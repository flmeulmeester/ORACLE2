

###########################################################################################################
#
# Project : Preparing data for LAVOLTA
#
###########################################################################################################

###########################################################################################################
#' [ Working directory initialisation]
###########################################################################################################

setwd("Y:/Simon_Couillard/ORACLE/LEBRI_LAVOLTA1-2/LEBRI_LAVOLTA1-2/2023_03_08_Merge")
getwd()

# Package importation

Packages <- c( "readxl","haven","ggplot2","dplyr","MASS", "summarytools", "gmodels",
               "jtools","car","openxlsx","extrafont","stargazer","readr")

lapply(Packages, library, character.only = TRUE)

###########################################################################################################
#' * PART 1 : KGAN*
###########################################################################################################

############################################################################################################
#' [Data import]
############################################################################################################

aab <- read_xpt("Y:/Simon_Couillard/ORACLE/LEBRI_LAVOLTA1-2/LEBRI_LAVOLTA1-2/ADaM_KGAN_placebo/aab.xpt")
aae <- read_xpt("Y:/Simon_Couillard/ORACLE/LEBRI_LAVOLTA1-2/LEBRI_LAVOLTA1-2/ADaM_KGAN_placebo/aae.xpt")
aag <- read_xpt("Y:/Simon_Couillard/ORACLE/LEBRI_LAVOLTA1-2/LEBRI_LAVOLTA1-2/ADaM_KGAN_placebo/aag.xpt")
acm <- read_xpt("Y:/Simon_Couillard/ORACLE/LEBRI_LAVOLTA1-2/LEBRI_LAVOLTA1-2/ADaM_KGAN_placebo/acm.xpt")
acq5 <- read_xpt("Y:/Simon_Couillard/ORACLE/LEBRI_LAVOLTA1-2/LEBRI_LAVOLTA1-2/ADaM_KGAN_placebo/acq5.xpt")
acqtest <- read_xpt("Y:/Simon_Couillard/ORACLE/LEBRI_LAVOLTA1-2/LEBRI_LAVOLTA1-2/ADaM_KGAN_placebo/acqtest.xpt")
adv <- read_xpt("Y:/Simon_Couillard/ORACLE/LEBRI_LAVOLTA1-2/LEBRI_LAVOLTA1-2/ADaM_KGAN_placebo/adv.xpt")
aeg <- read_xpt("Y:/Simon_Couillard/ORACLE/LEBRI_LAVOLTA1-2/LEBRI_LAVOLTA1-2/ADaM_KGAN_placebo/aeg.xpt")
ahcu <- read_xpt("Y:/Simon_Couillard/ORACLE/LEBRI_LAVOLTA1-2/LEBRI_LAVOLTA1-2/ADaM_KGAN_placebo/ahcu.xpt")
amh <- read_xpt("Y:/Simon_Couillard/ORACLE/LEBRI_LAVOLTA1-2/LEBRI_LAVOLTA1-2/ADaM_KGAN_placebo/amh.xpt")
aqs <- read_xpt("Y:/Simon_Couillard/ORACLE/LEBRI_LAVOLTA1-2/LEBRI_LAVOLTA1-2/ADaM_KGAN_placebo/aqs.xpt")
asl <- read_xpt("Y:/Simon_Couillard/ORACLE/LEBRI_LAVOLTA1-2/LEBRI_LAVOLTA1-2/ADaM_KGAN_placebo/asl.xpt")
asl2 <- read_xpt("Y:/Simon_Couillard/ORACLE/LEBRI_LAVOLTA1-2/LEBRI_LAVOLTA1-2/ADaM_KGAN_placebo/asl2.xpt")
asl3 <- read_xpt("Y:/Simon_Couillard/ORACLE/LEBRI_LAVOLTA1-2/LEBRI_LAVOLTA1-2/ADaM_KGAN_placebo/asl3.xpt")
asp <- read_xpt("Y:/Simon_Couillard/ORACLE/LEBRI_LAVOLTA1-2/LEBRI_LAVOLTA1-2/ADaM_KGAN_placebo/asp.xpt")
azb <- read_xpt("Y:/Simon_Couillard/ORACLE/LEBRI_LAVOLTA1-2/LEBRI_LAVOLTA1-2/ADaM_KGAN_placebo/azb.xpt")
exa <- read_xpt("Y:/Simon_Couillard/ORACLE/LEBRI_LAVOLTA1-2/LEBRI_LAVOLTA1-2/ADaM_KGAN_placebo/exa.xpt")
alb <- read_xpt("Y:/Simon_Couillard/ORACLE/LEBRI_LAVOLTA1-2/LEBRI_LAVOLTA1-2/ADaM_KGAN_placebo/alb.xpt")
zd <- read_xpt("Y:/Simon_Couillard/ORACLE/LEBRI_LAVOLTA1-2/LEBRI_LAVOLTA1-2/ADaM_KGAN_placebo/zd.xpt")

############################################################################################################
#' [New variables]
############################################################################################################

asl$Treatment_step <- ifelse( asl$ICSLABA == "Y",5,4  )
asl$Any_severe_attack_previous_12m <- ifelse(asl$ASMEX12C == "0",0, 1)
asl$ICS_Dose_PER_DAY <- asl$ICSEQDD*2.5
asl$Blood_Eos_baseline_x10_9_cells_per_L <- asl$EOS/1000
asl$Follow_up_duration_days <- asl$TARY1OT*365.25


amh$Psychiatric_disease <- ifelse(  (amh$MHHLT == "ADJUSTMENT DISORDERS" | amh$MHHLT == "ANXIETY DISORDERS NEC" | 
                                    amh$MHHLT == "ANXIETY SYMPTOMS" | amh$MHHLT == "ATTENTION DEFICIT AND DISRUPTIVE BEHAVIOUR DISORDERS" | 
                                    amh$MHHLT == "BIPOLAR DISORDERS" | amh$MHHLT == "DEPRESSIVE DISORDERS" | 
                                    amh$MHHLT == "EMOTIONAL AND MOOD DISTURBANCES NEC" | amh$MHHLT == "OBSESSIVE-COMPULSIVE DISORDERS AND SYMPTOMS" | 
                                    amh$MHHLT == "PSYCHOTIC DISORDER NEC" | amh$MHHLT == "SCHIZOPHRENIA AND OTHER PSYCHOTIC DISORDERS" | 
                                    amh$MHHLT == "SUBSTANCE-RELATED DISORDERS") & ( amh$MHDISTAT == "ONGOING WITH TREATMENT" | amh$MHDISTAT == "ONGOING WITHOUT TREATMENT" ) ,1,0)


amh$Psy_disease_type <- ifelse(  (amh$MHHLT == "ADJUSTMENT DISORDERS" | amh$MHHLT == "ANXIETY DISORDERS NEC" | amh$MHHLT == "ANXIETY SYMPTOMS" |  amh$MHHLT == "DEPRESSIVE DISORDERS" | 
                                       amh$MHHLT == "EMOTIONAL AND MOOD DISTURBANCES NEC" ) & ( amh$MHDISTAT == "ONGOING WITH TREATMENT" | amh$MHDISTAT == "ONGOING WITHOUT TREATMENT" ) ,1,
                                 ifelse(  ( amh$MHHLT == "SCHIZOPHRENIA AND OTHER PSYCHOTIC DISORDERS") & ( amh$MHDISTAT == "ONGOING WITH TREATMENT" | amh$MHDISTAT == "ONGOING WITHOUT TREATMENT" ) ,2,
                                          ifelse(  ( amh$MHHLT == "SUBSTANCE-RELATED DISORDERS") & ( amh$MHDISTAT == "ONGOING WITH TREATMENT" | amh$MHDISTAT == "ONGOING WITHOUT TREATMENT" ) ,3,
                                                   ifelse(  ( amh$MHHLT == "ATTENTION DEFICIT AND DISRUPTIVE BEHAVIOUR DISORDERS" | amh$MHHLT == "BIPOLAR DISORDERS" | amh$MHHLT == "OBSESSIVE-COMPULSIVE DISORDERS AND SYMPTOMS" ) 
                                                            & ( amh$MHDISTAT == "ONGOING WITH TREATMENT" | amh$MHDISTAT == "ONGOING WITHOUT TREATMENT" ) ,4,0))))


amh$Atopy_history <- ifelse(  ((amh$MHTERM == "ATOPIC DERMATITIS" | amh$MHTERM == "ECZEMA" | amh$MHTERM == "ALLERGIC RHINITIS") & (  amh$MHOCCUR == "Y")) |
                              ( amh$MHDECOD == "FOOD ALLERGY" & ( amh$MHDISTAT == "ONGOING WITH TREATMENT" | amh$MHDISTAT == "ONGOING WITHOUT TREATMENT" )   ), 1,0
                              )

amh$Eczema <- ifelse(  ((amh$MHTERM == "ATOPIC DERMATITIS" | amh$MHTERM == "ECZEMA") & (  amh$MHOCCUR == "Y")), 1,0)

amh$AllergicRhinitis <- ifelse(  ((amh$MHTERM == "ALLERGIC RHINITIS") & (  amh$MHOCCUR == "Y")), 1,0)

amh$Chronic_Rhinosinusitis <- ifelse(  ((amh$MHTERM == "CHRONIC SINUSITIS") & (  amh$MHOCCUR == "Y")), 1,0)

amh$Nasal_polyposis <- ifelse(  ((amh$MHTERM == "NASAL POLYPS" | amh$MHTERM == "SINUS POLYPS") & (  amh$MHOCCUR == "Y")), 1,0)


  
amh2 <- amh %>%
  group_by(USUBJID) %>%
  summarise(Psychiatric_disease = ifelse( sum(Psychiatric_disease,na.rm=T) > 0,1,0   ),
            Psy_disease_type = max(Psy_disease_type, na.rm = T),
            Atopy_history = ifelse( sum(Atopy_history,na.rm=T) > 0,1,0   ),
            Eczema = ifelse( sum(Eczema,na.rm=T) > 0,1,0   ),
            AllergicRhinitis = ifelse( sum(AllergicRhinitis,na.rm=T) > 0,1,0   ),
            Chronic_Rhinosinusitis = ifelse( sum(Chronic_Rhinosinusitis,na.rm=T) > 0,1,0   ),
            Nasal_polyposis = ifelse( sum(Nasal_polyposis,na.rm=T) > 0,1,0   )  )


acm$SABA_prescribed <- ifelse(  ((acm$CMDECOD == "SALBUTAMOL" | acm$CMDECOD == "SALBUTAMOL SULFATE" | acm$CMDECOD == "TERBUTALINE SULFATE" | acm$CMDECOD == "TERBUTALINE") & (  acm$ONTRTFL == "Y")), 1,0)
acm$Intranasal_seroid_prescribed <- ifelse(  ((acm$CMDOSU == "SPRAY" | acm$CMROUTE == "NASAL") & (  acm$ONTRTFL == "Y") & (acm$CMCLAS == "STEROIDS")   ), 1,0)



acm2 <- acm %>%
  group_by(USUBJID) %>%
  summarise(SABA_prescribed = ifelse( sum(SABA_prescribed,na.rm=T) > 0,1,0   ),
            Intranasal_seroid_prescribed = ifelse( sum(Intranasal_seroid_prescribed,na.rm=T) > 0,1,0   ))

exa$Time_to_First_attack <- ifelse( exa$UNIQEXF == 1 & exa$OTF == "Y" & exa$TIMETOEX < exa$TIMEARY1, exa$TIMETOEX*365.25,NA   )
exa$Time_to_2n_attack <-  ifelse( exa$UNIQEXF == 2 & exa$OTF == "Y" & exa$TIMETOEX < exa$TIMEARY1, exa$TIMETOEX*365.25,NA   )
exa$Time_to_3n_attack <-  ifelse( exa$UNIQEXF == 3 & exa$OTF == "Y" & exa$TIMETOEX < exa$TIMEARY1, exa$TIMETOEX*365.25,NA   )
exa$Time_to_4n_attack <-  ifelse( exa$UNIQEXF == 4 & exa$OTF == "Y" & exa$TIMETOEX < exa$TIMEARY1, exa$TIMETOEX*365.25,NA   )
exa$Time_to_5n_attack <-  ifelse( exa$UNIQEXF == 5 & exa$OTF == "Y" & exa$TIMETOEX < exa$TIMEARY1, exa$TIMETOEX*365.25,NA   )

exa2 <- exa %>%
  group_by(USUBJID) %>%
  mutate(  Time_to_First_attack2 =   first(na.omit(Time_to_First_attack)),
           Time_to_2n_attack2 =   first(na.omit(Time_to_2n_attack)),
           Time_to_3n_attack2 =   first(na.omit(Time_to_3n_attack)),
           Time_to_4n_attack2 =   first(na.omit(Time_to_4n_attack)),
           Time_to_5n_attack2 =   first(na.omit(Time_to_5n_attack)) )

exa2 <- exa2[!duplicated(exa2$USUBJID), ]

asl$SKIN <- ifelse( asl$ASMSTR == "POSITIVE", 1, ifelse(  asl$ASMST == "U" | asl$ASMST == "N" | is.na(asl$ASMST) == T | asl$ASMSTR == "UNKNOWN" | asl$ASMSTR == "INDETERMINATE", NA ,
                                                                  ifelse(  asl$ASMSTR == "NEGATIVE", 0,NA     )      )      )


alb$RAST <- ifelse(  (alb$LBTESTCD == "CATDIGE" & alb$AVAL >= 0.7) | 
                                                             (alb$LBTESTCD == "DERIGE" & alb$AVAL >= 0.7) | 
                                                             (alb$LBTESTCD == "DOGIGE" & alb$AVAL >= 0.7) | 
                                                             (alb$LBTESTCD == "CRAIGE" & alb$AVAL >= 0.7) | 
                                                             (alb$LBTESTCD == "DPTIGE" & alb$AVAL >= 0.7),1,
                                                           ifelse(  (alb$LBTESTCD == "CATDIGE" & alb$AVAL < 0.7) | 
                                                                      (alb$LBTESTCD == "DERIGE" & alb$AVAL < 0.7) | 
                                                                      (alb$LBTESTCD == "DOGIGE" & alb$AVAL < 0.7) | 
                                                                      (alb$LBTESTCD == "CRAIGE" & alb$AVAL < 0.7) | 
                                                                      (alb$LBTESTCD == "DPTIGE" & alb$AVAL < 0.7),0,NA            )
) 


alb2 <- alb %>%
  group_by(USUBJID) %>%
  summarise(RAST = ifelse( sum(RAST,na.rm=T) > 0,1,0   )  )

asup <- merge(asl,alb2[,c(1,2)], by = "USUBJID", all.x = T)

asup$Airborne_allergen_sensitisation_on_testing <- ifelse( asup$RAST == 1 | asup$SKIN == 1, 1, ifelse(   
    asup$RAST ==0 & asup$SKIN == 0 , 0 , NA  )           )


zd1 <- zd %>%
  filter( ZDTESTCD == "FEV1" & ZDTPT == "POST-DOSE" & ZDSTRESU == "L" & VISITNUM == 17  )%>%
  group_by(USUBJID) %>%
  summarise(   FEV1POSTBD_L_52W = max(ZDSTRESN,na.rm=T))

#zd2 <- zd %>%
#  filter( ZDTESTCD == "FEV1" & ZDTPT == "POST-DOSE" & ZDSTRESU == "%" & VISITNUM == 17  )



############################################################################################################
#' [Extracting data]
############################################################################################################

DataSet <- asl[,c(2,4,5,14,6,98)]

DataSet$Sequential_number <- as.numeric(NA)

DataSet$Enrolled_Trial_name <- "LAVOLTA_1"

DataSet$Treatment_arm <- "PLACEBO"

DataSet <- DataSet[,c(1,7,8,9,2,3,4,5,6)]

DataSet <- merge(DataSet,asl[,c(2,161,162,124,123)], by = "USUBJID", all.x = T)

DataSet$Previous_ICU <- as.numeric(NA)

DataSet <- merge(DataSet,asl[,c(2,126,109)], by = "USUBJID", all.x = T)

DataSet$Pack_years <- as.numeric(NA)

DataSet <- merge(DataSet,amh2[,c(1,2,3,4,5,6)], by = "USUBJID", all.x = T)

DataSet <- merge(DataSet,asup[,c(1,168)], by = "USUBJID", all.x = T)

DataSet <- merge(DataSet,amh2[,c(1,7,8)], by = "USUBJID", all.x = T)

DataSet$Previous_nasal_polypectomy <- as.numeric(NA)
DataSet$Adherence_PreTrial_quantity <- as.numeric(NA)
DataSet$Adherence_PreTrial_quality <- as.numeric(NA)
DataSet$Adherence_InTrial_quantity <- as.numeric(NA)
DataSet$Adherence_InTrial_quality <- as.numeric(NA)
DataSet$SABA_actuations_per_day_average_PreTrial <- as.numeric(NA)

DataSet <- merge(DataSet,acm2[,c(1,2)], by = "USUBJID", all.x = T)

DataSet$SABA_actuations_per_day_average_InTrial <- as.numeric(NA)

DataSet <- merge(DataSet,asl[,c(2,112)], by = "USUBJID", all.x = T)

DataSet$ICS_TYPE <- "FP"

DataSet <- merge(DataSet,asl[,c(2,163,113,114)], by = "USUBJID", all.x = T)

DataSet$maintenance_OCS_prescribed <- 0
DataSet$Mainteance_OCS_dose <- 0

DataSet <- merge(DataSet,asl[,c(2,115,116)], by = "USUBJID", all.x = T)

DataSet <- merge(DataSet,acm2[,c(1,3)], by = "USUBJID", all.x = T)

DataSet$FEV1_predicted_L <- as.numeric(NA)
DataSet$FVC_predicted_L <- as.numeric(NA)

DataSet <- merge(DataSet,asl[,c(2,91,95,92)], by = "USUBJID", all.x = T)

DataSet$FVC_preBD_PCT_Baseline <- as.numeric(NA)

DataSet$FEV1_postBD_L_Baseline <- as.numeric(NA)
DataSet <- merge(DataSet,asl3[,c(1,5)], by = "USUBJID", all.x = T)

DataSet$FVC_postBD_L_Baseline <- as.numeric(NA)
DataSet$FVC_postBD_PCT_Baseline <- as.numeric(NA)

DataSet <- merge(DataSet,asl[,c(2,97,120)], by = "USUBJID", all.x = T)

DataSet$ACQ_baseline_score_item1_sleepawakenings <- as.numeric(NA)
DataSet$ACQ_baseline_score_item2_morningsymptoms <- as.numeric(NA)
DataSet$ACQ_baseline_score_item3_activitylimitation <- as.numeric(NA)
DataSet$ACQ_baseline_score_item4_dyspnea <- as.numeric(NA)
DataSet$ACQ_baseline_score_item5_wheezing <- as.numeric(NA)
DataSet$ACQ_baseline_score_item6_RelieverUse <- as.numeric(NA)
DataSet$ACQ_baseline_score_item7_FEV1 <- as.numeric(NA)
DataSet$ACT_baseline_score <- as.numeric(NA)

DataSet <- merge(DataSet,asl[,c(2,164,86,89,165,134)], by = "USUBJID", all.x = T)

DataSet <- merge(DataSet,exa2[,c(2,71,72,73,74,75)], by = "USUBJID", all.x = T)

DataSet <- merge(DataSet,asl[,c(2,53,94,96)], by = "USUBJID", all.x = T)

DataSet <- merge(DataSet,zd1[,c(1,2)], by = "USUBJID", all.x = T)

DataSet$FEV1POSTBD_PCT_52W <- as.numeric(NA) 

DataSet <- DataSet[,c(2,1,3:78)]

DataSet <- DataSet %>%
  rename(  Subject_ID = USUBJID,
           Age = AGE,
           Gender_M = SEX,
           BMI = BBMI, 
           Ethnicity = RACE,
           Country = COUNTRY,
           Number_severe_attack_previous_12m = ASMEX12C,
           Number_hospitalisations_for_asthma_previous_12_months = ASMHOS12,
           Previous_Intubation = ASMINT,
           Smoking = SMOKE,
           Any_ICS_prescribed = BLICS,
           LABA_prescribed = BLLABA,
           LAMA_prescribed = BLLAMA,
           Montelukast_prescribed = BLLTRA,
           Theophylline_prescribed = BLTHEO,
           FEV1_preBD_L_Baseline = FEV1,
           FEV1_preBD_PCT_Baseline = FEV1PP,
           FVC_preBD_L_Baseline = FVC,
           FEV1_postBD_PCT_Baseline = FEV1POPP,
           FEV1_PCT_reversibility_postBD = BESTBDR,
           ACQ_baseline_score_mean = ACQ5,
           FeNO_baseline_ppb = FENO,
           Total_IgE = IGE,
           Number_severe_asthma_attacks_during_followup = NUMEXT,
           EndFollowUp_Reason = STDIPCR,
           FEV1PREBD_L_52W = FEV1A,
           FEV1PREBD_PCT_52W = FEV1PPA, 
           Time_to_First_attack = Time_to_First_attack2,
           Time_to_2n_attack = Time_to_2n_attack2,
           Time_to_3n_attack = Time_to_3n_attack2,
           Time_to_4n_attack = Time_to_4n_attack2,
           Time_to_5n_attack = Time_to_5n_attack2  )



DataSet$Gender_M <- ifelse( DataSet$Gender_M == "M",1,0 )

DataSet$Previous_Intubation <- ifelse( DataSet$Previous_Intubation == "Y",1,0 )

DataSet$Any_ICS_prescribed <- ifelse( DataSet$Any_ICS_prescribed == "Y",1,0 )

DataSet$LABA_prescribed <- ifelse( DataSet$LABA_prescribed == "Y",1,0 )

DataSet$LAMA_prescribed <- ifelse( DataSet$LAMA_prescribed == "Y",1,0 )

DataSet$Montelukast_prescribed <- ifelse( DataSet$Montelukast_prescribed == "Y",1,0 )

DataSet$Theophylline_prescribed <- ifelse( DataSet$Theophylline_prescribed == "Y",1,0 )

DataSet$Number_severe_attack_previous_12m <- as.factor(DataSet$Number_severe_attack_previous_12m)

DataSet$Number_hospitalisations_for_asthma_previous_12_months <- as.factor(DataSet$Number_hospitalisations_for_asthma_previous_12_months)

DataSet$Smoking <- ifelse( DataSet$Smoking == "Never",0, ifelse(DataSet$Smoking == "Current",2,1)      )

DataSet$EndFollowUp_Reason <- ifelse(  DataSet$EndFollowUp_Reason == "",0,DataSet$EndFollowUp_Reason    )


write.xlsx(DataSet,"LAVOLTA1_clean.xlsx")


###########################################################################################################
#' * PART 2 : KGAO*
###########################################################################################################


############################################################################################################
#' [Data import]
############################################################################################################

aab <- read_xpt("Y:/Simon_Couillard/ORACLE/LEBRI_LAVOLTA1-2/LEBRI_LAVOLTA1-2/ADaM_KGAO_placebo/aab.xpt")
aae <- read_xpt("Y:/Simon_Couillard/ORACLE/LEBRI_LAVOLTA1-2/LEBRI_LAVOLTA1-2/ADaM_KGAO_placebo/aae.xpt")
aag <- read_xpt("Y:/Simon_Couillard/ORACLE/LEBRI_LAVOLTA1-2/LEBRI_LAVOLTA1-2/ADaM_KGAO_placebo/aag.xpt")
acm <- read_xpt("Y:/Simon_Couillard/ORACLE/LEBRI_LAVOLTA1-2/LEBRI_LAVOLTA1-2/ADaM_KGAO_placebo/acm.xpt")
acq <- read_xpt("Y:/Simon_Couillard/ORACLE/LEBRI_LAVOLTA1-2/LEBRI_LAVOLTA1-2/ADaM_KGAO_placebo/acq.xpt")
acq5 <- read_xpt("Y:/Simon_Couillard/ORACLE/LEBRI_LAVOLTA1-2/LEBRI_LAVOLTA1-2/ADaM_KGAO_placebo/acq5.xpt")
acqtest <- read_xpt("Y:/Simon_Couillard/ORACLE/LEBRI_LAVOLTA1-2/LEBRI_LAVOLTA1-2/ADaM_KGAO_placebo/acqtest.xpt")
adv <- read_xpt("Y:/Simon_Couillard/ORACLE/LEBRI_LAVOLTA1-2/LEBRI_LAVOLTA1-2/ADaM_KGAO_placebo/adv.xpt")
aeg <- read_xpt("Y:/Simon_Couillard/ORACLE/LEBRI_LAVOLTA1-2/LEBRI_LAVOLTA1-2/ADaM_KGAO_placebo/aeg.xpt")
ahcu <- read_xpt("Y:/Simon_Couillard/ORACLE/LEBRI_LAVOLTA1-2/LEBRI_LAVOLTA1-2/ADaM_KGAO_placebo/ahcu.xpt")
alb <- read_xpt("Y:/Simon_Couillard/ORACLE/LEBRI_LAVOLTA1-2/LEBRI_LAVOLTA1-2/ADaM_KGAO_placebo/alb.xpt")
amh <- read_xpt("Y:/Simon_Couillard/ORACLE/LEBRI_LAVOLTA1-2/LEBRI_LAVOLTA1-2/ADaM_KGAO_placebo/amh.xpt")
aqs <- read_xpt("Y:/Simon_Couillard/ORACLE/LEBRI_LAVOLTA1-2/LEBRI_LAVOLTA1-2/ADaM_KGAO_placebo/aqs.xpt")
asl <- read_xpt("Y:/Simon_Couillard/ORACLE/LEBRI_LAVOLTA1-2/LEBRI_LAVOLTA1-2/ADaM_KGAO_placebo/asl.xpt")
asl2 <- read_xpt("Y:/Simon_Couillard/ORACLE/LEBRI_LAVOLTA1-2/LEBRI_LAVOLTA1-2/ADaM_KGAO_placebo/asl2.xpt")
asl3 <- read_xpt("Y:/Simon_Couillard/ORACLE/LEBRI_LAVOLTA1-2/LEBRI_LAVOLTA1-2/ADaM_KGAO_placebo/asl3.xpt")
asp <- read_xpt("Y:/Simon_Couillard/ORACLE/LEBRI_LAVOLTA1-2/LEBRI_LAVOLTA1-2/ADaM_KGAO_placebo/asp.xpt")
avs <- read_xpt("Y:/Simon_Couillard/ORACLE/LEBRI_LAVOLTA1-2/LEBRI_LAVOLTA1-2/ADaM_KGAO_placebo/avs.xpt")
azb <- read_xpt("Y:/Simon_Couillard/ORACLE/LEBRI_LAVOLTA1-2/LEBRI_LAVOLTA1-2/ADaM_KGAO_placebo/azb.xpt")
exa <- read_xpt("Y:/Simon_Couillard/ORACLE/LEBRI_LAVOLTA1-2/LEBRI_LAVOLTA1-2/ADaM_KGAO_placebo/exa.xpt")
zd <- read_xpt("Y:/Simon_Couillard/ORACLE/LEBRI_LAVOLTA1-2/LEBRI_LAVOLTA1-2/ADaM_KGAO_placebo/zd.xpt")



############################################################################################################
#' [New variables]
############################################################################################################

asl$Treatment_step <- ifelse( asl$ICSLABA == "Y",5,4  )
asl$Any_severe_attack_previous_12m <- ifelse(asl$ASMEX12C == "0",0, 1)
asl$ICS_Dose_PER_DAY <- asl$ICSEQDD*2.5
asl$Blood_Eos_baseline_x10_9_cells_per_L <- asl$EOS/1000
asl$Follow_up_duration_days <- asl$TARY1OT*365.25


amh$Psychiatric_disease <- ifelse(  (amh$MHHLT == "ADJUSTMENT DISORDERS" | amh$MHHLT == "ANXIETY DISORDERS NEC" | 
                                       amh$MHHLT == "ANXIETY SYMPTOMS" | amh$MHHLT == "ATTENTION DEFICIT AND DISRUPTIVE BEHAVIOUR DISORDERS" | 
                                       amh$MHHLT == "BIPOLAR DISORDERS" | amh$MHHLT == "DEPRESSIVE DISORDERS" | 
                                       amh$MHHLT == "EMOTIONAL AND MOOD DISTURBANCES NEC" | amh$MHHLT == "OBSESSIVE-COMPULSIVE DISORDERS AND SYMPTOMS" | 
                                       amh$MHHLT == "PSYCHOTIC DISORDER NEC" | amh$MHHLT == "SCHIZOPHRENIA AND OTHER PSYCHOTIC DISORDERS" | 
                                       amh$MHHLT == "SUBSTANCE-RELATED DISORDERS") & ( amh$MHDISTAT == "ONGOING WITH TREATMENT" | amh$MHDISTAT == "ONGOING WITHOUT TREATMENT" ) ,1,0)


amh$Psy_disease_type <- ifelse(  (amh$MHHLT == "ADJUSTMENT DISORDERS" | amh$MHHLT == "ANXIETY DISORDERS NEC" | amh$MHHLT == "ANXIETY SYMPTOMS" |  amh$MHHLT == "DEPRESSIVE DISORDERS" | 
                                    amh$MHHLT == "EMOTIONAL AND MOOD DISTURBANCES NEC" ) & ( amh$MHDISTAT == "ONGOING WITH TREATMENT" | amh$MHDISTAT == "ONGOING WITHOUT TREATMENT" ) ,1,
                                 ifelse(  ( amh$MHHLT == "SCHIZOPHRENIA AND OTHER PSYCHOTIC DISORDERS") & ( amh$MHDISTAT == "ONGOING WITH TREATMENT" | amh$MHDISTAT == "ONGOING WITHOUT TREATMENT" ) ,2,
                                          ifelse(  ( amh$MHHLT == "SUBSTANCE-RELATED DISORDERS") & ( amh$MHDISTAT == "ONGOING WITH TREATMENT" | amh$MHDISTAT == "ONGOING WITHOUT TREATMENT" ) ,3,
                                                   ifelse(  ( amh$MHHLT == "ATTENTION DEFICIT AND DISRUPTIVE BEHAVIOUR DISORDERS" | amh$MHHLT == "BIPOLAR DISORDERS" | amh$MHHLT == "OBSESSIVE-COMPULSIVE DISORDERS AND SYMPTOMS" ) 
                                                            & ( amh$MHDISTAT == "ONGOING WITH TREATMENT" | amh$MHDISTAT == "ONGOING WITHOUT TREATMENT" ) ,4,0))))


amh$Atopy_history <- ifelse(  ((amh$MHTERM == "ATOPIC DERMATITIS" | amh$MHTERM == "ECZEMA" | amh$MHTERM == "ALLERGIC RHINITIS") & (  amh$MHOCCUR == "Y")) |
                                ( amh$MHDECOD == "FOOD ALLERGY" & ( amh$MHDISTAT == "ONGOING WITH TREATMENT" | amh$MHDISTAT == "ONGOING WITHOUT TREATMENT" )   ), 1,0
)

amh$Eczema <- ifelse(  ((amh$MHTERM == "ATOPIC DERMATITIS" | amh$MHTERM == "ECZEMA") & (  amh$MHOCCUR == "Y")), 1,0)

amh$AllergicRhinitis <- ifelse(  ((amh$MHTERM == "ALLERGIC RHINITIS") & (  amh$MHOCCUR == "Y")), 1,0)

amh$Chronic_Rhinosinusitis <- ifelse(  ((amh$MHTERM == "CHRONIC SINUSITIS") & (  amh$MHOCCUR == "Y")), 1,0)

amh$Nasal_polyposis <- ifelse(  ((amh$MHTERM == "NASAL POLYPS" | amh$MHTERM == "SINUS POLYPS") & (  amh$MHOCCUR == "Y")), 1,0)



amh2 <- amh %>%
  group_by(USUBJID) %>%
  summarise(Psychiatric_disease = ifelse( sum(Psychiatric_disease,na.rm=T) > 0,1,0   ),
            Psy_disease_type = max(Psy_disease_type, na.rm = T),
            Atopy_history = ifelse( sum(Atopy_history,na.rm=T) > 0,1,0   ),
            Eczema = ifelse( sum(Eczema,na.rm=T) > 0,1,0   ),
            AllergicRhinitis = ifelse( sum(AllergicRhinitis,na.rm=T) > 0,1,0   ),
            Chronic_Rhinosinusitis = ifelse( sum(Chronic_Rhinosinusitis,na.rm=T) > 0,1,0   ),
            Nasal_polyposis = ifelse( sum(Nasal_polyposis,na.rm=T) > 0,1,0   )  )


acm$SABA_prescribed <- ifelse(  ((acm$CMDECOD == "SALBUTAMOL" | acm$CMDECOD == "SALBUTAMOL SULFATE" | acm$CMDECOD == "TERBUTALINE SULFATE" | acm$CMDECOD == "TERBUTALINE") & (  acm$ONTRTFL == "Y")), 1,0)
acm$Intranasal_seroid_prescribed <- ifelse(  ((acm$CMDOSU == "SPRAY" | acm$CMROUTE == "NASAL") & (  acm$ONTRTFL == "Y") & (acm$CMCLAS == "STEROIDS")   ), 1,0)



acm2 <- acm %>%
  group_by(USUBJID) %>%
  summarise(SABA_prescribed = ifelse( sum(SABA_prescribed,na.rm=T) > 0,1,0   ),
            Intranasal_seroid_prescribed = ifelse( sum(Intranasal_seroid_prescribed,na.rm=T) > 0,1,0   ))

exa$Time_to_First_attack <- ifelse( exa$UNIQEXF == 1 & exa$OTF == "Y" & exa$TIMETOEX < exa$TIMEARY1, exa$TIMETOEX*365.25,NA   )
exa$Time_to_2n_attack <-  ifelse( exa$UNIQEXF == 2 & exa$OTF == "Y" & exa$TIMETOEX < exa$TIMEARY1, exa$TIMETOEX*365.25,NA   )
exa$Time_to_3n_attack <-  ifelse( exa$UNIQEXF == 3 & exa$OTF == "Y" & exa$TIMETOEX < exa$TIMEARY1, exa$TIMETOEX*365.25,NA   )
exa$Time_to_4n_attack <-  ifelse( exa$UNIQEXF == 4 & exa$OTF == "Y" & exa$TIMETOEX < exa$TIMEARY1, exa$TIMETOEX*365.25,NA   )
exa$Time_to_5n_attack <-  ifelse( exa$UNIQEXF == 5 & exa$OTF == "Y" & exa$TIMETOEX < exa$TIMEARY1, exa$TIMETOEX*365.25,NA   )

exa2 <- exa %>%
  group_by(USUBJID) %>%
  mutate(  Time_to_First_attack2 =   first(na.omit(Time_to_First_attack)),
           Time_to_2n_attack2 =   first(na.omit(Time_to_2n_attack)),
           Time_to_3n_attack2 =   first(na.omit(Time_to_3n_attack)),
           Time_to_4n_attack2 =   first(na.omit(Time_to_4n_attack)),
           Time_to_5n_attack2 =   first(na.omit(Time_to_5n_attack)) )

exa2 <- exa2[!duplicated(exa2$USUBJID), ]

asl$SKIN <- ifelse( asl$ASMSTR == "POSITIVE", 1, ifelse(  asl$ASMST == "U" | asl$ASMST == "N" | is.na(asl$ASMST) == T | asl$ASMSTR == "UNKNOWN" | asl$ASMSTR == "INDETERMINATE", NA ,
                                                          ifelse(  asl$ASMSTR == "NEGATIVE", 0,NA     )      )      )


alb$RAST <- ifelse(  (alb$LBTESTCD == "CATDIGE" & alb$AVAL >= 0.7) | 
                       (alb$LBTESTCD == "DERIGE" & alb$AVAL >= 0.7) | 
                       (alb$LBTESTCD == "DOGIGE" & alb$AVAL >= 0.7) | 
                       (alb$LBTESTCD == "CRAIGE" & alb$AVAL >= 0.7) | 
                       (alb$LBTESTCD == "DPTIGE" & alb$AVAL >= 0.7),1,
                     ifelse(  (alb$LBTESTCD == "CATDIGE" & alb$AVAL < 0.7) | 
                                (alb$LBTESTCD == "DERIGE" & alb$AVAL < 0.7) | 
                                (alb$LBTESTCD == "DOGIGE" & alb$AVAL < 0.7) | 
                                (alb$LBTESTCD == "CRAIGE" & alb$AVAL < 0.7) | 
                                (alb$LBTESTCD == "DPTIGE" & alb$AVAL < 0.7),0,NA            )
) 


alb2 <- alb %>%
  group_by(USUBJID) %>%
  summarise(RAST = ifelse( sum(RAST,na.rm=T) > 0,1,0   )  )

asup <- merge(asl,alb2[,c(1,2)], by = "USUBJID", all.x = T)

asup$Airborne_allergen_sensitisation_on_testing <- ifelse( asup$RAST == 1 | asup$SKIN == 1, 1, ifelse(   
  asup$RAST ==0 & asup$SKIN == 0 , 0 , NA  )           )

zd1 <- zd %>%
  filter( ZDTESTCD == "FEV1" & ZDTPT == "POST-DOSE" & ZDSTRESU == "L" & VISITNUM == 17  )%>%
  group_by(USUBJID) %>%
  summarise(   FEV1POSTBD_L_52W = max(ZDSTRESN,na.rm=T))

#zd2 <- zd %>%
#  filter( ZDTESTCD == "FEV1" & ZDTPT == "POST-DOSE" & ZDSTRESU == "%" & VISITNUM == 17  )



############################################################################################################
#' [Extracting data]
############################################################################################################

DataSet <- asl[,c(2,4,5,14,6,98)]

DataSet$Sequential_number <- as.numeric(NA)

DataSet$Enrolled_Trial_name <- "LAVOLTA_2"

DataSet$Treatment_arm <- "PLACEBO"

DataSet <- DataSet[,c(1,7,8,9,2,3,4,5,6)]

DataSet <- merge(DataSet,asl[,c(2,161,162,124,123)], by = "USUBJID", all.x = T)

DataSet$Previous_ICU <- as.numeric(NA)

DataSet <- merge(DataSet,asl[,c(2,126,109)], by = "USUBJID", all.x = T)

DataSet$Pack_years <- as.numeric(NA)

DataSet <- merge(DataSet,amh2[,c(1,2,3,4,5,6)], by = "USUBJID", all.x = T)

DataSet <- merge(DataSet,asup[,c(1,168)], by = "USUBJID", all.x = T)

DataSet <- merge(DataSet,amh2[,c(1,7,8)], by = "USUBJID", all.x = T)

DataSet$Previous_nasal_polypectomy <- as.numeric(NA)
DataSet$Adherence_PreTrial_quantity <- as.numeric(NA)
DataSet$Adherence_PreTrial_quality <- as.numeric(NA)
DataSet$Adherence_InTrial_quantity <- as.numeric(NA)
DataSet$Adherence_InTrial_quality <- as.numeric(NA)
DataSet$SABA_actuations_per_day_average_PreTrial <- as.numeric(NA)

DataSet <- merge(DataSet,acm2[,c(1,2)], by = "USUBJID", all.x = T)

DataSet$SABA_actuations_per_day_average_InTrial <- as.numeric(NA)

DataSet <- merge(DataSet,asl[,c(2,112)], by = "USUBJID", all.x = T)

DataSet$ICS_TYPE <- "FP"

DataSet <- merge(DataSet,asl[,c(2,163,113,114)], by = "USUBJID", all.x = T)

DataSet$maintenance_OCS_prescribed <- 0
DataSet$Mainteance_OCS_dose <- 0

DataSet <- merge(DataSet,asl[,c(2,115,116)], by = "USUBJID", all.x = T)

DataSet <- merge(DataSet,acm2[,c(1,3)], by = "USUBJID", all.x = T)

DataSet$FEV1_predicted_L <- as.numeric(NA)
DataSet$FVC_predicted_L <- as.numeric(NA)

DataSet <- merge(DataSet,asl[,c(2,91,95,92)], by = "USUBJID", all.x = T)

DataSet$FVC_preBD_PCT_Baseline <- as.numeric(NA)

DataSet$FEV1_postBD_L_Baseline <- as.numeric(NA)

DataSet <- merge(DataSet,asl3[,c(1,5)], by = "USUBJID", all.x = T)

DataSet$FVC_postBD_L_Baseline <- as.numeric(NA)
DataSet$FVC_postBD_PCT_Baseline <- as.numeric(NA)

DataSet <- merge(DataSet,asl[,c(2,97,120)], by = "USUBJID", all.x = T)

DataSet$ACQ_baseline_score_item1_sleepawakenings <- as.numeric(NA)
DataSet$ACQ_baseline_score_item2_morningsymptoms <- as.numeric(NA)
DataSet$ACQ_baseline_score_item3_activitylimitation <- as.numeric(NA)
DataSet$ACQ_baseline_score_item4_dyspnea <- as.numeric(NA)
DataSet$ACQ_baseline_score_item5_wheezing <- as.numeric(NA)
DataSet$ACQ_baseline_score_item6_RelieverUse <- as.numeric(NA)
DataSet$ACQ_baseline_score_item7_FEV1 <- as.numeric(NA)
DataSet$ACT_baseline_score <- as.numeric(NA)

DataSet <- merge(DataSet,asl[,c(2,164,86,89,165,134)], by = "USUBJID", all.x = T)

DataSet <- merge(DataSet,exa2[,c(2,71,72,73,74,75)], by = "USUBJID", all.x = T)

DataSet <- merge(DataSet,asl[,c(2,53,94,96)], by = "USUBJID", all.x = T)

DataSet <- merge(DataSet,zd1[,c(1,2)], by = "USUBJID", all.x = T)

DataSet$FEV1POSTBD_PCT_52W <- as.numeric(NA) 

DataSet <- DataSet[,c(2,1,3:78)]

DataSet <- DataSet %>%
  rename(  Subject_ID = USUBJID,
           Age = AGE,
           Gender_M = SEX,
           BMI = BBMI, 
           Ethnicity = RACE,
           Country = COUNTRY,
           Number_severe_attack_previous_12m = ASMEX12C,
           Number_hospitalisations_for_asthma_previous_12_months = ASMHOS12,
           Previous_Intubation = ASMINT,
           Smoking = SMOKE,
           Any_ICS_prescribed = BLICS,
           LABA_prescribed = BLLABA,
           LAMA_prescribed = BLLAMA,
           Montelukast_prescribed = BLLTRA,
           Theophylline_prescribed = BLTHEO,
           FEV1_preBD_L_Baseline = FEV1,
           FEV1_preBD_PCT_Baseline = FEV1PP,
           FVC_preBD_L_Baseline = FVC,
           FEV1_postBD_PCT_Baseline = FEV1POPP,
           FEV1_PCT_reversibility_postBD = BESTBDR,
           ACQ_baseline_score_mean = ACQ5,
           FeNO_baseline_ppb = FENO,
           Total_IgE = IGE,
           Number_severe_asthma_attacks_during_followup = NUMEXT,
           EndFollowUp_Reason = STDIPCR,
           FEV1PREBD_L_52W = FEV1A,
           FEV1PREBD_PCT_52W = FEV1PPA, 
           Time_to_First_attack = Time_to_First_attack2,
           Time_to_2n_attack = Time_to_2n_attack2,
           Time_to_3n_attack = Time_to_3n_attack2,
           Time_to_4n_attack = Time_to_4n_attack2,
           Time_to_5n_attack = Time_to_5n_attack2)


DataSet$Gender_M <- ifelse( DataSet$Gender_M == "M",1,0 )

DataSet$Previous_Intubation <- ifelse( DataSet$Previous_Intubation == "Y",1,0 )

DataSet$Any_ICS_prescribed <- ifelse( DataSet$Any_ICS_prescribed == "Y",1,0 )

DataSet$LABA_prescribed <- ifelse( DataSet$LABA_prescribed == "Y",1,0 )

DataSet$LAMA_prescribed <- ifelse( DataSet$LAMA_prescribed == "Y",1,0 )

DataSet$Montelukast_prescribed <- ifelse( DataSet$Montelukast_prescribed == "Y",1,0 )

DataSet$Theophylline_prescribed <- ifelse( DataSet$Theophylline_prescribed == "Y",1,0 )

DataSet$Number_severe_attack_previous_12m <- as.factor(DataSet$Number_severe_attack_previous_12m)

DataSet$Number_hospitalisations_for_asthma_previous_12_months <- as.factor(DataSet$Number_hospitalisations_for_asthma_previous_12_months)

DataSet$Smoking <- ifelse( DataSet$Smoking == "Never",0, ifelse(DataSet$Smoking == "Current",2,1)      )

DataSet$EndFollowUp_Reason <- ifelse(  DataSet$EndFollowUp_Reason == "",0,DataSet$EndFollowUp_Reason    )


DataSet$Time_to_First_attack <- ifelse( DataSet$Subject_ID == "GB28689-817807-699107", 25, DataSet$Time_to_First_attack   )
DataSet$Time_to_2n_attack <- ifelse( DataSet$Subject_ID == "GB28689-817807-699107", 233, DataSet$Time_to_2n_attack    )
DataSet$Time_to_3n_attack <- ifelse( DataSet$Subject_ID == "GB28689-817807-699107", 283, DataSet$Time_to_3n_attack    )
DataSet$Time_to_4n_attack <- ifelse( DataSet$Subject_ID == "GB28689-817807-699107", NA, DataSet$Time_to_4n_attack    )

DataSet <- DataSet %>%
  filter(Subject_ID != "GB28689-817807-699108")

write.xlsx(DataSet,"LAVOLTA2_clean.xlsx")
