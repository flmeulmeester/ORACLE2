

###########################################################################################################
#
# Project : Preparing data for LUTE-VERSE
#
###########################################################################################################

###########################################################################################################
#' [ Working directory initialisation]
###########################################################################################################

setwd("Y:/Simon_Couillard/ORACLE/LEBRI_LUTE-VERSE/LEBRI_LUTE-VERSE/2023_03_14_extraction_LUTEVERSE")
getwd()

# Package importation

Packages <- c( "readxl","haven","ggplot2","dplyr","MASS", "summarytools", "gmodels",
               "jtools","car","openxlsx","extrafont","stargazer","readr")

lapply(Packages, library, character.only = TRUE)

###########################################################################################################
#' * PART 1 : KGAU*
###########################################################################################################

############################################################################################################
#' [Data import]
############################################################################################################


aae <- read_xpt("Y:/Simon_Couillard/ORACLE/LEBRI_LUTE-VERSE/LEBRI_LUTE-VERSE/ADaM_KGAU_placebo/aae.xpt")
acm <- read_xpt("Y:/Simon_Couillard/ORACLE/LEBRI_LUTE-VERSE/LEBRI_LUTE-VERSE/ADaM_KGAU_placebo/acm.xpt")
adv <- read_xpt("Y:/Simon_Couillard/ORACLE/LEBRI_LUTE-VERSE/LEBRI_LUTE-VERSE/ADaM_KGAU_placebo/adv.xpt")
aeg <- read_xpt("Y:/Simon_Couillard/ORACLE/LEBRI_LUTE-VERSE/LEBRI_LUTE-VERSE/ADaM_KGAU_placebo/aeg.xpt")
alb <- read_xpt("Y:/Simon_Couillard/ORACLE/LEBRI_LUTE-VERSE/LEBRI_LUTE-VERSE/ADaM_KGAU_placebo/alb.xpt")
amh <- read_xpt("Y:/Simon_Couillard/ORACLE/LEBRI_LUTE-VERSE/LEBRI_LUTE-VERSE/ADaM_KGAU_placebo/amh.xpt")
apd <- read_xpt("Y:/Simon_Couillard/ORACLE/LEBRI_LUTE-VERSE/LEBRI_LUTE-VERSE/ADaM_KGAU_placebo/apd.xpt")
aqs <- read_xpt("Y:/Simon_Couillard/ORACLE/LEBRI_LUTE-VERSE/LEBRI_LUTE-VERSE/ADaM_KGAU_placebo/aqs.xpt")
asl <- read_xpt("Y:/Simon_Couillard/ORACLE/LEBRI_LUTE-VERSE/LEBRI_LUTE-VERSE/ADaM_KGAU_placebo/asl.xpt")
asm <- read_xpt("Y:/Simon_Couillard/ORACLE/LEBRI_LUTE-VERSE/LEBRI_LUTE-VERSE/ADaM_KGAU_placebo/asm.xpt")
asp <- read_xpt("Y:/Simon_Couillard/ORACLE/LEBRI_LUTE-VERSE/LEBRI_LUTE-VERSE/ADaM_KGAU_placebo/asp.xpt")
avs <- read_xpt("Y:/Simon_Couillard/ORACLE/LEBRI_LUTE-VERSE/LEBRI_LUTE-VERSE/ADaM_KGAU_placebo/avs.xpt")
cm <- read_xpt("Y:/Simon_Couillard/ORACLE/LEBRI_LUTE-VERSE/LEBRI_LUTE-VERSE/ADaM_KGAU_placebo/cm.xpt")
qs <- read_xpt("Y:/Simon_Couillard/ORACLE/LEBRI_LUTE-VERSE/LEBRI_LUTE-VERSE/ADaM_KGAU_placebo/qs.xpt")
zd <- read_xpt("Y:/Simon_Couillard/ORACLE/LEBRI_LUTE-VERSE/LEBRI_LUTE-VERSE/ADaM_KGAU_placebo/zd.xpt")

############################################################################################################
#' [New variables]
############################################################################################################


alb$Airborne_allergen_sensitisation_on_testing <- ifelse(  (alb$LBTESTCD == "CATDIGE" & alb$AVAL >= 0.7) | 
                                                             (alb$LBTESTCD == "DERIGE" & alb$AVAL >= 0.7) | 
                                                             (alb$LBTESTCD == "DPTIGE" & alb$AVAL >= 0.7) | 
                                                             (alb$LBTESTCD == "AFIGE" & alb$AVAL >= 0.7) | 
                                                             (alb$LBTESTCD == "ATIGE" & alb$AVAL >= 0.7),1,
                                                           ifelse(  (alb$LBTESTCD == "CATDIGE" & alb$AVAL < 0.7) | 
                                                                      (alb$LBTESTCD == "DERIGE" & alb$AVAL < 0.7) | 
                                                                      (alb$LBTESTCD == "DPTIGE" & alb$AVAL < 0.7) | 
                                                                      (alb$LBTESTCD == "AFIGE" & alb$AVAL < 0.7) | 
                                                                      (alb$LBTESTCD == "ATIGE" & alb$AVAL < 0.7),0,NA            )
                                                                 ) 


alb2 <- alb %>%
  group_by(USUBJID) %>%
  summarise(Airborne_allergen_sensitisation_on_testing = ifelse( sum(Airborne_allergen_sensitisation_on_testing,na.rm=T) > 0,1,0   )  )


asl$BMI <- (asl$BWT)/( (asl$BHT/100)^2) 

asl$Treatment_step <- ifelse(asl$BLICSLAB == ">= 1000 ug/day",5,4)

asl$Any_severe_attack_previous_12m <- ifelse(asl$ASTEXHX == "0",0,1)

amh$Psychiatric_disease <- ifelse(  (amh$MHHLGT == "ANXIETY DISORDERS AND SYMPTOMS" | amh$MHHLGT == "COGNITIVE AND ATTENTION DEFICIT DISORDERS AND DISTURBANCES" | 
                                       amh$MHHLGT == "MANIC AND BIPOLAR MOOD DISORDERS AND DISTURBANCES" | amh$MHHLGT == "DEPRESSIVE MOOD DISORDERS AND DISTURBANCES"
                                        ) & ( amh$MHDISTAT == "ONGOING WITH TREATMENT" | amh$MHDISTAT == "ONGOING WITHOUT TREATMENT" ) ,1,0)


amh$Psy_disease_type <- ifelse(  (amh$MHHLGT == "ANXIETY DISORDERS AND SYMPTOMS" | amh$MHHLGT == "DEPRESSIVE MOOD DISORDERS AND DISTURBANCES") ,1,
                                 ifelse( amh$MHHLGT == "MANIC AND BIPOLAR MOOD DISORDERS AND DISTURBANCES" | amh$MHHLGT == "COGNITIVE AND ATTENTION DEFICIT DISORDERS AND DISTURBANCES",4,0     )   )






amh$Atopy_history <- ifelse(  (amh$MHDECOD == "RHINITIS ALLERGIC" | amh$MHDECOD == "ECZEMA" | amh$MHDECOD == "DERMATITIS ATOPIC" | amh$MHLLT == "FOOD ALLERGY" ) & 
                                  ( amh$MHDISTAT == "ONGOING WITH TREATMENT" | amh$MHDISTAT == "ONGOING WITHOUT TREATMENT" )   , 1,0
)



amh$Eczema <- ifelse(  ((amh$MHDECOD == "DERMATITIS ATOPIC" | amh$MHDECOD == "ECZEMA") & ( amh$MHDISTAT == "ONGOING WITH TREATMENT" | amh$MHDISTAT == "ONGOING WITHOUT TREATMENT" )), 1,0)


amh$AllergicRhinitis <- ifelse(  ((amh$MHDECOD == "RHINITIS ALLERGIC") & ( amh$MHDISTAT == "ONGOING WITH TREATMENT" | amh$MHDISTAT == "ONGOING WITHOUT TREATMENT" )), 1,0)


amh$Chronic_Rhinosinusitis <- ifelse(  ((amh$MHDECOD == "CHRONIC SINUSITIS") & ( amh$MHDISTAT == "ONGOING WITH TREATMENT" | amh$MHDISTAT == "ONGOING WITHOUT TREATMENT" )), 1,0)



amh$Nasal_polyposis <- ifelse((amh$MHDECOD == "NASAL POLYPS" | amh$MHDECOD == "SINUS POLYP") & ( amh$MHDISTAT == "ONGOING WITH TREATMENT" | amh$MHDISTAT == "ONGOING WITHOUT TREATMENT" ), 1,0)



amh2 <- amh %>%
  group_by(USUBJID) %>%
  summarise(Psychiatric_disease = ifelse( sum(Psychiatric_disease,na.rm=T) > 0,1,0   ),
            Psy_disease_type = max(Psy_disease_type, na.rm = T),
            Atopy_history = ifelse( sum(Atopy_history,na.rm=T) > 0,1,0   ),
            Eczema = ifelse( sum(Eczema,na.rm=T) > 0,1,0   ),
            AllergicRhinitis = ifelse( sum(AllergicRhinitis,na.rm=T) > 0,1,0   ),
            Chronic_Rhinosinusitis = ifelse( sum(Chronic_Rhinosinusitis,na.rm=T) > 0,1,0   ),
            Nasal_polyposis = ifelse( sum(Nasal_polyposis,na.rm=T) > 0,1,0   )  )


asl$Adherence_PreTrial_quality <- ifelse(asl$ADHERPC >= 70,1,0)



cm2 <- cm  %>%
  filter(CMTRT == "RESCUE MEDICATION" &  EPOCH == "SCREENING") %>%
  group_by(USUBJID) %>%
  summarise( SOMME =  sum(CMDOSE, na.rm= T)  ,
             DENOM =  abs(min(CMENDY,na.rm=T)) ,
              SABA_actuations_per_day_average_PreTrial = SOMME/DENOM )


cm3 <- cm  %>%
  filter(CMTRT == "RESCUE MEDICATION" &  EPOCH == "TREATMENT") %>%
  group_by(USUBJID) %>%
  summarise( SOMME =  sum(CMDOSE, na.rm= T)  ,
             DENOM =  max(CMENDY,na.rm=T) ,
             SABA_actuations_per_day_average_InTrial = SOMME/DENOM )


cm$Intranasal_seroid_prescribed <- ifelse(  ((cm$CMDOSU == "SPRAY" | cm$CMROUTE == "NASAL") & (  cm$CMENRTPT == "ONGOING") & (cm$CMCLAS == "STEROIDS")   ), 1,0)


cm4 <- cm %>%
  group_by(USUBJID) %>%
  summarise(Intranasal_seroid_prescribed = ifelse( sum(Intranasal_seroid_prescribed,na.rm=T) > 0,1,0   ))


zd1 <- zd %>%
  filter( ZDTESTCD == "FVC" & ZDTPT == "PRE-DOSE" & ZDSTRESU == "L" & EPOCH == "SCREENING" ) %>%
  group_by(USUBJID) %>%
  summarise(FVC_preBD_L_Baseline = max( ZDSTRESN,na.rm=T)     )

#zd2 <- zd %>%
#  filter( ZDTESTCD == "FVC" & ZDTPT == "PRE-DOSE" & ZDSTRESU == "%" & EPOCH == "SCREENING" ) %>%
#  group_by(USUBJID) %>%
#  summarise(FVC_preBD_PCT_Baseline = max( ZDSTRESN,na.rm=T)     )

zd3 <- zd %>%
  filter( ZDTESTCD == "FEV1" & ZDTPT == "POST-DOSE" & ZDSTRESU == "L" & EPOCH == "SCREENING" ) %>%
  group_by(USUBJID) %>%
  summarise(FEV1_postBD_L_Baseline = max( ZDSTRESN,na.rm=T)     )

#zd4 <- zd %>%
#  filter( ZDTESTCD == "FEV1" & ZDTPT == "POST-DOSE" & ZDSTRESU == "%" & EPOCH == "SCREENING" ) %>%
#  group_by(USUBJID) %>%
#  summarise(FEV1_postBD_PCT_Baseline = max( ZDSTRESN,na.rm=T)     )

zd5 <- zd %>%
  filter( ZDTESTCD == "FVC" & ZDTPT == "POST-DOSE" & ZDSTRESU == "L" & EPOCH == "SCREENING" ) %>%
  group_by(USUBJID) %>%
  summarise(FVC_postBD_L_Baseline = max( ZDSTRESN,na.rm=T)     )

#zd6 <- zd %>%
#  filter( ZDTESTCD == "FVC" & ZDTPT == "POST-DOSE" & ZDSTRESU == "%" & EPOCH == "SCREENING" ) %>%
#  group_by(USUBJID) %>%
#  summarise(FVC_postBD_PCT_Baseline = max( ZDSTRESN,na.rm=T)     )


qs1 <- qs %>%
  filter(VISITNUM == 3 & QSTESTCD == "QS00201")%>%
  dplyr::select(c(3,10))

qs2 <- qs %>%
  filter(VISITNUM == 3 & QSTESTCD == "QS00202")%>%
  dplyr::select(c(3,10))

qs3 <- qs %>%
  filter(VISITNUM == 3 & QSTESTCD == "QS00203")%>%
  dplyr::select(c(3,10))

qs4 <- qs %>%
  filter(VISITNUM == 3 & QSTESTCD == "QS00204")%>%
  dplyr::select(c(3,10))

qs5 <- qs %>%
  filter(VISITNUM == 3 & QSTESTCD == "QS00205")%>%
  dplyr::select(c(3,10))


qs1 <- qs1 %>%
  rename( ACQ_baseline_score_item1_sleepawakenings = QSSTRESC   )

qs2 <- qs2 %>%
  rename( ACQ_baseline_score_item2_morningsymptoms = QSSTRESC    )

qs3 <- qs3 %>%
  rename( ACQ_baseline_score_item3_activitylimitation = QSSTRESC  )

qs4 <- qs4 %>%
  rename( ACQ_baseline_score_item4_dyspnea = QSSTRESC  )

qs5 <- qs5 %>%
  rename( ACQ_baseline_score_item5_wheezing = QSSTRESC  )

qs6 <- DataSet <- merge(qs1,qs2, by = "USUBJID", all.x = T)

qs6 <- DataSet <- merge(qs6,qs3, by = "USUBJID", all.x = T)				

qs6 <- DataSet <- merge(qs6,qs4, by = "USUBJID", all.x = T)	

qs6 <- DataSet <- merge(qs6,qs5, by = "USUBJID", all.x = T)	

rm(qs1,qs2,qs3,qs4,qs5)

qs6$ACQ_baseline_score_item1_sleepawakenings <- as.numeric(qs6$ACQ_baseline_score_item1_sleepawakenings)
qs6$ACQ_baseline_score_item2_morningsymptoms <- as.numeric(qs6$ACQ_baseline_score_item2_morningsymptoms)
qs6$ACQ_baseline_score_item3_activitylimitation <- as.numeric(qs6$ACQ_baseline_score_item3_activitylimitation)
qs6$ACQ_baseline_score_item4_dyspnea <- as.numeric(qs6$ACQ_baseline_score_item4_dyspnea)
qs6$ACQ_baseline_score_item5_wheezing <- as.numeric(qs6$ACQ_baseline_score_item5_wheezing)

qs6$ACQ_baseline_score_item1_sleepawakenings <- ifelse(qs6$ACQ_baseline_score_item1_sleepawakenings == 9,NA,qs6$ACQ_baseline_score_item1_sleepawakenings   )
qs6$ACQ_baseline_score_item2_morningsymptoms <- ifelse(qs6$ACQ_baseline_score_item2_morningsymptoms == 9,NA,qs6$ACQ_baseline_score_item2_morningsymptoms   )
qs6$ACQ_baseline_score_item3_activitylimitation <- ifelse(qs6$ACQ_baseline_score_item3_activitylimitation == 9,NA,qs6$ACQ_baseline_score_item3_activitylimitation   )
qs6$ACQ_baseline_score_item4_dyspnea <- ifelse(qs6$ACQ_baseline_score_item4_dyspnea == 9,NA,qs6$ACQ_baseline_score_item4_dyspnea   )
qs6$ACQ_baseline_score_item5_wheezing <- ifelse(qs6$ACQ_baseline_score_item5_wheezing == 9,NA,qs6$ACQ_baseline_score_item5_wheezing   )


qs6 <- qs6 %>%
  group_by(USUBJID) %>%
  mutate(  ACQ_baseline_score_mean = sum(ACQ_baseline_score_item1_sleepawakenings, ACQ_baseline_score_item2_morningsymptoms,
                                            ACQ_baseline_score_item3_activitylimitation,ACQ_baseline_score_item4_dyspnea,
                                            ACQ_baseline_score_item5_wheezing,na.rm=F )/5     )


asl$Follow_up_duration_days <- asl$YEARSPC*365.25 


asl$EXFDTPC

asl$RANDDT


asl$EXFDTPC <- as.POSIXct(asl$EXFDTPC, format = '%Y-%m-%d') 
asl$RANDDT <- as.POSIXct(asl$RANDDT, format = '%Y-%m-%d') 

asl$Time_to_First_attack <- as.numeric(difftime(asl$EXFDTPC,asl$RANDDT, units = "days"))

asl$EndFollowUp_Reason <- ifelse( asl$TXDRS == "SUBJECT DECISION" | asl$TXDRS == "STUDY TERMINATED BY SPONSOR",2,4   ) 

############################################################################################################
#' [Extracting data]
############################################################################################################

DataSet <- asl[,c(2,4,6,75,7)]

DataSet$Sequential_number <- as.numeric(NA)

DataSet$Enrolled_Trial_name <- "LUTE"

DataSet$Treatment_arm <- "PLACEBO"

DataSet <- DataSet[,c(1,6,7,8,2,3,4,5)]

DataSet$Country <- "USA"

DataSet <- merge(DataSet,asl[,c(2,76,77,47)], by = "USUBJID", all.x = T)

DataSet$Number_hospitalisations_for_asthma_previous_12_months <- as.numeric(NA)

DataSet$Previous_ICU <- as.numeric(NA)

DataSet$Previous_Intubation <- as.numeric(NA)

DataSet$Smoking <- as.numeric(NA)

DataSet$Pack_years <- as.numeric(NA)

DataSet <- merge(DataSet,amh2[,c(1,2,3,4,5,6)], by = "USUBJID", all.x = T)

DataSet <- merge(DataSet,alb2[,c(1,2)], by = "USUBJID", all.x = T)

DataSet <- merge(DataSet,amh2[,c(1,7,8)], by = "USUBJID", all.x = T)

DataSet$Previous_nasal_polypectomy <- as.numeric(NA)

DataSet <- merge(DataSet,asl[,c(2,72,78)], by = "USUBJID", all.x = T)

DataSet$Adherence_InTrial_quantity <- as.numeric(NA)

DataSet$Adherence_InTrial_quality <- as.numeric(NA)

DataSet <- merge(DataSet,cm2[,c(1,4)], by = "USUBJID", all.x = T)

DataSet$SABA_prescribed <- 1

DataSet <- merge(DataSet,cm3[,c(1,4)], by = "USUBJID", all.x = T)

DataSet <- merge(DataSet,asl[,c(2,23)], by = "USUBJID", all.x = T)

DataSet$ICS_TYPE <- "FP"

DataSet <- merge(DataSet,asl[,c(2,45,24,25)], by = "USUBJID", all.x = T)

DataSet$maintenance_OCS_prescribed <- 0

DataSet$Mainteance_OCS_dose <- 0

DataSet <- merge(DataSet,asl[,c(2,26,27)], by = "USUBJID", all.x = T)

DataSet <- merge(DataSet,cm4[,c(1,2)], by = "USUBJID", all.x = T)

DataSet$FEV1_predicted_L <- as.numeric(NA)

DataSet$FVC_predicted_L <- as.numeric(NA)

DataSet <- merge(DataSet,asl[,c(2,38,37)], by = "USUBJID", all.x = T)

DataSet <- merge(DataSet,zd1[,c(1,2)], by = "USUBJID", all.x = T)

DataSet$FVC_preBD_PCT_Baseline <- as.numeric(NA)

DataSet <- merge(DataSet,zd3[,c(1,2)], by = "USUBJID", all.x = T)

DataSet$FEV1_postBD_PCT_Baseline <- as.numeric(NA)

DataSet <- merge(DataSet,zd5[,c(1,2)], by = "USUBJID", all.x = T)

DataSet$FVC_postBD_PCT_Baseline <- as.numeric(NA)

DataSet <- merge(DataSet,asl[,c(2,36)], by = "USUBJID", all.x = T)

DataSet <- merge(DataSet,qs6[,c(1,7,2,3,4,5,6)], by = "USUBJID", all.x = T)

DataSet$ACQ_baseline_score_item6_RelieverUse <- as.numeric(NA)

DataSet$ACQ_baseline_score_item7_FEV1 <- as.numeric(NA)

DataSet$ACT_baseline_score <- as.numeric(NA)

DataSet <- merge(DataSet,asl[,c(2,42,41,44,79,54,80)], by = "USUBJID", all.x = T)

DataSet$Time_to_2n_attack <- as.numeric(NA)
DataSet$Time_to_3n_attack <- as.numeric(NA)
DataSet$Time_to_4n_attack <- as.numeric(NA)
DataSet$Time_to_5n_attack <- as.numeric(NA)

DataSet <- merge(DataSet,asl[,c(2,81)], by = "USUBJID", all.x = T)

DataSet$FEV1PREBD_L_52W <- as.numeric(NA)
DataSet$FEV1PREBD_PCT_52W <- as.numeric(NA)
DataSet$FEV1POSTBD_L_52W <- as.numeric(NA)
DataSet$FEV1POSTBD_PCT_52W <- as.numeric(NA)

DataSet <- DataSet[,c(2,1,3:78)]

DataSet <- DataSet %>%
  rename( Subject_ID = USUBJID,
          Age = AGE,
          Gender_M = SEX,
          Ethnicity = RACE, 
          Number_severe_attack_previous_12m = ASTEXHX,
          Adherence_PreTrial_quantity = ADHERPC,
          Any_ICS_prescribed = BLICS,
          ICS_Dose_PER_DAY = ICSEQ,
          LABA_prescribed = BLLABA,
          LAMA_prescribed = BLLAMA,
          Montelukast_prescribed = BLLTRA,
          Theophylline_prescribed = BLTHEO,
          FEV1_preBD_L_Baseline = FEV1B,
          FEV1_preBD_PCT_Baseline = FEV1PPD1,
          FEV1_PCT_reversibility_postBD = FEV1RB,
          Blood_Eos_baseline_x10_9_cells_per_L = EOSB,
          FeNO_baseline_ppb = FENOB,
          Total_IgE = IGEB,
          Number_severe_asthma_attacks_during_followup = NUMEXPC)


DataSet$Any_ICS_prescribed <-   ifelse(DataSet$Any_ICS_prescribed == "Y", 1,0)

DataSet$LABA_prescribed <-   ifelse(DataSet$LABA_prescribed == "Y", 1,0)

DataSet$LAMA_prescribed <-   ifelse(DataSet$LAMA_prescribed == "Y", 1,0)

DataSet$Montelukast_prescribed <-   ifelse(DataSet$Montelukast_prescribed == "Y", 1,0)

DataSet$Theophylline_prescribed <-   ifelse(DataSet$Theophylline_prescribed == "Y", 1,0)


DataSet$FEV1_postBD_PCT_Baseline <- ((DataSet$FEV1_postBD_L_Baseline * DataSet$FEV1_preBD_PCT_Baseline)/DataSet$FEV1_preBD_L_Baseline)

DataSet$Time_to_First_attack <- ifelse(DataSet$Number_severe_asthma_attacks_during_followup == 0 , NA, DataSet$Time_to_First_attack )

DataSet$Gender_M <- ifelse( DataSet$Gender_M == "M", 1, ifelse( DataSet$Gender_M == "F", 0 ,NA   ) )

write.xlsx(DataSet,"LUTE_clean.xlsx")

###########################################################################################################
#' * PART 2 : KGAV*
###########################################################################################################


############################################################################################################
#' [Data import]
############################################################################################################

aae <- read_xpt("Y:/Simon_Couillard/ORACLE/LEBRI_LUTE-VERSE/LEBRI_LUTE-VERSE/ADaM_KGAV_placebo/aae.xpt")
acm <- read_xpt("Y:/Simon_Couillard/ORACLE/LEBRI_LUTE-VERSE/LEBRI_LUTE-VERSE/ADaM_KGAV_placebo/acm.xpt")
adv <- read_xpt("Y:/Simon_Couillard/ORACLE/LEBRI_LUTE-VERSE/LEBRI_LUTE-VERSE/ADaM_KGAV_placebo/adv.xpt")
aeg <- read_xpt("Y:/Simon_Couillard/ORACLE/LEBRI_LUTE-VERSE/LEBRI_LUTE-VERSE/ADaM_KGAV_placebo/aeg.xpt")
alb <- read_xpt("Y:/Simon_Couillard/ORACLE/LEBRI_LUTE-VERSE/LEBRI_LUTE-VERSE/ADaM_KGAV_placebo/alb.xpt")
amh <- read_xpt("Y:/Simon_Couillard/ORACLE/LEBRI_LUTE-VERSE/LEBRI_LUTE-VERSE/ADaM_KGAV_placebo/amh.xpt")
apd <- read_xpt("Y:/Simon_Couillard/ORACLE/LEBRI_LUTE-VERSE/LEBRI_LUTE-VERSE/ADaM_KGAV_placebo/apd.xpt")
aqs <- read_xpt("Y:/Simon_Couillard/ORACLE/LEBRI_LUTE-VERSE/LEBRI_LUTE-VERSE/ADaM_KGAV_placebo/aqs.xpt")
asl <- read_xpt("Y:/Simon_Couillard/ORACLE/LEBRI_LUTE-VERSE/LEBRI_LUTE-VERSE/ADaM_KGAV_placebo/asl.xpt")
asm <- read_xpt("Y:/Simon_Couillard/ORACLE/LEBRI_LUTE-VERSE/LEBRI_LUTE-VERSE/ADaM_KGAV_placebo/asm.xpt")
asp <- read_xpt("Y:/Simon_Couillard/ORACLE/LEBRI_LUTE-VERSE/LEBRI_LUTE-VERSE/ADaM_KGAV_placebo/asp.xpt")
avs <- read_xpt("Y:/Simon_Couillard/ORACLE/LEBRI_LUTE-VERSE/LEBRI_LUTE-VERSE/ADaM_KGAV_placebo/avs.xpt")
cm <- read_xpt("Y:/Simon_Couillard/ORACLE/LEBRI_LUTE-VERSE/LEBRI_LUTE-VERSE/ADaM_KGAV_placebo/cm.xpt")
qs <- read_xpt("Y:/Simon_Couillard/ORACLE/LEBRI_LUTE-VERSE/LEBRI_LUTE-VERSE/ADaM_KGAV_placebo/qs.xpt")
zd <- read_xpt("Y:/Simon_Couillard/ORACLE/LEBRI_LUTE-VERSE/LEBRI_LUTE-VERSE/ADaM_KGAV_placebo/zd.xpt")


############################################################################################################
#' [New variables]
############################################################################################################


alb$Airborne_allergen_sensitisation_on_testing <- ifelse(  (alb$LBTESTCD == "CATDIGE" & alb$AVAL >= 0.7) | 
                                                             (alb$LBTESTCD == "DERIGE" & alb$AVAL >= 0.7) | 
                                                             (alb$LBTESTCD == "DPTIGE" & alb$AVAL >= 0.7) | 
                                                             (alb$LBTESTCD == "AFIGE" & alb$AVAL >= 0.7) | 
                                                             (alb$LBTESTCD == "ATIGE" & alb$AVAL >= 0.7),1,
                                                           ifelse(  (alb$LBTESTCD == "CATDIGE" & alb$AVAL < 0.7) | 
                                                                      (alb$LBTESTCD == "DERIGE" & alb$AVAL < 0.7) | 
                                                                      (alb$LBTESTCD == "DPTIGE" & alb$AVAL < 0.7) | 
                                                                      (alb$LBTESTCD == "AFIGE" & alb$AVAL < 0.7) | 
                                                                      (alb$LBTESTCD == "ATIGE" & alb$AVAL < 0.7),0,NA            )
) 


alb2 <- alb %>%
  group_by(USUBJID) %>%
  summarise(Airborne_allergen_sensitisation_on_testing = ifelse( sum(Airborne_allergen_sensitisation_on_testing,na.rm=T) > 0,1,0   )  )


asl$BMI <- (asl$BWT)/( (asl$BHT/100)^2) 

asl$Treatment_step <- ifelse(asl$BLICSLAB == ">= 1000 ug/day",5,4)

asl$Any_severe_attack_previous_12m <- ifelse(asl$ASTEXHX == "0",0,1)

amh$Psychiatric_disease <- ifelse(  (amh$MHHLGT == "ANXIETY DISORDERS AND SYMPTOMS" | amh$MHHLGT == "COGNITIVE AND ATTENTION DEFICIT DISORDERS AND DISTURBANCES" | 
                                       amh$MHHLGT == "MANIC AND BIPOLAR MOOD DISORDERS AND DISTURBANCES" | amh$MHHLGT == "DEPRESSIVE MOOD DISORDERS AND DISTURBANCES"
) & ( amh$MHDISTAT == "ONGOING WITH TREATMENT" | amh$MHDISTAT == "ONGOING WITHOUT TREATMENT" ) ,1,0)


amh$Psy_disease_type <- ifelse(  (amh$MHHLGT == "ANXIETY DISORDERS AND SYMPTOMS" | amh$MHHLGT == "DEPRESSIVE MOOD DISORDERS AND DISTURBANCES") ,1,
                                 ifelse( amh$MHHLGT == "MANIC AND BIPOLAR MOOD DISORDERS AND DISTURBANCES" | amh$MHHLGT == "COGNITIVE AND ATTENTION DEFICIT DISORDERS AND DISTURBANCES",4,0     )   )






amh$Atopy_history <- ifelse(  (amh$MHDECOD == "RHINITIS ALLERGIC" | amh$MHDECOD == "ECZEMA" | amh$MHDECOD == "DERMATITIS ATOPIC" | amh$MHLLT == "FOOD ALLERGY" ) & 
                                ( amh$MHDISTAT == "ONGOING WITH TREATMENT" | amh$MHDISTAT == "ONGOING WITHOUT TREATMENT" )   , 1,0
)



amh$Eczema <- ifelse(  ((amh$MHDECOD == "DERMATITIS ATOPIC" | amh$MHDECOD == "ECZEMA") & ( amh$MHDISTAT == "ONGOING WITH TREATMENT" | amh$MHDISTAT == "ONGOING WITHOUT TREATMENT" )), 1,0)


amh$AllergicRhinitis <- ifelse(  ((amh$MHDECOD == "RHINITIS ALLERGIC") & ( amh$MHDISTAT == "ONGOING WITH TREATMENT" | amh$MHDISTAT == "ONGOING WITHOUT TREATMENT" )), 1,0)


amh$Chronic_Rhinosinusitis <- ifelse(  ((amh$MHDECOD == "CHRONIC SINUSITIS") & ( amh$MHDISTAT == "ONGOING WITH TREATMENT" | amh$MHDISTAT == "ONGOING WITHOUT TREATMENT" )), 1,0)



amh$Nasal_polyposis <- ifelse((amh$MHDECOD == "NASAL POLYPS" | amh$MHDECOD == "SINUS POLYP") & ( amh$MHDISTAT == "ONGOING WITH TREATMENT" | amh$MHDISTAT == "ONGOING WITHOUT TREATMENT" ), 1,0)



amh2 <- amh %>%
  group_by(USUBJID) %>%
  summarise(Psychiatric_disease = ifelse( sum(Psychiatric_disease,na.rm=T) > 0,1,0   ),
            Psy_disease_type = max(Psy_disease_type, na.rm = T),
            Atopy_history = ifelse( sum(Atopy_history,na.rm=T) > 0,1,0   ),
            Eczema = ifelse( sum(Eczema,na.rm=T) > 0,1,0   ),
            AllergicRhinitis = ifelse( sum(AllergicRhinitis,na.rm=T) > 0,1,0   ),
            Chronic_Rhinosinusitis = ifelse( sum(Chronic_Rhinosinusitis,na.rm=T) > 0,1,0   ),
            Nasal_polyposis = ifelse( sum(Nasal_polyposis,na.rm=T) > 0,1,0   )  )


asl$Adherence_PreTrial_quality <- ifelse(asl$ADHERPC >= 70,1,0)



cm2 <- cm  %>%
  filter(CMTRT == "RESCUE MEDICATION" &  EPOCH == "SCREENING") %>%
  group_by(USUBJID) %>%
  summarise( SOMME =  sum(CMDOSE, na.rm= T)  ,
             DENOM =  abs(min(CMENDY,na.rm=T)) ,
             SABA_actuations_per_day_average_PreTrial = SOMME/DENOM )


cm3 <- cm  %>%
  filter(CMTRT == "RESCUE MEDICATION" &  EPOCH == "TREATMENT") %>%
  group_by(USUBJID) %>%
  summarise( SOMME =  sum(CMDOSE, na.rm= T)  ,
             DENOM =  max(CMENDY,na.rm=T) ,
             SABA_actuations_per_day_average_InTrial = SOMME/DENOM )


cm$Intranasal_seroid_prescribed <- ifelse(  ((cm$CMDOSU == "SPRAY" | cm$CMROUTE == "NASAL") & (  cm$CMENRTPT == "ONGOING") & (cm$CMCLAS == "STEROIDS")   ), 1,0)


cm4 <- cm %>%
  group_by(USUBJID) %>%
  summarise(Intranasal_seroid_prescribed = ifelse( sum(Intranasal_seroid_prescribed,na.rm=T) > 0,1,0   ))


zd1 <- zd %>%
  filter( ZDTESTCD == "FVC" & ZDTPT == "PRE-DOSE" & ZDSTRESU == "L" & EPOCH == "SCREENING" ) %>%
  group_by(USUBJID) %>%
  summarise(FVC_preBD_L_Baseline = max( ZDSTRESN,na.rm=T)     )

#zd2 <- zd %>%
#  filter( ZDTESTCD == "FVC" & ZDTPT == "PRE-DOSE" & ZDSTRESU == "%" & EPOCH == "SCREENING" ) %>%
#  group_by(USUBJID) %>%
#  summarise(FVC_preBD_PCT_Baseline = max( ZDSTRESN,na.rm=T)     )

zd3 <- zd %>%
  filter( ZDTESTCD == "FEV1" & ZDTPT == "POST-DOSE" & ZDSTRESU == "L" & EPOCH == "SCREENING" ) %>%
  group_by(USUBJID) %>%
  summarise(FEV1_postBD_L_Baseline = max( ZDSTRESN,na.rm=T)     )

#zd4 <- zd %>%
#  filter( ZDTESTCD == "FEV1" & ZDTPT == "POST-DOSE" & ZDSTRESU == "%" & EPOCH == "SCREENING" ) %>%
#  group_by(USUBJID) %>%
#  summarise(FEV1_postBD_PCT_Baseline = max( ZDSTRESN,na.rm=T)     )

zd5 <- zd %>%
  filter( ZDTESTCD == "FVC" & ZDTPT == "POST-DOSE" & ZDSTRESU == "L" & EPOCH == "SCREENING" ) %>%
  group_by(USUBJID) %>%
  summarise(FVC_postBD_L_Baseline = max( ZDSTRESN,na.rm=T)     )

#zd6 <- zd %>%
#  filter( ZDTESTCD == "FVC" & ZDTPT == "POST-DOSE" & ZDSTRESU == "%" & EPOCH == "SCREENING" ) %>%
#  group_by(USUBJID) %>%
#  summarise(FVC_postBD_PCT_Baseline = max( ZDSTRESN,na.rm=T)     )


qs1 <- qs %>%
  filter(VISITNUM == 3 & QSTESTCD == "QS00201")%>%
  dplyr::select(c(3,10))

qs2 <- qs %>%
  filter(VISITNUM == 3 & QSTESTCD == "QS00202")%>%
  dplyr::select(c(3,10))

qs3 <- qs %>%
  filter(VISITNUM == 3 & QSTESTCD == "QS00203")%>%
  dplyr::select(c(3,10))

qs4 <- qs %>%
  filter(VISITNUM == 3 & QSTESTCD == "QS00204")%>%
  dplyr::select(c(3,10))

qs5 <- qs %>%
  filter(VISITNUM == 3 & QSTESTCD == "QS00205")%>%
  dplyr::select(c(3,10))


qs1 <- qs1 %>%
  rename( ACQ_baseline_score_item1_sleepawakenings = QSSTRESC   )

qs2 <- qs2 %>%
  rename( ACQ_baseline_score_item2_morningsymptoms = QSSTRESC    )

qs3 <- qs3 %>%
  rename( ACQ_baseline_score_item3_activitylimitation = QSSTRESC  )

qs4 <- qs4 %>%
  rename( ACQ_baseline_score_item4_dyspnea = QSSTRESC  )

qs5 <- qs5 %>%
  rename( ACQ_baseline_score_item5_wheezing = QSSTRESC  )

qs6 <- DataSet <- merge(qs1,qs2, by = "USUBJID", all.x = T)

qs6 <- DataSet <- merge(qs6,qs3, by = "USUBJID", all.x = T)				

qs6 <- DataSet <- merge(qs6,qs4, by = "USUBJID", all.x = T)	

qs6 <- DataSet <- merge(qs6,qs5, by = "USUBJID", all.x = T)	

rm(qs1,qs2,qs3,qs4,qs5)

qs6$ACQ_baseline_score_item1_sleepawakenings <- as.numeric(qs6$ACQ_baseline_score_item1_sleepawakenings)
qs6$ACQ_baseline_score_item2_morningsymptoms <- as.numeric(qs6$ACQ_baseline_score_item2_morningsymptoms)
qs6$ACQ_baseline_score_item3_activitylimitation <- as.numeric(qs6$ACQ_baseline_score_item3_activitylimitation)
qs6$ACQ_baseline_score_item4_dyspnea <- as.numeric(qs6$ACQ_baseline_score_item4_dyspnea)
qs6$ACQ_baseline_score_item5_wheezing <- as.numeric(qs6$ACQ_baseline_score_item5_wheezing)

qs6$ACQ_baseline_score_item1_sleepawakenings <- ifelse(qs6$ACQ_baseline_score_item1_sleepawakenings == 9,NA,qs6$ACQ_baseline_score_item1_sleepawakenings   )
qs6$ACQ_baseline_score_item2_morningsymptoms <- ifelse(qs6$ACQ_baseline_score_item2_morningsymptoms == 9,NA,qs6$ACQ_baseline_score_item2_morningsymptoms   )
qs6$ACQ_baseline_score_item3_activitylimitation <- ifelse(qs6$ACQ_baseline_score_item3_activitylimitation == 9,NA,qs6$ACQ_baseline_score_item3_activitylimitation   )
qs6$ACQ_baseline_score_item4_dyspnea <- ifelse(qs6$ACQ_baseline_score_item4_dyspnea == 9,NA,qs6$ACQ_baseline_score_item4_dyspnea   )
qs6$ACQ_baseline_score_item5_wheezing <- ifelse(qs6$ACQ_baseline_score_item5_wheezing == 9,NA,qs6$ACQ_baseline_score_item5_wheezing   )


qs6 <- qs6 %>%
  group_by(USUBJID) %>%
  mutate(  ACQ_baseline_score_mean = sum(ACQ_baseline_score_item1_sleepawakenings, ACQ_baseline_score_item2_morningsymptoms,
                                         ACQ_baseline_score_item3_activitylimitation,ACQ_baseline_score_item4_dyspnea,
                                         ACQ_baseline_score_item5_wheezing,na.rm=F )/5     )


asl$Follow_up_duration_days <- asl$YEARSPC*365.25 


asl$EXFDTPC

asl$RANDDT


asl$EXFDTPC <- as.POSIXct(asl$EXFDTPC, format = '%Y-%m-%d') 
asl$RANDDT <- as.POSIXct(asl$RANDDT, format = '%Y-%m-%d') 

asl$Time_to_First_attack <- as.numeric(difftime(asl$EXFDTPC,asl$RANDDT, units = "days"))

asl$EndFollowUp_Reason <- ifelse( asl$TXDRS == "SUBJECT DECISION" | asl$TXDRS == "STUDY TERMINATED BY SPONSOR",2,4   ) 



############################################################################################################
#' [Extracting data]
############################################################################################################

DataSet <- asl[,c(2,4,6,75,7)]

DataSet$Sequential_number <- as.numeric(NA)

DataSet$Enrolled_Trial_name <- "VERSE"

DataSet$Treatment_arm <- "PLACEBO"

DataSet <- DataSet[,c(1,6,7,8,2,3,4,5)]

DataSet$Country <- "USA"

DataSet <- merge(DataSet,asl[,c(2,76,77,47)], by = "USUBJID", all.x = T)

DataSet$Number_hospitalisations_for_asthma_previous_12_months <- as.numeric(NA)

DataSet$Previous_ICU <- as.numeric(NA)

DataSet$Previous_Intubation <- as.numeric(NA)

DataSet$Smoking <- as.numeric(NA)

DataSet$Pack_years <- as.numeric(NA)

DataSet <- merge(DataSet,amh2[,c(1,2,3,4,5,6)], by = "USUBJID", all.x = T)

DataSet <- merge(DataSet,alb2[,c(1,2)], by = "USUBJID", all.x = T)

DataSet <- merge(DataSet,amh2[,c(1,7,8)], by = "USUBJID", all.x = T)

DataSet$Previous_nasal_polypectomy <- as.numeric(NA)

DataSet <- merge(DataSet,asl[,c(2,72,78)], by = "USUBJID", all.x = T)

DataSet$Adherence_InTrial_quantity <- as.numeric(NA)

DataSet$Adherence_InTrial_quality <- as.numeric(NA)

DataSet <- merge(DataSet,cm2[,c(1,4)], by = "USUBJID", all.x = T)

DataSet$SABA_prescribed <- 1

DataSet <- merge(DataSet,cm3[,c(1,4)], by = "USUBJID", all.x = T)

DataSet <- merge(DataSet,asl[,c(2,23)], by = "USUBJID", all.x = T)

DataSet$ICS_TYPE <- "FP"

DataSet <- merge(DataSet,asl[,c(2,45,24,25)], by = "USUBJID", all.x = T)

DataSet$maintenance_OCS_prescribed <- 0

DataSet$Mainteance_OCS_dose <- 0

DataSet <- merge(DataSet,asl[,c(2,26,27)], by = "USUBJID", all.x = T)

DataSet <- merge(DataSet,cm4[,c(1,2)], by = "USUBJID", all.x = T)

DataSet$FEV1_predicted_L <- as.numeric(NA)

DataSet$FVC_predicted_L <- as.numeric(NA)

DataSet <- merge(DataSet,asl[,c(2,38,37)], by = "USUBJID", all.x = T)

DataSet <- merge(DataSet,zd1[,c(1,2)], by = "USUBJID", all.x = T)

DataSet$FVC_preBD_PCT_Baseline <- as.numeric(NA)

DataSet <- merge(DataSet,zd3[,c(1,2)], by = "USUBJID", all.x = T)

DataSet$FEV1_postBD_PCT_Baseline <- as.numeric(NA)

DataSet <- merge(DataSet,zd5[,c(1,2)], by = "USUBJID", all.x = T)

DataSet$FVC_postBD_PCT_Baseline <- as.numeric(NA)

DataSet <- merge(DataSet,asl[,c(2,36)], by = "USUBJID", all.x = T)

DataSet <- merge(DataSet,qs6[,c(1,7,2,3,4,5,6)], by = "USUBJID", all.x = T)

DataSet$ACQ_baseline_score_item6_RelieverUse <- as.numeric(NA)

DataSet$ACQ_baseline_score_item7_FEV1 <- as.numeric(NA)

DataSet$ACT_baseline_score <- as.numeric(NA)

DataSet <- merge(DataSet,asl[,c(2,42,41,44,79,54,80)], by = "USUBJID", all.x = T)

DataSet$Time_to_2n_attack <- as.numeric(NA)
DataSet$Time_to_3n_attack <- as.numeric(NA)
DataSet$Time_to_4n_attack <- as.numeric(NA)
DataSet$Time_to_5n_attack <- as.numeric(NA)

DataSet <- merge(DataSet,asl[,c(2,81)], by = "USUBJID", all.x = T)

DataSet$FEV1PREBD_L_52W <- as.numeric(NA)
DataSet$FEV1PREBD_PCT_52W <- as.numeric(NA)
DataSet$FEV1POSTBD_L_52W <- as.numeric(NA)
DataSet$FEV1POSTBD_PCT_52W <- as.numeric(NA)

DataSet <- DataSet[,c(2,1,3:78)]

DataSet <- DataSet %>%
  rename( Subject_ID = USUBJID,
          Age = AGE,
          Gender_M = SEX,
          Ethnicity = RACE, 
          Number_severe_attack_previous_12m = ASTEXHX,
          Adherence_PreTrial_quantity = ADHERPC,
          Any_ICS_prescribed = BLICS,
          ICS_Dose_PER_DAY = ICSEQ,
          LABA_prescribed = BLLABA,
          LAMA_prescribed = BLLAMA,
          Montelukast_prescribed = BLLTRA,
          Theophylline_prescribed = BLTHEO,
          FEV1_preBD_L_Baseline = FEV1B,
          FEV1_preBD_PCT_Baseline = FEV1PPD1,
          FEV1_PCT_reversibility_postBD = FEV1RB,
          Blood_Eos_baseline_x10_9_cells_per_L = EOSB,
          FeNO_baseline_ppb = FENOB,
          Total_IgE = IGEB,
          Number_severe_asthma_attacks_during_followup = NUMEXPC)


DataSet$Any_ICS_prescribed <-   ifelse(DataSet$Any_ICS_prescribed == "Y", 1,0)

DataSet$LABA_prescribed <-   ifelse(DataSet$LABA_prescribed == "Y", 1,0)

DataSet$LAMA_prescribed <-   ifelse(DataSet$LAMA_prescribed == "Y", 1,0)

DataSet$Montelukast_prescribed <-   ifelse(DataSet$Montelukast_prescribed == "Y", 1,0)

DataSet$Theophylline_prescribed <-   ifelse(DataSet$Theophylline_prescribed == "Y", 1,0)

DataSet$FEV1_postBD_PCT_Baseline <- ((DataSet$FEV1_postBD_L_Baseline * DataSet$FEV1_preBD_PCT_Baseline)/DataSet$FEV1_preBD_L_Baseline)

DataSet$Time_to_First_attack <- ifelse(DataSet$Number_severe_asthma_attacks_during_followup == 0 , NA, DataSet$Time_to_First_attack )

DataSet$Gender_M <- ifelse( DataSet$Gender_M == "M", 1, ifelse( DataSet$Gender_M == "F", 0 ,NA   ) )

write.xlsx(DataSet,"VERSE_clean.xlsx")
