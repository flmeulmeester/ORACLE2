

###########################################################################################################
#
# Project : Preparing data for BenraP2B
#
###########################################################################################################


###########################################################################################################
#' [ Working directory initialisation]
###########################################################################################################

setwd("Y:/Simon_Couillard/ORACLE/BenraP2B/BenraP2B/2023_07_10_Data_clean_BenraP2B")
getwd()

# Package importation

Packages <- c( "readxl","haven","ggplot2","dplyr","MASS", "summarytools", "gmodels",
               "jtools","car","openxlsx","extrafont","stargazer","readr")

lapply(Packages, library, character.only = TRUE)


#'*BenraP2B *

############################################################################################################
#' [Data import]
############################################################################################################

acq <- read_sas("Y:/Simon_Couillard/ORACLE/BenraP2B/BenraP2B/BenraP2B/Data/deid_acq0.sas7bdat")

ah <- read_sas("Y:/Simon_Couillard/ORACLE/BenraP2B/BenraP2B/BenraP2B/Data/deid_ah0.sas7bdat")

amed <- read_sas("Y:/Simon_Couillard/ORACLE/BenraP2B/BenraP2B/BenraP2B/Data/deid_amed0.sas7bdat")

asth <- read_sas("Y:/Simon_Couillard/ORACLE/BenraP2B/BenraP2B/BenraP2B/Data/deid_asth0.sas7bdat")

astht <- read_sas("Y:/Simon_Couillard/ORACLE/BenraP2B/BenraP2B/BenraP2B/Data/deid_astht0.sas7bdat")

basedis <- read_sas("Y:/Simon_Couillard/ORACLE/BenraP2B/BenraP2B/BenraP2B/Data/deid_basedis0.sas7bdat")

dm <- read_sas("Y:/Simon_Couillard/ORACLE/BenraP2B/BenraP2B/BenraP2B/Data/deid_dm0.sas7bdat")

ds <- read_sas("Y:/Simon_Couillard/ORACLE/BenraP2B/BenraP2B/BenraP2B/Data/deid_ds0.sas7bdat")

feno <- read_sas("Y:/Simon_Couillard/ORACLE/BenraP2B/BenraP2B/BenraP2B/Data/deid_feno0.sas7bdat")

hema <- read_sas("Y:/Simon_Couillard/ORACLE/BenraP2B/BenraP2B/BenraP2B/Data/deid_hema2_0.sas7bdat")

mh <- read_sas("Y:/Simon_Couillard/ORACLE/BenraP2B/BenraP2B/BenraP2B/Data/deid_mh0.sas7bdat")

spiro <- read_sas("Y:/Simon_Couillard/ORACLE/BenraP2B/BenraP2B/BenraP2B/Data/deid_spiro_l0.sas7bdat")

totalige <- read_sas("Y:/Simon_Couillard/ORACLE/BenraP2B/BenraP2B/BenraP2B/Data/deid_totalige0.sas7bdat")


############################################################################################################
#' [New variables]
############################################################################################################

dm$Treatment_step <- ifelse( dm$STEROID == "HIGH", 5, ifelse( dm$STEROID == "MEDIUM", 4, ifelse( dm$STEROID == "LOW",3,NA  )    )        )

ah$Previous_ICU <- ifelse(ah$ADMICU >= 1, 1,0       )

ah$Previous_Intubation <- ifelse( ah$INTUBYN == "Yes",1,0  )

ah$Smoking <- ifelse( ah$SMEVRYN == "YES" | ah$MARIJYN == "YES",1,0 )

ah$Pack_years <- ifelse(is.na(ah$SMDUR) == F &  is.na(ah$AVGCIG) == F,  ah$SMDUR*ah$AVGCIG,0      )


psy <- merge(mh[,c(47,38)], ah[,c(207,129)], by = "SUBJID", all.x = T)

psy$Psychiatric_disease <- ifelse( psy$MHSCAT == "PSYCHIATRIC"  | psy$DPRSNYN == "CURRENT" | psy$DPRSNYN == "RESOLVED", 1, 0      )

psy2 <- psy %>%
  group_by(SUBJID) %>%
  summarise(  Psychiatric_disease = ifelse(sum(Psychiatric_disease,na.rm=T) > 0, 1, 0)   )


ah$Atopy_history <- ifelse( ah$SEASMTH != "" | ah$PRNLMTH != "" | ah$ECZMAYN == "YES" ,1,0       )

ah$Eczema <- ifelse( ah$ECZMAYN == "YES" ,1,0       )

ah$AllergicRhinitis <- ifelse( ah$SEASMTH != "" | ah$PRNLMTH != "" ,1,0       )

ah$Airborne_allergen_sensitisation_on_testing <- ifelse(  (ah$SEASMTH != "" & ah$SEASMTH != "SUBJECT HISTORY"   ) | (ah$PRNLMTH != "" & ah$PRNLMTH != "SUBJECT HISTORY"   )  ,1,0      )

ah$Chronic_Rhinosinusitis <- ifelse( ah$SNSTSYN == "CURRENT", 1, 0      )

ah$Nasal_polyposis <- ifelse( ah$NPLYPYN == "YES", 1, ifelse( ah$NPLYPYN == "NO", 0 ,NA     )        )

ah$Previous_nasal_polypectomy <- ifelse( ah$SURGYN == "YES", 1, ifelse( ah$SURGYN == "NO", 0 ,NA     )        )

amed$SABA_prescribed <- ifelse( (amed$PNAM == "FENOTEROL" | 
                                   amed$PNAM == "FENOTEROL HYDROBROMIDE" | 
                                   amed$PNAM == "FENOTEROL+IPRATROPIUM BROMIDE (FENOTEROL,IPRATROPIUM BROMIDE)" | 
                                   amed$PNAM == "IPRATROPIUM BROMIDE+SALBUTAMOL (IPRATROPIUM BROMIDE,SALBUTAMOL)" | 
                                   amed$PNAM == "LEVOSALBUTAMOL" | 
                                   amed$PNAM == "SALBUTAMOL" | 
                                   amed$PNAM == "SALBUTAMOL SULFATE" ) & amed$AMBASE != "",1,0      )

amed$LAMA_prescribed <- ifelse( (amed$PNAM == "TIOTROPIUM" | 
                                   amed$PNAM == "TIOTROPIUM BROMIDE" ) & amed$AMBASE != "",1,0      )



amed$Montelukast_prescribed <- ifelse( (amed$PNAM == "MONTELUKAST" | 
                                   amed$PNAM == "MONTELUKAST SODIUM" ) & amed$AMBASE != "",1,0      )


amed$Theophylline_prescribed <- ifelse( (amed$PNAM == "AMINOPHYLLINE" | 
                                          amed$PNAM == "THEOPHYLLINE" ) & amed$AMBASE != "",1,0      )


amed2 <- amed %>%
  group_by(SUBJID) %>%
  summarise( SABA_prescribed = ifelse(sum(SABA_prescribed,na.rm=T) > 0, 1, 0),
             LAMA_prescribed = ifelse(sum(LAMA_prescribed,na.rm=T) > 0, 1, 0),
             Montelukast_prescribed = ifelse(sum(Montelukast_prescribed,na.rm=T) > 0, 1, 0),
             Theophylline_prescribed = ifelse(sum(Theophylline_prescribed,na.rm=T) > 0, 1, 0))


basedis$maintenance_OCS_prescribed <-   ifelse( basedis$ORALYNN == "1",1,0   )

spiro1 <- spiro %>%
  filter(TIMEPT == "PRE" & CPEVENT == "WEEK 1 (DAY 1)") %>%
  group_by(SUBJID) %>%
  summarise(  FEV1_predicted_L = FEV1PD )

spiro2 <- spiro %>%
  filter(TIMEPT == "PRE" & CPEVENT == "WEEK 1 (DAY 1)") %>%
  group_by(SUBJID) %>%
  summarise(  FVC_predicted_L = FVCPD )

spiro3 <- spiro %>%
  filter(TIMEPT == "PRE" & CPEVENT == "WEEK 1 (DAY 1)") %>%
  group_by(SUBJID) %>%
  summarise(  FEV1_preBD_L_Baseline = FEV1 )

spiro4 <- spiro %>%
  filter(TIMEPT == "PRE" & CPEVENT == "WEEK 1 (DAY 1)") %>%
  group_by(SUBJID) %>%
  summarise(  FEV1_preBD_PCT_Baseline = FEV1PDP )

spiro5 <- spiro %>%
  filter(TIMEPT == "PRE" & CPEVENT == "WEEK 1 (DAY 1)") %>%
  group_by(SUBJID) %>%
  summarise(  FVC_preBD_L_Baseline = FVC )

spiro6 <- spiro %>%
  filter(TIMEPT == "PRE" & CPEVENT == "WEEK 1 (DAY 1)") %>%
  group_by(SUBJID) %>%
  summarise(  FVC_preBD_PCT_Baseline = FVCPDP )


spiro1_post <- spiro %>%
  filter(  (TIMEPT == "POST1" | TIMEPT == "POST2" ) & CPEVENT == "WEEK 1 (DAY 1)") %>%
  group_by(SUBJID) %>%
  summarise(  FEV1_postBD_L_Baseline = max(FEV1,na.rm = T) )

spiro2_post <- spiro %>%
  filter(  (TIMEPT == "POST1" | TIMEPT == "POST2" ) & CPEVENT == "WEEK 1 (DAY 1)") %>%
  group_by(SUBJID) %>%
  summarise(  FEV1_postBD_PCT_Baseline = max(FEV1PDP,na.rm = T) )

spiro3_post <- spiro %>%
  filter(  (TIMEPT == "POST1" | TIMEPT == "POST2" ) & CPEVENT == "WEEK 1 (DAY 1)") %>%
  group_by(SUBJID) %>%
  summarise(  FVC_postBD_L_Baseline = max(FVC,na.rm = T) )

spiro4_post <- spiro %>%
  filter(  (TIMEPT == "POST1" | TIMEPT == "POST2" ) & CPEVENT == "WEEK 1 (DAY 1)") %>%
  group_by(SUBJID) %>%
  summarise(  FVC_postBD_PCT_Baseline = max(FVCPDP,na.rm = T) )

acq_short <- acq %>%
  filter(B_FLAG == 1)

hema_short <- hema %>%
  filter(B_FLAG == "YES", LPARM == "EOSA")

feno_short <- feno %>%
  filter(B_FLAG == "YES")

totalige_short <- totalige %>%
  filter(B_FLAG == "YES")

ds_short <- ds %>%
  filter(EPOCH == "END OF TREATMENT")


asth_v2 <- asth %>%
  dplyr::select(c(74,63,66)) %>%
  filter(WEEK <= 52) %>%
  group_by(SUBJID) %>%
  mutate( Event = row_number()    )


asth_v2_short1 <- asth_v2 %>%
  filter(Event == 1)

asth_v2_short2 <- asth_v2 %>%
  filter(Event == 2)

asth_v2_short3 <- asth_v2 %>%
  filter(Event == 3)

asth_v2_short4 <- asth_v2 %>%
  filter(Event == 4)

ds_short$EndFollowUp_Reason <- ifelse( ds_short$DSDECOD == "COMPLETED PROTOCOL-DEFINED END OF TREATMENT", 0 ,
                                       ifelse( ds_short$DSDECOD == "LOST TO FOLLOW-UP",1,
                                               ifelse( ds_short$DSDECOD == "WITHDRAWAL OF CONSENT",2,
                                                       ifelse( ds_short$DSDECOD == "OTHER",4,NA        ))))



spiro5_post <- spiro %>%
  filter(  (TIMEPT == "PRE" ) & CPEVENT == "WEEK 52") %>%
  group_by(SUBJID) %>%
  summarise(  FEV1PREBD_L_52W = FEV1 )

spiro6_post <- spiro %>%
  filter(  (TIMEPT == "PRE" ) & CPEVENT == "WEEK 52") %>%
  group_by(SUBJID) %>%
  summarise(  FEV1PREBD_PCT_52W = FEV1PDP )

spiro7_post <- spiro %>%
  filter(  (TIMEPT == "POST1" | TIMEPT == "POST2" ) & CPEVENT == "WEEK 52") %>%
  group_by(SUBJID) %>%
  summarise(  FEV1POSTBD_L_52W = max(FEV1,na.rm = T) )

spiro8_post <- spiro %>%
  filter(  (TIMEPT == "POST1" | TIMEPT == "POST2" ) & CPEVENT == "WEEK 52") %>%
  group_by(SUBJID) %>%
  summarise(  FEV1POSTBD_PCT_52W = max(FEV1PDP,na.rm = T) )



############################################################################################################
#' [Extracting data]
############################################################################################################


DataSet <- basedis[,71]

DataSet$Sequential_number <- as.numeric(NA)

DataSet$Enrolled_Trial_name <- "BENRAP2B"

DataSet$Treatment_arm <- "PLACEBO"

DataSet <- merge(DataSet,dm[,c(51,49,9,50,38)], by = "SUBJID", all.x = T)

DataSet$Country <- as.numeric(NA)

DataSet <- merge(DataSet,dm[,c(51,52)], by = "SUBJID", all.x = T)

DataSet$Any_severe_attack_previous_12m <- 1

DataSet <- merge(DataSet,ah[,c(207,191,97,208,209,210,211)], by = "SUBJID", all.x = T)

DataSet <- merge(DataSet,psy2[,c(1,2)], by = "SUBJID", all.x = T)

DataSet$Psy_disease_type <- as.numeric(NA)

DataSet <- merge(DataSet,ah[,c(207,212:218)], by = "SUBJID", all.x = T)

DataSet$Adherence_PreTrial_quantity <- as.numeric(NA)

DataSet$Adherence_PreTrial_quality <- as.numeric(NA)

DataSet$Adherence_InTrial_quantity <- as.numeric(NA)

DataSet$Adherence_InTrial_quality <- as.numeric(NA)

DataSet <- merge(DataSet,basedis[,c(71,62)], by = "SUBJID", all.x = T)

DataSet <- merge(DataSet,amed2[,c(1,2)], by = "SUBJID", all.x = T)

DataSet$SABA_actuations_per_day_average_InTrial <-  as.numeric(NA)

DataSet$Any_ICS_prescribed <-  1

DataSet$ICS_TYPE <-  "BUDESONIDE"

DataSet <- merge(DataSet,basedis[,c(71,45)], by = "SUBJID", all.x = T)

DataSet$LABA_prescribed <-  1

DataSet <- merge(DataSet,amed2[,c(1,3)], by = "SUBJID", all.x = T)

DataSet <- merge(DataSet,basedis[,c(71,72)], by = "SUBJID", all.x = T)

DataSet$Mainteance_OCS_dose <- as.numeric(NA)

DataSet <- merge(DataSet,amed2[,c(1,4,5)], by = "SUBJID", all.x = T)

DataSet$Intranasal_seroid_prescribed <- as.numeric(NA)

DataSet <- merge(DataSet,spiro1[,c(1,2)], by = "SUBJID", all.x = T)

DataSet <- merge(DataSet,spiro2[,c(1,2)], by = "SUBJID", all.x = T)

DataSet <- merge(DataSet,spiro3[,c(1,2)], by = "SUBJID", all.x = T)

DataSet <- merge(DataSet,spiro4[,c(1,2)], by = "SUBJID", all.x = T)

DataSet <- merge(DataSet,spiro5[,c(1,2)], by = "SUBJID", all.x = T)

DataSet <- merge(DataSet,spiro6[,c(1,2)], by = "SUBJID", all.x = T)

DataSet <- merge(DataSet,spiro1_post[,c(1,2)], by = "SUBJID", all.x = T)

DataSet <- merge(DataSet,spiro2_post[,c(1,2)], by = "SUBJID", all.x = T)

DataSet <- merge(DataSet,spiro3_post[,c(1,2)], by = "SUBJID", all.x = T)

DataSet <- merge(DataSet,spiro4_post[,c(1,2)], by = "SUBJID", all.x = T)

DataSet <- merge(DataSet,basedis[,c(71,42)], by = "SUBJID", all.x = T)

DataSet$ACQ_baseline_score_mean <- as.numeric(NA)

DataSet <- merge(DataSet,acq_short[,c(61,39:44)], by = "SUBJID", all.x = T)

DataSet <- DataSet %>% 
  group_by(SUBJID) %>%
  mutate( ACQ_baseline_score_mean = ifelse( is.na(Q1) == T,NA,      sum(Q1,Q2,Q3,Q4,Q5,na.rm=T)/5 )  )

DataSet$ACQ_baseline_score_item7_FEV1 <- as.numeric(NA)

DataSet$ACT_baseline_score <- as.numeric(NA)

DataSet <- merge(DataSet,hema_short[,c(81, 64)], by = "SUBJID", all.x = T)

DataSet <- merge(DataSet,feno_short[,c(59, 47)], by = "SUBJID", all.x = T)

DataSet <- merge(DataSet,totalige_short[,c(69, 48)], by = "SUBJID", all.x = T)

DataSet <- merge(DataSet,ds_short[,c(54, 37)], by = "SUBJID", all.x = T)

DataSet <- merge(DataSet,astht[,c(75, 41)], by = "SUBJID", all.x = T)

DataSet <- merge(DataSet,asth_v2_short1[,c(1,3)], by = "SUBJID", all.x = T)

DataSet <- DataSet %>%
  rename(  Time_to_First_attack = ONSTDTC )

DataSet <- merge(DataSet,asth_v2_short2[,c(1,3)], by = "SUBJID", all.x = T)

DataSet <- DataSet %>%
  rename(  Time_to_2n_attack = ONSTDTC )

DataSet <- merge(DataSet,asth_v2_short3[,c(1,3)], by = "SUBJID", all.x = T)

DataSet <- DataSet %>%
  rename(  Time_to_3n_attack = ONSTDTC )

DataSet <- merge(DataSet,asth_v2_short4[,c(1,3)], by = "SUBJID", all.x = T)

DataSet <- DataSet %>%
  rename(  Time_to_4n_attack = ONSTDTC )

DataSet$Time_to_5n_attack <- as.numeric(NA)

DataSet <- merge(DataSet,ds_short[,c(54,55)], by = "SUBJID", all.x = T)

DataSet <- merge(DataSet,spiro5_post[,c(1,2)], by = "SUBJID", all.x = T)

DataSet <- merge(DataSet,spiro6_post[,c(1,2)], by = "SUBJID", all.x = T)

DataSet <- merge(DataSet,spiro7_post[,c(1,2)], by = "SUBJID", all.x = T)

DataSet <- merge(DataSet,spiro8_post[,c(1,2)], by = "SUBJID", all.x = T)


DataSet <- DataSet %>%
  rename(  Subject_ID = SUBJID ,
           Age = AGE,
           Gender_M = SEX,
           Ethnicity = ETHNIC,
           Number_severe_attack_previous_12m = EXACENUM,
           Number_hospitalisations_for_asthma_previous_12_months = ADM12MO,
           SABA_actuations_per_day_average_PreTrial = ASSYMD12,
           ICS_Dose_PER_DAY = TOTAL,
           FEV1_PCT_reversibility_postBD = FEV1REV,
           ACQ_baseline_score_item1_sleepawakenings = Q1,
           ACQ_baseline_score_item2_morningsymptoms = Q2,
           ACQ_baseline_score_item3_activitylimitation = Q3 ,
           ACQ_baseline_score_item4_dyspnea = Q4 ,
           ACQ_baseline_score_item5_wheezing = Q5 , 
           ACQ_baseline_score_item6_RelieverUse = Q6,
           Blood_Eos_baseline_x10_9_cells_per_L = LVALSTD,
           FeNO_baseline_ppb = FENOMEAN,
           Total_IgE = RESULT_C,
           Follow_up_duration_days = DSDAN ,
           Number_severe_asthma_attacks_during_followup = N_AS52)


DataSet$Gender_M <- ifelse( DataSet$Gender_M == "MALE", 1, 0      )

DataSet <- DataSet[,c(2,1,3:78)]

DataSet$Follow_up_duration_days <- ifelse( DataSet$Subject_ID == "7363287567", 225, DataSet$Follow_up_duration_days      )
DataSet$Follow_up_duration_days <- ifelse( DataSet$Subject_ID == "7302073090", 361, DataSet$Follow_up_duration_days      )


write.xlsx(DataSet, "BENRAP2B_clean.xlsx")

