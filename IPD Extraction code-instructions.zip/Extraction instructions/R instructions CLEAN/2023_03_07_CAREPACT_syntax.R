

###########################################################################################################
# Project : Preparing data for CAREPACT
#
###########################################################################################################


###########################################################################################################
#' [ Working directory initialisation]
###########################################################################################################

setwd("Y:/Simon_Couillard/ORACLE/CARE_PACT/CARE_PACT/2023_03_07_Data_clean_CAREPACT")
getwd()

# Package importation

Packages <- c( "readxl","haven","ggplot2","dplyr","MASS", "summarytools", "gmodels",
               "jtools","car","openxlsx","extrafont","stargazer","readr")

lapply(Packages, library, character.only = TRUE)

############################################################################################################
#' [Data import]
############################################################################################################

aeclin2 <- read_csv("Y:/Simon_Couillard/ORACLE/CARE_PACT/CARE_PACT/CSV/aeclin2.csv",show_col_types = FALSE)

ast_hx <- read_csv("Y:/Simon_Couillard/ORACLE/CARE_PACT/CARE_PACT/CSV/ast_hx.csv",show_col_types = FALSE)

cap_feia <- read_csv("Y:/Simon_Couillard/ORACLE/CARE_PACT/CARE_PACT/CSV/cap_feia.csv",show_col_types = FALSE)

cmed <- read_csv("Y:/Simon_Couillard/ORACLE/CARE_PACT/CARE_PACT/CSV/cmed.csv",show_col_types = FALSE)

comply <- read_csv("Y:/Simon_Couillard/ORACLE/CARE_PACT/CARE_PACT/CSV/comply.csv",show_col_types = FALSE)

diary <- read_csv("Y:/Simon_Couillard/ORACLE/CARE_PACT/CARE_PACT/CSV/diary.csv",show_col_types = FALSE)

drugarms <- read_csv("Y:/Simon_Couillard/ORACLE/CARE_PACT/CARE_PACT/CSV/drugarms.csv",show_col_types = FALSE)

elig_ad <- read_csv("Y:/Simon_Couillard/ORACLE/CARE_PACT/CARE_PACT/CSV/elig_ad.csv",show_col_types = FALSE)

elig_ct <- read_csv("Y:/Simon_Couillard/ORACLE/CARE_PACT/CARE_PACT/CSV/elig_ct.csv",show_col_types = FALSE)

elig1 <- read_csv("Y:/Simon_Couillard/ORACLE/CARE_PACT/CARE_PACT/CSV/elig1.csv",show_col_types = FALSE)

elig2 <- read_csv("Y:/Simon_Couillard/ORACLE/CARE_PACT/CARE_PACT/CSV/elig2.csv",show_col_types = FALSE)

elig3 <- read_csv("Y:/Simon_Couillard/ORACLE/CARE_PACT/CARE_PACT/CSV/elig3.csv",show_col_types = FALSE)

eno <- read_csv("Y:/Simon_Couillard/ORACLE/CARE_PACT/CARE_PACT/CSV/eno.csv",show_col_types = FALSE)

heq <- read_csv("Y:/Simon_Couillard/ORACLE/CARE_PACT/CARE_PACT/CSV/heq.csv",show_col_types = FALSE)

hur <- read_csv("Y:/Simon_Couillard/ORACLE/CARE_PACT/CARE_PACT/CSV/hur.csv",show_col_types = FALSE)

icd9 <- read_csv("Y:/Simon_Couillard/ORACLE/CARE_PACT/CARE_PACT/CSV/icd9.csv",show_col_types = FALSE)

ios <- read_csv("Y:/Simon_Couillard/ORACLE/CARE_PACT/CARE_PACT/CSV/ios.csv",show_col_types = FALSE)

jun_acq <- read_csv("Y:/Simon_Couillard/ORACLE/CARE_PACT/CARE_PACT/CSV/jun_acq.csv",show_col_types = FALSE)

lab <- read_csv("Y:/Simon_Couillard/ORACLE/CARE_PACT/CARE_PACT/CSV/lab.csv",show_col_types = FALSE)

mataq <- read_csv("Y:/Simon_Couillard/ORACLE/CARE_PACT/CARE_PACT/CSV/mataq.csv",show_col_types = FALSE)

maxbd <- read_csv("Y:/Simon_Couillard/ORACLE/CARE_PACT/CARE_PACT/CSV/maxbd.csv",show_col_types = FALSE)

med <- read_csv("Y:/Simon_Couillard/ORACLE/CARE_PACT/CARE_PACT/CSV/med.csv",show_col_types = FALSE)

medcodes <- read_csv("Y:/Simon_Couillard/ORACLE/CARE_PACT/CARE_PACT/CSV/medcodes.csv",show_col_types = FALSE)

medhx2 <- read_csv("Y:/Simon_Couillard/ORACLE/CARE_PACT/CARE_PACT/CSV/medhx2.csv",show_col_types = FALSE)

metha <- read_csv("Y:/Simon_Couillard/ORACLE/CARE_PACT/CARE_PACT/CSV/metha.csv",show_col_types = FALSE)

paq_c <- read_csv("Y:/Simon_Couillard/ORACLE/CARE_PACT/CARE_PACT/CSV/paq_c.csv",show_col_types = FALSE)

pred <- read_csv("Y:/Simon_Couillard/ORACLE/CARE_PACT/CARE_PACT/CSV/pred.csv",show_col_types = FALSE)

priormed <- read_csv("Y:/Simon_Couillard/ORACLE/CARE_PACT/CARE_PACT/CSV/priormed.csv",show_col_types = FALSE)

serious <- read_csv("Y:/Simon_Couillard/ORACLE/CARE_PACT/CARE_PACT/CSV/serious.csv",show_col_types = FALSE)

sexam <- read_csv("Y:/Simon_Couillard/ORACLE/CARE_PACT/CARE_PACT/CSV/sexam.csv",show_col_types = FALSE)

sfdq <- read_csv("Y:/Simon_Couillard/ORACLE/CARE_PACT/CARE_PACT/CSV/sfdq.csv",show_col_types = FALSE)

skin <- read_csv("Y:/Simon_Couillard/ORACLE/CARE_PACT/CARE_PACT/CSV/skin.csv",show_col_types = FALSE)

spiro <- read_csv("Y:/Simon_Couillard/ORACLE/CARE_PACT/CARE_PACT/CSV/spiro.csv",show_col_types = FALSE)

term <- read_csv("Y:/Simon_Couillard/ORACLE/CARE_PACT/CARE_PACT/CSV/term.csv",show_col_types = FALSE)

trtfail <- read_csv("Y:/Simon_Couillard/ORACLE/CARE_PACT/CARE_PACT/CSV/trtfail.csv",show_col_types = FALSE)

############################################################################################################
#' [New variables]
############################################################################################################

sexam$BMI <- sexam$SX_1050/(sexam$SX_1041*sexam$SX_1041)*10000

sexam <- sexam %>%
  filter(VNUM == 1)

spiro <- spiro %>%
  filter(VNUM == 1)

maxbd <- maxbd %>%
  filter(VNUM == 1)

eno <- eno %>%
  filter(VNUM == 2)

lab <- lab %>%
  filter(VNUM == 2)

jun_acq <- jun_acq %>%
  filter(VNUM == 2)

medhx2$Ethnicity <- ifelse(medhx2$RACE_WHITE == "YES", "White", ifelse( medhx2$RACE_BLACK == "YES","Black", "Others" )  )
medhx2$Ethnicity <- ifelse( (medhx2$RACE_WHITE == "YES" &  medhx2$RACE_BLACK == "YES") |
                              (medhx2$RACE_WHITE == "YES" &  medhx2$RACE_OTHER == "YES") |
                              (medhx2$RACE_OTHER == "YES" &  medhx2$RACE_BLACK == "YES") , "Mixed", medhx2$Ethnicity)


ast_hx$AHX_1340 <- ifelse( ast_hx$AHX_1310 == "NO","NO", ast_hx$AHX_1340  )

ast_hx$AHX_1290 <- ifelse( ast_hx$AHX_1260 == "NO","NO", ast_hx$AHX_1290  )

ast_hx$AHX_1390 <- ifelse( ast_hx$AHX_1360 == "NO","NO", ast_hx$AHX_1390  )

ast_hx$AHX_1380 <- ifelse( ast_hx$AHX_1360 == "NO","NO", ast_hx$AHX_1380  )


ast_hx$Atopy_history <- ifelse(ast_hx$AHX_1290 == "YES" | ast_hx$AHX_1340 == "YES" | ast_hx$AHX_1390 == "YES" | ast_hx$AHX_1380 == "YES", 1,
                               ifelse( ast_hx$AHX_1290 == "NO" & ast_hx$AHX_1340 == "NO" & ast_hx$AHX_1390 == "NO" & ast_hx$AHX_1380 == "NO",0,NA        ))



comply2 <- comply %>%
  group_by(SUBJ_ID) %>%
  summarise(Adherence_InTrial_quantity = mean( CMP_1190, na.rm = T),
            Adherence_InTrial_quality = ifelse(  Adherence_InTrial_quantity >= 70,1,0   )   )

  
lab$Blood_Eos_baseline_x10_9_cells_per_L <- (lab$LAB_1040/100)*(lab$LAB_1030)/1000
  
maxbd <- maxbd %>%
  group_by(SUBJ_ID)%>%   
  mutate( FEV1_postBD_L_Baseline =  max( MAX_1270, MAX_1310, MAX_1370  ,na.rm = T),
          FEV1_postBD_PCT_Baseline = max(MAX_1280, MAX_1320, MAX_1380  ,na.rm = T)  )

maxbd$FEV1_postBD_L_Baseline <- ifelse( maxbd$FEV1_postBD_L_Baseline == "-Inf",NA,maxbd$FEV1_postBD_L_Baseline )
maxbd$FEV1_postBD_PCT_Baseline <- ifelse( maxbd$FEV1_postBD_PCT_Baseline == "-Inf",NA,maxbd$FEV1_postBD_PCT_Baseline )

maxbd2 <- maxbd %>%
  filter(VNUM==1) 


skin$SKN_1080 <- ifelse( is.na(skin$SKN_1080) == T, 0, skin$SKN_1080     )

skin$SKN_1110_less_SKN_1080 <- skin$SKN_1110 - skin$SKN_1080
skin$SKN_1140_less_SKN_1080 <- skin$SKN_1140 - skin$SKN_1080
skin$SKN_1170_less_SKN_1080 <- skin$SKN_1170 - skin$SKN_1080
skin$SKN_1200_less_SKN_1080 <- skin$SKN_1200 - skin$SKN_1080
skin$SKN_1230_less_SKN_1080 <- skin$SKN_1230 - skin$SKN_1080
skin$SKN_1260_less_SKN_1080 <- skin$SKN_1260 - skin$SKN_1080
skin$SKN_1290_less_SKN_1080 <- skin$SKN_1290 - skin$SKN_1080
skin$SKN_1320_less_SKN_1080 <- skin$SKN_1320 - skin$SKN_1080

Skin_Cap_feia <- merge(skin,cap_feia,by = "SUBJ_ID", all.x = T)

Skin_Cap_feia$Airborne_allergen_sensitisation_on_testing <- ifelse(   Skin_Cap_feia$CAP_1000 >= 0.7 | 
                                                                      Skin_Cap_feia$CAP_1010 >= 0.7 |
                                                                      Skin_Cap_feia$CAP_1020 >= 0.7 |
                                                                      Skin_Cap_feia$CAP_1030 >= 0.7 |
                                                                      Skin_Cap_feia$CAP_1040 >= 0.7 |
                                                                      Skin_Cap_feia$CAP_1050 >= 0.7 |
                                                                      Skin_Cap_feia$CAP_1060 >= 0.7 |
                                                                      Skin_Cap_feia$CAP_1070 >= 0.7 |
                                                                      Skin_Cap_feia$SKN_1110_less_SKN_1080 >= 3 |
                                                                      Skin_Cap_feia$SKN_1140_less_SKN_1080 >= 3 |
                                                                      Skin_Cap_feia$SKN_1170_less_SKN_1080 >= 3 |
                                                                      Skin_Cap_feia$SKN_1200_less_SKN_1080 >= 3 |
                                                                      Skin_Cap_feia$SKN_1230_less_SKN_1080 >= 3 |
                                                                      Skin_Cap_feia$SKN_1260_less_SKN_1080 >= 3 |
                                                                      Skin_Cap_feia$SKN_1290_less_SKN_1080 >= 3 |
                                                                      Skin_Cap_feia$SKN_1320_less_SKN_1080 >= 3,1, NA )


Skin_Cap_feia$Airborne_allergen_sensitisation_on_testing <-ifelse(
  is.na(Skin_Cap_feia$Airborne_allergen_sensitisation_on_testing) == T & (
  is.na(Skin_Cap_feia$CAP_1000) == F | 
    is.na(Skin_Cap_feia$CAP_1010) == F |
    is.na(Skin_Cap_feia$CAP_1020) == F |
    is.na(Skin_Cap_feia$CAP_1030) == F |
    is.na(Skin_Cap_feia$CAP_1040) == F |
    is.na(Skin_Cap_feia$CAP_1050) == F |
    is.na(Skin_Cap_feia$CAP_1060) == F |
    is.na(Skin_Cap_feia$CAP_1070) == F |
    is.na(Skin_Cap_feia$SKN_1110_less_SKN_1080) == F |
    is.na(Skin_Cap_feia$SKN_1140_less_SKN_1080) == F |
    is.na(Skin_Cap_feia$SKN_1170_less_SKN_1080) == F |
    is.na(Skin_Cap_feia$SKN_1200_less_SKN_1080) == F |
    is.na(Skin_Cap_feia$SKN_1230_less_SKN_1080) == F |
    is.na(Skin_Cap_feia$SKN_1260_less_SKN_1080) == F |
    is.na(Skin_Cap_feia$SKN_1290_less_SKN_1080) == F |
    is.na(Skin_Cap_feia$SKN_1320_less_SKN_1080) == F), 0,Skin_Cap_feia$Airborne_allergen_sensitisation_on_testing )

Skin_Cap_feia <- Skin_Cap_feia %>%
  dplyr::select(c(1,17,20,23,26,29,32,35,38,14,71,72,73,74,75,76,77,78,84))

pred.max <- pred %>%
  group_by(SUBJ_ID)%>%
  summarise(Number_severe_asthma_attacks_during_followup = max(PRD_1010,na.rm=T  ))

pred1 <- pred %>%
  filter(PRD_1010 == 1) %>%
  rename( Time_to_First_attack = PRD_1000 )

pred2 <- pred %>%
  filter(PRD_1010 == 2)%>%
  rename( Time_to_2n_attack = PRD_1000 )

pred3 <- pred %>%
  filter(PRD_1010 == 3)%>%
  rename( Time_to_3n_attack = PRD_1000 )

pred4 <- pred %>%
  filter(PRD_1010 == 4)%>%
  rename( Time_to_4n_attack = PRD_1000 )


term$EndFollowUp_Reason <- ifelse( term$TRM_1010 == "YES", 0, ifelse(  
  term$TRM_1090 == "YES", 1, ifelse(  term$TRM_1070 == "YES", term$TRM_1080,  NA   )   )   )


mataq$MAT_1090_v2 <- ifelse( mataq$MAT_1090 == "1 to 4 puffs", 2.5, ifelse( 
  mataq$MAT_1090 == "5 to 8 puffs", 6.5, ifelse(  
    mataq$MAT_1090 == "9 to 12 puffs", 10.5,12    )  ))


mataq2 <- mataq %>%
  group_by(SUBJ_ID)  %>%
  summarise( SABA_actuations_per_day_average_InTrial = mean( MAT_1090_v2 ,na.rm=T)    )



############################################################################################################
#' [Extracting data]
############################################################################################################

DataSet <- drugarms

DataSet$Sequential_number <- as.numeric(NA)

DataSet$Enrolled_Trial_name <- "PACT"

DataSet <- DataSet[,c(3,1,4,2)]

DataSet <- merge(DataSet,medhx2[,c(1,54,8)], by = "SUBJ_ID", all.x = T)

DataSet <- merge(DataSet, sexam[,c(1,38)] , by = "SUBJ_ID", all.x = T)

DataSet <- merge(DataSet,medhx2[,c(1,56)], by = "SUBJ_ID", all.x = T)

DataSet$Country <- "USA"

DataSet <- merge(DataSet,elig2[,c(1,4)], by = "SUBJ_ID", all.x = T)

DataSet <- merge(DataSet,priormed[,c(1,4,14)], by = "SUBJ_ID", all.x = T)

DataSet <- merge(DataSet,ast_hx[,c(1,10)], by = "SUBJ_ID", all.x = T)

DataSet$PRM_1090 <- ifelse( DataSet$PRM_1000 == "NO", 0, DataSet$PRM_1090    )

DataSet$AHX_1060 <- ifelse( DataSet$PRM_1000 == "NO", 0, DataSet$AHX_1060    )

DataSet <- DataSet %>% dplyr::select(-c(11))

DataSet$Any_severe_attack_previous_12m <- ifelse( DataSet$PRM_1090 == "1:1 course" |
                                                             DataSet$PRM_1090 == "2:2 courses" |
                                                             DataSet$PRM_1090 == "3:3 courses" |
                                                             DataSet$AHX_1060 >= 1, 1, 0   )


DataSet$Any_severe_attack_previous_12m <-ifelse( is.na(DataSet$Any_severe_attack_previous_12m  ) == T,0,DataSet$Any_severe_attack_previous_12m  )

DataSet <- DataSet[,c(1,2,3,4,5,6,7,8,9,10,13,11,12)]

DataSet <- merge(DataSet,ast_hx[,c(1,11)], by = "SUBJ_ID", all.x = T)

DataSet <- merge(DataSet,elig1[,c(1,18,9)], by = "SUBJ_ID", all.x = T)

DataSet$Pack_years <- as.numeric(NA)

DataSet$Psychiatric_disease	 <- as.numeric(NA)

DataSet$Psy_disease_type <- as.numeric(NA)

DataSet <- merge(DataSet,ast_hx[,c(1,51)], by = "SUBJ_ID", all.x = T)

DataSet <- merge(DataSet,ast_hx[,c(1,38,33)], by = "SUBJ_ID", all.x = T)

DataSet <- merge(DataSet,Skin_Cap_feia[,c(1,19)], by = "SUBJ_ID", all.x = T)

DataSet <- merge(DataSet,medhx2[,c(1,19)], by = "SUBJ_ID", all.x = T)

DataSet$Nasal_polyposis <- as.numeric(NA)

DataSet$Previous_nasal_polypectomy <- as.numeric(NA)

DataSet$Adherence_PreTrial_quantity <- as.numeric(NA)

DataSet$Adherence_PreTrial_quality <- as.numeric(NA)

DataSet <- merge(DataSet,comply2[,c(1,2,3)], by = "SUBJ_ID", all.x = T)

DataSet <- merge(DataSet,elig3[,c(1,27)], by = "SUBJ_ID", all.x = T)

DataSet$SABA_prescribed <- 1

DataSet <- merge(DataSet,mataq2[,c(1,2)], by = "SUBJ_ID", all.x = T)

DataSet$Any_ICS_prescribed <- DataSet$DRUG_ARM
DataSet$ICS_TYPE <- DataSet$DRUG_ARM
DataSet$ICS_Dose_PER_DAY <- DataSet$DRUG_ARM
DataSet$LABA_prescribed <- DataSet$DRUG_ARM

DataSet$LAMA_prescribed <- 0
DataSet$maintenance_OCS_prescribed <- 0
DataSet$Mainteance_OCS_dose <- 0

DataSet$Montelukast_prescribed <- DataSet$DRUG_ARM

DataSet <- merge(DataSet,priormed[,c(1,9)], by = "SUBJ_ID", all.x = T)

DataSet$PRM_1050 <- ifelse( is.na(DataSet$PRM_1050) == T, 0,DataSet$PRM_1050    )

DataSet <- merge(DataSet,medhx2[,c(1,22)], by = "SUBJ_ID", all.x = T)

DataSet$MHX_1190 <- ifelse( DataSet$MHX_1190 == "5. Never" | DataSet$MHX_1160 == "NO", 0, 1  )

DataSet$FEV1_predicted_L <- as.numeric(NA)

DataSet$FVC_predicted_L <- as.numeric(NA)





DataSet <- merge(DataSet,maxbd2[,c(1,16,17,15)], by = "SUBJ_ID", all.x = T)





DataSet$FVC_preBD_PCT_Baseline <- as.numeric(NA)

DataSet <- merge(DataSet,maxbd[,c(1,50,51)], by = "SUBJ_ID", all.x = T)

DataSet$FVC_postBD_L_Baseline <- as.numeric(NA)
DataSet$FVC_postBD_PCT_Baseline <- as.numeric(NA)
DataSet$FEV1_PCT_reversibility_postBD <- as.numeric(NA)
DataSet$ACQ_baseline_score_mean <- as.numeric(NA)

DataSet <- merge(DataSet,jun_acq[,c(1,5,6,7,8,9,10,11)], by = "SUBJ_ID", all.x = T)

DataSet$ACT_baseline_score <- as.numeric(NA)

DataSet <- merge(DataSet,lab[,c(1,9)], by = "SUBJ_ID", all.x = T)
	
DataSet <- merge(DataSet,eno[,c(1,19)], by = "SUBJ_ID", all.x = T)

DataSet$Total_IgE <- as.numeric(NA)

DataSet <- merge(DataSet,term[,c(1,3)], by = "SUBJ_ID", all.x = T)

DataSet <- merge(DataSet,pred.max[,c(1,2)], by = "SUBJ_ID", all.x = T)

DataSet <- merge(DataSet,pred1[,c(1,4)], by = "SUBJ_ID", all.x = T)

DataSet <- merge(DataSet,pred2[,c(1,4)], by = "SUBJ_ID", all.x = T)

DataSet <- merge(DataSet,pred3[,c(1,4)], by = "SUBJ_ID", all.x = T)

DataSet <- merge(DataSet,pred4[,c(1,4)], by = "SUBJ_ID", all.x = T)

DataSet$Time_to_5n_attack <- as.numeric(NA)

DataSet <- merge(DataSet,term[,c(1,18)], by = "SUBJ_ID", all.x = T)

rm(list = c("aeclin2","ast_hx","cap_feia","cmed","comply","comply2","diary","drugarms",
            "elig_ad","elig_ct","elig1","elig2","elig3","eno","heq","hur","icd9","ios","jun_acq",
            "lab","mataq","mataq2","maxbd","med","medcodes","medhx2","metha","paq_c","pred",
            "pred.max","priormed","serious","sexam","sfdq","skin","Skin_Cap_feia","spiro","term","trtfail"))

DataSet <- DataSet[,c(2,1,3:74)]

DataSet$FEV1PREBD_L_52W <- as.numeric(NA)
DataSet$FEV1PREBD_PCT_52W <- as.numeric(NA)
DataSet$FEV1POSTBD_L_52W <- as.numeric(NA)
DataSet$FEV1POSTBD_PCT_52W <- as.numeric(NA)


DataSet <- DataSet %>%
  rename(  Subject_ID = SUBJ_ID ,
           Treatment_arm = DRUG_ARM,
           Age = AGE,
           Gender_M = MHX_1030,
           Treatment_step = E2_1000,
           Number_severe_attack_previous_12m = PRM_1090,
           Number_hospitalisations_for_asthma_previous_12_months = AHX_1060,
           Previous_ICU = AHX_1070,
           Previous_Intubation = E1_1140,
           Smoking = E1_1050,
           Eczema = AHX_1340,
           AllergicRhinitis = AHX_1290,
           Chronic_Rhinosinusitis = MHX_1160,
           SABA_actuations_per_day_average_PreTrial = E3_1260,
           Theophylline_prescribed = PRM_1050,
           Intranasal_seroid_prescribed = MHX_1190,
           FEV1_preBD_L_Baseline = MAX_1120,
           FEV1_preBD_PCT_Baseline = MAX_1130,
           FVC_preBD_L_Baseline = MAX_1110,
           ACQ_baseline_score_item1_sleepawakenings = JUN_1010,
           ACQ_baseline_score_item2_morningsymptoms	= JUN_1020,
           ACQ_baseline_score_item3_activitylimitation	= JUN_1030,
           ACQ_baseline_score_item4_dyspnea	= JUN_1040,
           ACQ_baseline_score_item5_wheezing	= JUN_1050,
           ACQ_baseline_score_item6_RelieverUse =	JUN_1060,
           ACQ_baseline_score_item7_FEV1 = JUN_1110,
           FeNO_baseline_ppb = ENO_1120  )


DataSet$Gender_M <- ifelse( DataSet$Gender_M == "Male",1,0 )

DataSet$Treatment_step <- ifelse( DataSet$Treatment_step == "YES",2, ifelse( 
  DataSet$Treatment_step == "NO",1, NA  ) )

DataSet$Previous_ICU <- ifelse( DataSet$Previous_ICU == "YES",1, ifelse( 
  DataSet$Previous_ICU == "NO",0, NA  ) )

DataSet$Previous_Intubation <- ifelse( DataSet$Previous_Intubation == "YES",1, ifelse( 
  DataSet$Previous_Intubation == "NO",0, NA  ) )

DataSet$Smoking <- ifelse( DataSet$Smoking == "YES",1, ifelse( 
  DataSet$Smoking == "NO",0, NA  ) )

DataSet$Eczema <- ifelse( DataSet$Eczema == "YES",1, ifelse( 
  DataSet$Eczema == "NO",0, NA  ) )

DataSet$AllergicRhinitis <- ifelse( DataSet$AllergicRhinitis == "YES",1, ifelse( 
  DataSet$AllergicRhinitis == "NO",0, NA  ) )

DataSet$Chronic_Rhinosinusitis <- ifelse( DataSet$Chronic_Rhinosinusitis == "YES",1, ifelse( 
  DataSet$Chronic_Rhinosinusitis == "NO",0, NA  ) )

DataSet$ACQ_baseline_score_item7_FEV1 <- ifelse( DataSet$ACQ_baseline_score_item7_FEV1 == "YES",1, ifelse( 
  DataSet$ACQ_baseline_score_item7_FEV1 == "NO",0, NA  ) )

DataSet$Number_severe_attack_previous_12m <- ifelse(  DataSet$Number_severe_attack_previous_12m == "0:0 courses",0,
                                                      ifelse( DataSet$Number_severe_attack_previous_12m == "1:1 course",1,
                                                              ifelse(  DataSet$Number_severe_attack_previous_12m == "2:2 courses",2,3
                                                                              )         ))

DataSet$ACQ_baseline_score_item1_sleepawakenings <- substr(DataSet$ACQ_baseline_score_item1_sleepawakenings, 1, 1)

DataSet$ACQ_baseline_score_item1_sleepawakenings <- as.numeric(DataSet$ACQ_baseline_score_item1_sleepawakenings)

DataSet$ACQ_baseline_score_item2_morningsymptoms <- substr(DataSet$ACQ_baseline_score_item2_morningsymptoms, 1, 1)

DataSet$ACQ_baseline_score_item2_morningsymptoms <- as.numeric(DataSet$ACQ_baseline_score_item2_morningsymptoms)

DataSet$ACQ_baseline_score_item3_activitylimitation <- substr(DataSet$ACQ_baseline_score_item3_activitylimitation, 1, 1)

DataSet$ACQ_baseline_score_item3_activitylimitation <- as.numeric(DataSet$ACQ_baseline_score_item3_activitylimitation)

DataSet$ACQ_baseline_score_item4_dyspnea <- substr(DataSet$ACQ_baseline_score_item4_dyspnea, 1, 1)

DataSet$ACQ_baseline_score_item4_dyspnea <- as.numeric(DataSet$ACQ_baseline_score_item4_dyspnea)

DataSet$ACQ_baseline_score_item5_wheezing <- substr(DataSet$ACQ_baseline_score_item5_wheezing, 1, 1)

DataSet$ACQ_baseline_score_item5_wheezing <- as.numeric(DataSet$ACQ_baseline_score_item5_wheezing)

DataSet$ACQ_baseline_score_item6_RelieverUse <- substr(DataSet$ACQ_baseline_score_item6_RelieverUse, 1, 1)

DataSet$ACQ_baseline_score_item6_RelieverUse <- as.numeric(DataSet$ACQ_baseline_score_item6_RelieverUse)


DataSet$Any_ICS_prescribed <- ifelse( DataSet$Any_ICS_prescribed == "Montelukast","0","1"    )

DataSet$ICS_TYPE <- ifelse( DataSet$ICS_TYPE == "Montelukast","0","FP"    )

DataSet$ICS_Dose_PER_DAY <- ifelse( DataSet$ICS_Dose_PER_DAY == "Montelukast","0","200"    )

DataSet$LABA_prescribed <- ifelse( DataSet$LABA_prescribed == "Advair","1","0"    )

DataSet$Montelukast_prescribed <- ifelse( DataSet$ICS_Dose_PER_DAY == "Montelukast","1","0"    )




write.xlsx(DataSet, "CAREPACT_clean.xlsx")
