

###########################################################################################################
#
# Project : Preparing data for CAREPACT
#
###########################################################################################################


###########################################################################################################
#' [ Working directory initialisation]
###########################################################################################################

setwd("Y:/Simon_Couillard/ORACLE/LEBRI_MILLY/LEBRI_MILLY/2023_03_29_Data_clean_MILLY")
getwd()

# Package importation

Packages <- c( "readxl","haven","ggplot2","dplyr","MASS", "summarytools", "gmodels",
               "jtools","car","openxlsx","extrafont","stargazer","readr")

lapply(Packages, library, character.only = TRUE)

############################################################################################################
#' [Data import]
############################################################################################################

abconc <- read_xpt("Y:/Simon_Couillard/ORACLE/LEBRI_MILLY/LEBRI_MILLY/Analysis Datasets_KGAR_placebo/abconc.xpt")
acddeff <- read_xpt("Y:/Simon_Couillard/ORACLE/LEBRI_MILLY/LEBRI_MILLY/Analysis Datasets_KGAR_placebo/acddeff.xpt")
acq <- read_xpt("Y:/Simon_Couillard/ORACLE/LEBRI_MILLY/LEBRI_MILLY/Analysis Datasets_KGAR_placebo/acq.xpt")
acqeff <- read_xpt("Y:/Simon_Couillard/ORACLE/LEBRI_MILLY/LEBRI_MILLY/Analysis Datasets_KGAR_placebo/acqeff.xpt")
ae <- read_xpt("Y:/Simon_Couillard/ORACLE/LEBRI_MILLY/LEBRI_MILLY/Analysis Datasets_KGAR_placebo/ae.xpt")
aqlq <- read_xpt("Y:/Simon_Couillard/ORACLE/LEBRI_MILLY/LEBRI_MILLY/Analysis Datasets_KGAR_placebo/aqlq.xpt")
aqlqeff <- read_xpt("Y:/Simon_Couillard/ORACLE/LEBRI_MILLY/LEBRI_MILLY/Analysis Datasets_KGAR_placebo/aqlqeff.xpt")
CONMED <- read_xpt("Y:/Simon_Couillard/ORACLE/LEBRI_MILLY/LEBRI_MILLY/Analysis Datasets_KGAR_placebo/CONMED.xpt")
demog <- read_xpt("Y:/Simon_Couillard/ORACLE/LEBRI_MILLY/LEBRI_MILLY/Analysis Datasets_KGAR_placebo/demog.xpt")
disccw <- read_xpt("Y:/Simon_Couillard/ORACLE/LEBRI_MILLY/LEBRI_MILLY/Analysis Datasets_KGAR_placebo/disccw.xpt")
ecg <- read_xpt("Y:/Simon_Couillard/ORACLE/LEBRI_MILLY/LEBRI_MILLY/Analysis Datasets_KGAR_placebo/ecg.xpt")
elig <- read_xpt("Y:/Simon_Couillard/ORACLE/LEBRI_MILLY/LEBRI_MILLY/Analysis Datasets_KGAR_placebo/elig.xpt")
esq <- read_xpt("Y:/Simon_Couillard/ORACLE/LEBRI_MILLY/LEBRI_MILLY/Analysis Datasets_KGAR_placebo/esq.xpt")
exac <- read_xpt("Y:/Simon_Couillard/ORACLE/LEBRI_MILLY/LEBRI_MILLY/Analysis Datasets_KGAR_placebo/exac.xpt")
feno <- read_xpt("Y:/Simon_Couillard/ORACLE/LEBRI_MILLY/LEBRI_MILLY/Analysis Datasets_KGAR_placebo/feno.xpt")
fenoeff <- read_xpt("Y:/Simon_Couillard/ORACLE/LEBRI_MILLY/LEBRI_MILLY/Analysis Datasets_KGAR_placebo/fenoeff.xpt")
ic <- read_xpt("Y:/Simon_Couillard/ORACLE/LEBRI_MILLY/LEBRI_MILLY/Analysis Datasets_KGAR_placebo/ic.xpt")
ige <- read_xpt("Y:/Simon_Couillard/ORACLE/LEBRI_MILLY/LEBRI_MILLY/Analysis Datasets_KGAR_placebo/ige.xpt")
ivrs <- read_xpt("Y:/Simon_Couillard/ORACLE/LEBRI_MILLY/LEBRI_MILLY/Analysis Datasets_KGAR_placebo/ivrs.xpt")
labv <- read_xpt("Y:/Simon_Couillard/ORACLE/LEBRI_MILLY/LEBRI_MILLY/Analysis Datasets_KGAR_placebo/labv.xpt")
medhx <- read_xpt("Y:/Simon_Couillard/ORACLE/LEBRI_MILLY/LEBRI_MILLY/Analysis Datasets_KGAR_placebo/medhx.xpt")
ncigrade <- read_xpt("Y:/Simon_Couillard/ORACLE/LEBRI_MILLY/LEBRI_MILLY/Analysis Datasets_KGAR_placebo/ncigrade.xpt")
pat <- read_xpt("Y:/Simon_Couillard/ORACLE/LEBRI_MILLY/LEBRI_MILLY/Analysis Datasets_KGAR_placebo/pat.xpt")
pat32 <- read_xpt("Y:/Simon_Couillard/ORACLE/LEBRI_MILLY/LEBRI_MILLY/Analysis Datasets_KGAR_placebo/pat32.xpt")
pe <- read_xpt("Y:/Simon_Couillard/ORACLE/LEBRI_MILLY/LEBRI_MILLY/Analysis Datasets_KGAR_placebo/pe.xpt")
primed <- read_xpt("Y:/Simon_Couillard/ORACLE/LEBRI_MILLY/LEBRI_MILLY/Analysis Datasets_KGAR_placebo/primed.xpt")
#pro <- read_xpt("Y:/Simon_Couillard/ORACLE/LEBRI_MILLY/LEBRI_MILLY/Analysis Datasets_KGAR_placebo/pro.xpt")
queseff <- read_xpt("Y:/Simon_Couillard/ORACLE/LEBRI_MILLY/LEBRI_MILLY/Analysis Datasets_KGAR_placebo/queseff.xpt")
reprod <- read_xpt("Y:/Simon_Couillard/ORACLE/LEBRI_MILLY/LEBRI_MILLY/Analysis Datasets_KGAR_placebo/reprod.xpt")
skinprk <- read_xpt("Y:/Simon_Couillard/ORACLE/LEBRI_MILLY/LEBRI_MILLY/Analysis Datasets_KGAR_placebo/skinprk.xpt")
spireff <- read_xpt("Y:/Simon_Couillard/ORACLE/LEBRI_MILLY/LEBRI_MILLY/Analysis Datasets_KGAR_placebo/spireff.xpt")
spiro <- read_xpt("Y:/Simon_Couillard/ORACLE/LEBRI_MILLY/LEBRI_MILLY/Analysis Datasets_KGAR_placebo/spiro.xpt")
stdunits <- read_xpt("Y:/Simon_Couillard/ORACLE/LEBRI_MILLY/LEBRI_MILLY/Analysis Datasets_KGAR_placebo/stdunits.xpt")
stratvar <- read_xpt("Y:/Simon_Couillard/ORACLE/LEBRI_MILLY/LEBRI_MILLY/Analysis Datasets_KGAR_placebo/stratvar.xpt")
surg <- read_xpt("Y:/Simon_Couillard/ORACLE/LEBRI_MILLY/LEBRI_MILLY/Analysis Datasets_KGAR_placebo/surg.xpt")
tarcmcp <- read_xpt("Y:/Simon_Couillard/ORACLE/LEBRI_MILLY/LEBRI_MILLY/Analysis Datasets_KGAR_placebo/tarcmcp.xpt")
tohx <- read_xpt("Y:/Simon_Couillard/ORACLE/LEBRI_MILLY/LEBRI_MILLY/Analysis Datasets_KGAR_placebo/tohx.xpt")
tx <- read_xpt("Y:/Simon_Couillard/ORACLE/LEBRI_MILLY/LEBRI_MILLY/Analysis Datasets_KGAR_placebo/tx.xpt")
unsvst <- read_xpt("Y:/Simon_Couillard/ORACLE/LEBRI_MILLY/LEBRI_MILLY/Analysis Datasets_KGAR_placebo/unsvst.xpt")
vitals <- read_xpt("Y:/Simon_Couillard/ORACLE/LEBRI_MILLY/LEBRI_MILLY/Analysis Datasets_KGAR_placebo/vitals.xpt")
vlaq <- read_xpt("Y:/Simon_Couillard/ORACLE/LEBRI_MILLY/LEBRI_MILLY/Analysis Datasets_KGAR_placebo/vlaq.xpt")
wpai <- read_xpt("Y:/Simon_Couillard/ORACLE/LEBRI_MILLY/LEBRI_MILLY/Analysis Datasets_KGAR_placebo/wpai.xpt")
xray <- read_xpt("Y:/Simon_Couillard/ORACLE/LEBRI_MILLY/LEBRI_MILLY/Analysis Datasets_KGAR_placebo/xray.xpt")


############################################################################################################
#' [New variables]
############################################################################################################

demog$BMI <- demog$WT / ( (demog$HT/100  )*(demog$HT/100  )   )

demog$Treatment_step <- ifelse( demog$ICSDOSE < 250, 3, ifelse( demog$ICSDOSE >= 250 & demog$ICSDOSE < 500,4,5      )      )

medhx$Any_severe_attack_previous_12m <- ifelse(  (medhx$HXRAW == "ASTHMA EXACERBATIONS" | medhx$HXRAW == "ASTHMA EXACERBATION" ) & medhx$HXREC == "Yes",1,0       )

tohx$Pack_years <- ifelse( is.na(tohx$TOBQTY) == T, 0, tohx$TOBQTY    )


medhx$Psychiatric_disease <- ifelse(  (medhx$HXRAW == "ANXIETY" | medhx$HXRAW == "ANXETY DISORDER" |
                                         medhx$HXRAW == "DEPRESSION" | medhx$HXRAW == "DEPRESSION (MILD)" |
                                         medhx$HXRAW == "INTERMITTENT ANXIETY" | medhx$HXRAW == "MILD DEPRESSION" |
                                         medhx$HXRAW == "MILD ANXIETY" | medhx$HXRAW == "OCCASIONAL MILD ANXIETY" |
                                         medhx$HXRAW == "SOCIAL ANXIETY" | medhx$HXRAW == "ATTENTION DEFICIT DISORDER" ) & medhx$HXREC == "Yes",1,0       )


medhx$Psy_disease_type <- ifelse(  (medhx$HXRAW == "ANXIETY" | medhx$HXRAW == "ANXETY DISORDER" |
                                         medhx$HXRAW == "DEPRESSION" | medhx$HXRAW == "DEPRESSION (MILD)" |
                                         medhx$HXRAW == "INTERMITTENT ANXIETY" | medhx$HXRAW == "MILD DEPRESSION" |
                                         medhx$HXRAW == "MILD ANXIETY" | medhx$HXRAW == "OCCASIONAL MILD ANXIETY" |
                                         medhx$HXRAW == "SOCIAL ANXIETY") & medhx$HXREC == "Yes",1, ifelse(  (medhx$HXRAW == "ATTENTION DEFICIT DISORDER") & medhx$HXREC == "Yes",4,0
                                        ))

medhx$Chronic_Rhinosinusitis <- ifelse(  (medhx$HXRAW == "SINUS POLYPS" | medhx$HXRAW == "CHRONIC SINUSITIS" |
                                      medhx$HXRAW == "CHRONIC SINUS DISEASE" | medhx$HXRAW == "CHRONIC RHINITIS" ) 
                                      & medhx$HXREC == "Yes",1, 0)

medhx$Nasal_polyposis <- ifelse(  (medhx$HXRAW == "SINUS POLYPS") & medhx$HXREC == "Yes",1, 0)



medhx2 <- medhx %>%
  group_by(PATNUM) %>%
  summarise(Any_severe_attack_previous_12m = ifelse( sum(Any_severe_attack_previous_12m,na.rm=T) > 0,1,0   ),
            Psychiatric_disease = ifelse( sum(Psychiatric_disease,na.rm=T) > 0,1,0   ),
            Psy_disease_type =  max(Psy_disease_type,na.rm=T),
            Chronic_Rhinosinusitis = ifelse( sum(Chronic_Rhinosinusitis,na.rm=T) > 0,1,0   ),
            Nasal_polyposis = ifelse( sum(Nasal_polyposis,na.rm=T) > 0,1,0   ))


demog$Atopy_history <- ifelse(  demog$ECZEMA == "YES" | demog$RHINITIS == "YES"| demog$SKINTEST == "POSITIVE" , 1, 0          )


acddeff2 <- acddeff %>%
  filter(VISIT == "Day 1 Visit 3")

acddeff3 <- acddeff %>%
  filter(VISIT != "Day 1 Visit 3") %>%
  group_by(PATNUM) %>%
  summarise(SABA_actuations_per_day_average_InTrial = mean(RESCUE, na.rm= T))


CONMED$Montelukast_prescribed <- ifelse( CONMED$MDG == "MONTELUKAST SODIUM" &  CONMED$MDONG == 1,1,0     )

CONMED$Theophylline_prescribed <- ifelse( (CONMED$MDG == "AMINOPHYLLINE" | CONMED$MDG == "THEOPHYLLINE" ) &  CONMED$MDONG == 1,1,0 )

CONMED$Intranasal_seroid_prescribed <- ifelse( ( CONMED$MDUN == "SPRAY" | CONMED$MDUN == "SPRAYS" |
                                                   CONMED$MDRTE == "NASAL" | CONMED$MDRTE == "INTRANASAL" |
                                                   CONMED$MDRTE == "NASAL SPRAY" | CONMED$MDRTE == "INTRA NASAL" |
                                                   CONMED$MDRTE == "INTRA-NASAL" ) & (CONMED$MDC == "STEROIDS" |
                                                                                        CONMED$MDC == "STEROID/OTHER DRUG COMBINATIONS" ) & (CONMED$MDONG == 1),1,0                       )

CONMED$SABA_prescribed <- ifelse( (CONMED$MDG == "LEVALBUTEROL HYDROCHLORIDE" | CONMED$MDG == "LEVALBUTEROL TARTRATE" |
                                     CONMED$MDG == "ALBUTEROL/ALBUTEROL SULFATE" | CONMED$MDG == "ALBUTEROL/ALBUTEROL SULFATE/IPRATROPIUM BROMIDE") &  CONMED$MDONG == 1,1,0     )

CONMED$LAMA_prescribed <- ifelse( CONMED$MDG == "TIOTROPIUM BROMIDE" &  CONMED$MDONG == 1,1,0     )

CONMED2 <- CONMED %>%
  group_by(PATNUM) %>%
  summarise(Montelukast_prescribed = ifelse( sum(Montelukast_prescribed,na.rm=T) > 0,1,0   ),
            Theophylline_prescribed = ifelse( sum(Theophylline_prescribed,na.rm=T) > 0,1,0   ),
            Intranasal_seroid_prescribed = ifelse( sum(Intranasal_seroid_prescribed,na.rm=T) > 0,1,0),
            SABA_prescribed = ifelse( sum(SABA_prescribed,na.rm=T) > 0,1,0) , 
            LAMA_prescribed = ifelse( sum(LAMA_prescribed,na.rm=T) > 0,1,0) 
            )


spiro.test <- merge(spiro, demog[,c(2,38)], by = "PATNUM", all.x = T)

spiro.test2 <- spiro.test %>%
  filter( FEV1.x == FEV1.y & MESLABEL == "PFTPRE" & (VISITID=="V1" | VISITID=="V2" | VISITID=="V3")   ) %>%
  group_by(PATNUM) %>%
  summarise( FVC_preBD_L_Baseline = max( FVC ,na.rm=T) )


spiro.test3 <- spiro.test %>%
  filter( MESLABEL == "PFTPOST" & (VISITID=="V1" | VISITID=="V2" | VISITID=="V3")   ) %>%
  group_by(PATNUM) %>%
  summarise( FEV1_postBD_L_Baseline = max( FEV1.x ,na.rm=T),
             FEV1_postBD_PCT_Baseline = max( FEV1PTPR ,na.rm=T),
             FVC_postBD_L_Baseline = max( FVC ,na.rm=T))


acq2 <- acq %>%
  filter(VISIT == "Day 1 Visit 3")


exac2 <- exac %>%
  filter( is.na(EXCBDAY) == F & ( exac$STROID == 1 | exac$HOSP == 1  )   ) %>%
  group_by(PATNUM) %>%
  summarise(Number_severe_asthma_attacks_during_followup = n())


exac3 <- exac %>%
  filter( is.na(EXCBDAY) == F & ( exac$STROID == 1 | exac$HOSP == 1  )   ) %>%
  dplyr::select(c(2,31)) %>%
  group_by(PATNUM)%>%
  mutate(positionInCategory = 1:n())

exacT1 <- exac3 %>%
  filter(positionInCategory == 1) %>%
  rename( Time_to_First_attack = EXCBDAY )

exacT2 <- exac3 %>%
  filter(positionInCategory == 2)%>%
  rename( Time_to_2n_attack = EXCBDAY )

exacT3 <- exac3 %>%
  filter(positionInCategory == 3)%>%
  rename( Time_to_3n_attack = EXCBDAY )

exacT4 <- exac3 %>%
  filter(positionInCategory == 4)%>%
  rename( Time_to_4n_attack = EXCBDAY )

exacT5 <- exac3 %>%
  filter(positionInCategory == 5)%>%
  rename( Time_to_5n_attack = EXCBDAY )

			

disccw$EndFollowUp_Reason <- ifelse( disccw$DCCMP == "Subject completed study through Visit 13", 0,  
                                      ifelse( disccw$DCRS == "Lost to follow-up", 1,
                                              ifelse( disccw$DCRS == "Physician decision to withdraw subject from study" | disccw$DCRS == "Subject decision to withdraw"  , 2,
                                                      ifelse( disccw$DCRS == "Adverse Event", 4, NA        ))))







############################################################################################################
#' [Extracting data]
############################################################################################################

DataSet <- demog[,c(2,8,16,67,15,29,68)]

DataSet$Sequential_number <- as.numeric(NA)

DataSet$Enrolled_Trial_name <- "MILLY"

DataSet$Treatment_arm <- "PLACEBO"

DataSet <- DataSet[,c(1,8,9,10,2,3,4,5,6,7)]

DataSet <- merge(DataSet,medhx2[,c(1,2)], by = "PATNUM", all.x = T)

DataSet$Number_severe_attack_previous_12m <- as.numeric(NA)

DataSet$Number_hospitalisations_for_asthma_previous_12_months <- as.numeric(NA)

DataSet$Previous_ICU <- as.numeric(NA)

DataSet$Previous_Intubation <- as.numeric(NA)

DataSet <- merge(DataSet,demog[,c(2,63)], by = "PATNUM", all.x = T)

DataSet <- merge(DataSet,tohx[,c(2,37)], by = "PATNUM", all.x = T)

DataSet <- merge(DataSet,medhx2[,c(1,3,4)], by = "PATNUM", all.x = T)

DataSet <- merge(DataSet,demog[,c(2,69,35,61,62)], by = "PATNUM", all.x = T)

DataSet <- merge(DataSet,medhx2[,c(1,5,6)], by = "PATNUM", all.x = T)

DataSet$Previous_nasal_polypectomy <- as.numeric(NA)

DataSet$Adherence_PreTrial_quantity <- as.numeric(NA)

DataSet$Adherence_PreTrial_quality <- as.numeric(NA)

DataSet$Adherence_InTrial_quantity <- as.numeric(NA)

DataSet <- merge(DataSet,demog[,c(2,43)], by = "PATNUM", all.x = T)

DataSet <- merge(DataSet,acddeff2[,c(2,38)], by = "PATNUM", all.x = T)

DataSet <- merge(DataSet,CONMED2[,c(1,5)], by = "PATNUM", all.x = T)

DataSet <- merge(DataSet,acddeff3[,c(1,2)], by = "PATNUM", all.x = T)

DataSet$Any_ICS_prescribed_0no_1yes <- 1

DataSet$ICS_TYPE <- "FP"

DataSet <- merge(DataSet,demog[,c(2,44,14)], by = "PATNUM", all.x = T)

DataSet <- merge(DataSet,CONMED2[,c(1,6)], by = "PATNUM", all.x = T)

DataSet$maintenance_OCS_prescribed <- 0

DataSet$Mainteance_OCS_dose <- 0

DataSet <- merge(DataSet,CONMED2[,c(1,2,3,4)], by = "PATNUM", all.x = T)

DataSet$FEV1_predicted_L <- as.numeric(NA)

DataSet$FVC_predicted_L <- as.numeric(NA)

DataSet <- merge(DataSet,demog[,c(2,38,39)], by = "PATNUM", all.x = T)

DataSet <- merge(DataSet,spiro.test2[,c(1,2)], by = "PATNUM", all.x = T)

DataSet$FVC_preBD_PCT_Baseline <- as.numeric(NA)

DataSet <- merge(DataSet,spiro.test3[,c(1,2,3,4)], by = "PATNUM", all.x = T)

DataSet$FVC_postBD_PCT_Baseline <- as.numeric(NA)

DataSet <- merge(DataSet,demog[,c(2,40)], by = "PATNUM", all.x = T)

DataSet <- merge(DataSet,acddeff2[,c(2,40)], by = "PATNUM", all.x = T)

DataSet <- merge(DataSet,acq2[,c(2,30,31,32,33,34)], by = "PATNUM", all.x = T)

DataSet$ACQ_baseline_score_item6_RelieverUse <- as.numeric(NA)

DataSet$ACQ_baseline_score_item7_FEV1 <- as.numeric(NA)

DataSet$ACT_baseline_score <- as.numeric(NA)

DataSet <- merge(DataSet,demog[,c(2,36,37,46)], by = "PATNUM", all.x = T)

DataSet <- merge(DataSet,disccw[,c(2,30)], by = "PATNUM", all.x = T)

DataSet <- merge(DataSet,exac2[,c(1,2)], by = "PATNUM", all.x = T)
		
DataSet <- merge(DataSet,exacT1[,c(1,2)], by = "PATNUM", all.x = T)

DataSet <- merge(DataSet,exacT2[,c(1,2)], by = "PATNUM", all.x = T)

DataSet <- merge(DataSet,exacT3[,c(1,2)], by = "PATNUM", all.x = T)

DataSet <- merge(DataSet,exacT4[,c(1,2)], by = "PATNUM", all.x = T)

DataSet <- merge(DataSet,exacT5[,c(1,2)], by = "PATNUM", all.x = T)

DataSet <- merge(DataSet,disccw[,c(2,37)], by = "PATNUM", all.x = T)

DataSet$FEV1PREBD_L_52W <- as.numeric(NA)

DataSet$FEV1PREBD_PCT_52W <- as.numeric(NA)

DataSet$FEV1POSTBD_L_52W <- as.numeric(NA)

DataSet$FEV1POSTBD_PCT_52W <- as.numeric(NA)


DataSet <- DataSet %>%
  rename( Subject_ID = PATNUM,
          Age = AGE,
          Gender = SEX,
          Ethnicity = RACE, 
          Country = SITEFCNT,
          Smoking = SMOKE,
          Eczema = ECZEMA,
          AllergicRhinitis = RHINITIS,
          Airborne_allergen_sensitisation_on_testing = SKINTEST,
          Adherence_InTrial_quality = ICSCOMP,
          SABA_actuations_per_day_average_PreTrial = RESCUEB,
          ICS_Dose_PER_DAY = ICSDOSE,
          LABA_prescribed = LABA,
          FEV1_preBD_L_Baseline = FEV1,
          FEV1_preBD_PCT_Baseline = FEV1PP,
          FEV1_PCT_reversibility_postBD = FEV1REV,
          ACQ_baseline_score_mean = SYM,
          ACQ_baseline_score_item1_sleepawakenings = ACQ1,
          ACQ_baseline_score_item2_morningsymptoms = ACQ2, 
          ACQ_baseline_score_item3_activitylimitation = ACQ3,
          ACQ_baseline_score_item4_dyspnea = ACQ4, 
          ACQ_baseline_score_item5_wheezing = ACQ5,
          Blood_Eos_baseline_x10_9_cells_per_L = EOS, 
          FeNO_baseline_ppb = FENO,
          Total_IgE = IGE,
          Follow_up_duration_days = DAY)


DataSet$Gender <- ifelse( DataSet$Gender == "Male",1,0   )
DataSet$Smoking <- ifelse( DataSet$Smoking == "Never",0,1   )
DataSet$Eczema <- ifelse( DataSet$Eczema == "YES",1,0   )
DataSet$AllergicRhinitis <- ifelse( DataSet$AllergicRhinitis == "YES",1,0   )
DataSet$Airborne_allergen_sensitisation_on_testing <- ifelse( DataSet$Airborne_allergen_sensitisation_on_testing == "POSITIVE",1,0   )
DataSet$Adherence_PreTrial_quality <- ifelse( DataSet$Adherence_PreTrial_quality == "YES",1,0   )
DataSet$Adherence_InTrial_quality <- ifelse( DataSet$Adherence_InTrial_quality == "YES",1,0   )
DataSet$LABA_prescribed <- ifelse( DataSet$LABA_prescribed == "YES",1,0   )

DataSet$Number_severe_asthma_attacks_during_followup <- ifelse( is.na( DataSet$Number_severe_asthma_attacks_during_followup ) == T, 0, DataSet$Number_severe_asthma_attacks_during_followup  )

# Overwrite "ACQ_baseline_score_mean"

DataSet$ACQ_baseline_score_item1_sleepawakenings <- as.numeric(DataSet$ACQ_baseline_score_item1_sleepawakenings)
DataSet$ACQ_baseline_score_item2_morningsymptoms <- as.numeric(DataSet$ACQ_baseline_score_item2_morningsymptoms)
DataSet$ACQ_baseline_score_item3_activitylimitation <- as.numeric(DataSet$ACQ_baseline_score_item3_activitylimitation)
DataSet$ACQ_baseline_score_item4_dyspnea <- as.numeric(DataSet$ACQ_baseline_score_item4_dyspnea)
DataSet$ACQ_baseline_score_item5_wheezing <- as.numeric(DataSet$ACQ_baseline_score_item5_wheezing)

DataSet <- DataSet %>%
  group_by(Subject_ID) %>%
  mutate( ACQ_baseline_score_mean = sum(ACQ_baseline_score_item1_sleepawakenings,ACQ_baseline_score_item2_morningsymptoms,
                                         ACQ_baseline_score_item3_activitylimitation,ACQ_baseline_score_item4_dyspnea,
                                         ACQ_baseline_score_item5_wheezing)/5     )

write.xlsx(DataSet, "MILLY_clean.xlsx")
