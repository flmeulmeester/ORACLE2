

###########################################################################################################
#
# Project : Preparing data for STRATOS
#
###########################################################################################################


###########################################################################################################
#' [ Working directory initialisation]
###########################################################################################################

setwd("Y:/Simon_Couillard/ORACLE/STRATOS 1-2/STRATOS1-2/STRATOS1-2/2023_07_07_Data_clean_STRATOS")
getwd()

# Package importation

Packages <- c( "readxl","haven","ggplot2","dplyr","MASS", "summarytools", "gmodels",
               "jtools","car","openxlsx","extrafont","stargazer","readr")

lapply(Packages, library, character.only = TRUE)

#'*STRATOS 1 *

############################################################################################################
#' [Data import]
############################################################################################################

adsl <- read_sas("Y:/Simon_Couillard/ORACLE/STRATOS 1-2/STRATOS1-2/STRATOS1-2/STRATOS1/data/deid_adsl.sas7bdat")
rssu <- read_sas("Y:/Simon_Couillard/ORACLE/STRATOS 1-2/STRATOS1-2/STRATOS1-2/STRATOS1/data/deid_rssu.sas7bdat")
rsmh <- read_sas("Y:/Simon_Couillard/ORACLE/STRATOS 1-2/STRATOS1-2/STRATOS1-2/STRATOS1/data/deid_rsmh.sas7bdat")
adexsum <- read_sas("Y:/Simon_Couillard/ORACLE/STRATOS 1-2/STRATOS1-2/STRATOS1-2/STRATOS1/data/deid_adexsum.sas7bdat")
rscm <- read_sas("Y:/Simon_Couillard/ORACLE/STRATOS 1-2/STRATOS1-2/STRATOS1-2/STRATOS1/data/deid_rscm.sas7bdat")
rszk <- read_sas("Y:/Simon_Couillard/ORACLE/STRATOS 1-2/STRATOS1-2/STRATOS1-2/STRATOS1/data/deid_rszk.sas7bdat")
rslb <- read_sas("Y:/Simon_Couillard/ORACLE/STRATOS 1-2/STRATOS1-2/STRATOS1-2/STRATOS1/data/deid_rslb.sas7bdat")
adexac <- read_sas("Y:/Simon_Couillard/ORACLE/STRATOS 1-2/STRATOS1-2/STRATOS1-2/STRATOS1/data/deid_adexac.sas7bdat")
rsqs <- read_sas("Y:/Simon_Couillard/ORACLE/STRATOS 1-2/STRATOS1-2/STRATOS1-2/STRATOS1/deid_rsqs/deid_rsqs.sas7bdat")

############################################################################################################
#' [New variables]
############################################################################################################

adsl$Treatment_step <- ifelse( adsl$ICSCAT == "High", 5, ifelse( adsl$ICSCAT == "Medium",4, ifelse( adsl$ICSCAT == "Low", 3, NA    )   )   )

adsl$Number_hospitalisations_for_asthma_previous_12_months <- ifelse( adsl$COVAR11 == 0,"0",">=1"     )

rssu$Smoking <- ifelse(rssu$SUCAT == "TOBACCO" & rssu$SUOCCUR == "Y", 1,0)

rssu$Pack_years <- ifelse(rssu$SUCAT == "TOBACCO" & rssu$SUOCCUR == "Y", rssu$SUDOSE,0    )

rsmh$Psychiatric_disease <- ifelse( (rsmh$MHHLT == "Anxiety symptoms"
                                     | rsmh$MHHLT == "Attention deficit and disruptive behaviour disorders"
                                     | rsmh$MHHLT == "Depressive disorders" ) ,1,0       )



rsmh$Psy_disease_type <- ifelse(   (rsmh$MHHLT == "Anxiety symptoms"
                                    | rsmh$MHHLT == "Depressive disorders" ) ,1, ifelse(
                                      (rsmh$MHHLT == "Attention deficit and disruptive behaviour disorders") & rsmh$MHOCCUR == "Y",4,0 
                                             )            )



rsmh$Atopy_history <- ifelse(   (  (rsmh$MHTERM == "DIAGNOSIS OF ALLERGIC RHINITIS" | rsmh$MHTERM == "ECZEMA" ) & rsmh$MHOCCUR == "Y" ) | 
                                  (   (rsmh$MHDECOD == "Allergy to animal" | rsmh$MHDECOD == "Conjunctivitis allergic" |
                                         rsmh$MHDECOD == "Eczema" | rsmh$MHDECOD == "Food allergy" |
                                         rsmh$MHDECOD == "Mite allergy" | rsmh$MHDECOD == "Seasonal allergy") & rsmh$MHOCCUR == "Y" ),1,0     )


rsmh$Eczema <- ifelse(   (  (rsmh$MHTERM == "ECZEMA" ) & rsmh$MHOCCUR == "Y" ) | 
                           (   (rsmh$MHDECOD == "Eczema") & rsmh$MHOCCUR == "Y" ),1,0     )



rsmh$AllergicRhinitis <- ifelse(   (  (rsmh$MHTERM == "DIAGNOSIS OF ALLERGIC RHINITIS") & rsmh$MHOCCUR == "Y" ) | 
                                     (   (rsmh$MHDECOD == "Allergy to animal" | rsmh$MHDECOD == "Conjunctivitis allergic" |
                                            rsmh$MHDECOD == "Mite allergy" | rsmh$MHDECOD == "Seasonal allergy") & rsmh$MHOCCUR == "Y" ),1,0     )



rsmh$Airborne_allergen_sensitisation_on_testing <- ifelse( rsmh$MHTERM == "HISTORY OF POSITIVE ALLERGY TESTS" & rsmh$MHOCCUR == "Y", 1,0     )



rsmh$Chronic_Rhinosinusitis <- ifelse(   (  (rsmh$MHTERM == "CHRONIC SINUSITIS" ) & rsmh$MHOCCUR == "Y" ) | 
                                           (   (rsmh$MHDECOD == "Chronic sinusitis") & rsmh$MHOCCUR == "Y" ),1,0     )



rsmh$Nasal_polyposis <- ifelse(   (  (rsmh$MHTERM == "NASAL POLYPS" | rsmh$MHTERM == "PAST POLYPECTOMY" ) & rsmh$MHOCCUR == "Y" ) | 
                                    (   (rsmh$MHDECOD == "Nasal polypectomy" | rsmh$MHDECOD == "Nasal polyps"  ) & rsmh$MHOCCUR == "Y" ),1,0     )


rsmh$Previous_nasal_polypectomy <- ifelse(   (  (rsmh$MHTERM == "PAST POLYPECTOMY" ) & rsmh$MHOCCUR == "Y" ) | 
                                               (   (rsmh$MHDECOD == "Nasal polypectomy" ) & rsmh$MHOCCUR == "Y" ),1,0     )



rsmh_v2 <- rsmh %>%
  group_by(USUBJID) %>%
  summarise( Psychiatric_disease = ifelse( sum(Psychiatric_disease,na.rm=T) >=1,1,0),
             Psy_disease_type = ifelse( sum(Psy_disease_type,na.rm=T) >=1, max(Psy_disease_type,na.rm=T)   ,0),
             Atopy_history = ifelse( sum(Atopy_history,na.rm=T) >=1,1,0),
             Eczema = ifelse( sum(Eczema,na.rm=T) >=1,1,0),
             AllergicRhinitis = ifelse( sum(AllergicRhinitis,na.rm=T) >=1,1,0),
             Airborne_allergen_sensitisation_on_testing = ifelse( sum(Airborne_allergen_sensitisation_on_testing,na.rm=T) >=1,1,0),
             Chronic_Rhinosinusitis = ifelse( sum(Chronic_Rhinosinusitis,na.rm=T) >=1,1,0),
             Nasal_polyposis = ifelse( sum(Nasal_polyposis,na.rm=T) >=1,1,0),
             Previous_nasal_polypectomy = ifelse( sum(Previous_nasal_polypectomy,na.rm=T) >=1,1,0)
  )



adexsum.v1 <-  adexsum %>%
  filter(PARAMCD == "COMPINH" & APHASE == "Pre-treatment") 

adexsum.v1$Adherence_PreTrial_quality <- ifelse(adexsum.v1$AVAL >= 70, 1, ifelse(adexsum.v1$AVAL < 70,0, NA)  )
  
adexsum.v2 <-  adexsum %>%
  filter(PARAMCD == "COMPINH" & APHASE == "Treatment") %>%
  group_by(USUBJID) %>%
  summarise( Adherence_InTrial_quantity = mean(AVAL,na.rm=T)    )

adexsum.v2$Adherence_InTrial_quality <- ifelse(adexsum.v2$Adherence_InTrial_quantity >= 70, 1, ifelse(adexsum.v2$Adherence_InTrial_quantity < 70,0, NA)  )

adexsum.v3 <-  adexsum %>%
  filter(PARAMCD == "REAMOUNT" & APHASE == "Pre-treatment") %>%
  group_by(USUBJID) %>%
  summarise( SABA_actuations_per_day_average_PreTrial = mean(AVAL,na.rm=T)/14    )

adexsum.v4 <-  adexsum %>%
  filter(PARAMCD == "REAMOUNT" & APHASE == "Treatment") %>%
  group_by(USUBJID) %>%
  summarise( SABA_actuations_per_day_average_InTrial = mean(AVAL,na.rm=T)/14    )



rscm$SABA_prescribed <- ifelse( rscm$ANL05FL == "Y" & rscm$ANL12FL == "Y", 1, 0  )
 
adsl$ICS_TYPE <- ifelse( adsl$ICSCAT == "High", "FP>500", ifelse( adsl$ICSCAT == "Medium","FP>250-500", ifelse( adsl$ICSCAT == "Low", "FP=<250", NA    )   )   )

rscm$LABA_prescribed <- ifelse( rscm$ANL06FL == "Y" & rscm$ANL12FL == "Y",1,0  )   

rscm$LAMA_prescribed <- ifelse( rscm$ANL08FL == "Y" & rscm$ANL12FL == "Y",1,0  )   

rscm$Montelukast_prescribed <- ifelse( rscm$ANL09FL == "Y" & rscm$ANL12FL == "Y",1,0  )   

rscm$Theophylline_prescribed <- ifelse( rscm$ANL10FL == "Y" & rscm$ANL12FL == "Y",1,0  )   

rscm$Intranasal_seroid_prescribed <- ifelse( rscm$CMROUTE == "NASAL"  & ( rscm$ATCDTXT == "STEROIDS" |  rscm$ATCDTXT == "GLUCOCORTICOIDS") &  rscm$ANL12FL == "Y",1,0   )


rscm_short <- rscm %>%
  group_by(USUBJID) %>%
  summarise( SABA_prescribed = ifelse( sum(SABA_prescribed,na.rm=T) >=1,1,0),
             LABA_prescribed = ifelse( sum(LABA_prescribed,na.rm=T) >=1, 1,0),
             LAMA_prescribed = ifelse( sum(LAMA_prescribed,na.rm=T) >=1,1,0),
             Montelukast_prescribed = ifelse( sum(Montelukast_prescribed,na.rm=T) >=1,1,0),
             Theophylline_prescribed = ifelse( sum(Theophylline_prescribed,na.rm=T) >=1,1,0),
             Intranasal_seroid_prescribed = ifelse( sum(Intranasal_seroid_prescribed,na.rm=T) >=1,1,0)
  )





rszk.v1 <- rszk %>%
  filter( ZKTESTCD  == "FEV1" & (ZKBLFL == "Y" | VISIT == "Randomization" ) & ZKTPT == "Pre-dose"    )

rszk.v2 <- rszk %>%
  filter( ZKTESTCD  == "FEV1PP" & (ZKBLFL == "Y" | VISIT == "Randomization" ) & ZKTPT == "Pre-dose"    )

rszk.v3 <- rszk %>%
  filter( ZKTESTCD  == "FVC" & (ZKBLFL == "Y" | VISIT == "Randomization" ) & ZKTPT == "Pre-dose"    )

rszk.v4 <- rszk %>%
  filter( ZKTESTCD  == "FVCPP" & (ZKBLFL == "Y" | VISIT == "Randomization" ) & ZKTPT == "Pre-dose"    )



rszk.v1_post <- rszk %>%
  filter( ZKTESTCD  == "FEV1" & ZKBLFL == "Y" & (ZKTPT == "Post-dose" | ZKTPT == "Post-dose 15-20 min" | ZKTPT == "Post-dose 35 min" | ZKTPT == "Post-dose 55 min"  )    ) %>%
  group_by(USUBJID) %>%
summarise(FEV1_postBD_L_Baseline = max( ZKSTRESN , na.rm= T))

rszk.v2_post <- rszk %>%
  filter( ZKTESTCD  == "FEV1PP" & ZKBLFL == "Y" & (ZKTPT == "Post-dose" | ZKTPT == "Post-dose 15-20 min" | ZKTPT == "Post-dose 35 min" | ZKTPT == "Post-dose 55 min"  )    ) %>%
  group_by(USUBJID) %>%
  summarise(FEV1_postBD_PCT_Baseline = max( ZKSTRESN , na.rm= T))

rszk.v3_post <- rszk %>%
  filter( ZKTESTCD  == "FVC" & ZKBLFL == "Y" & (ZKTPT == "Post-dose" | ZKTPT == "Post-dose 15-20 min" | ZKTPT == "Post-dose 35 min" | ZKTPT == "Post-dose 55 min"  )    ) %>%
  group_by(USUBJID) %>%
  summarise(FVC_postBD_L_Baseline = max( ZKSTRESN , na.rm= T))

rszk.v4_post <- rszk %>%
  filter( ZKTESTCD  == "FVCPP" & ZKBLFL == "Y" & (ZKTPT == "Post-dose" | ZKTPT == "Post-dose 15-20 min" | ZKTPT == "Post-dose 35 min" | ZKTPT == "Post-dose 55 min"  )    ) %>%
  group_by(USUBJID) %>%
  summarise(FVC_postBD_PCT_Baseline = max( ZKSTRESN , na.rm= T))




rslb.v1 <- rslb %>%
  filter(LBTESTCD == "EOS" & LBBLFL == "Y")


rszk.v5 <- rszk %>%
  filter( ZKTESTCD  == "FENO" & ZKBLFL == "Y"   )


rslb.v2 <- rslb %>%
  filter(LBTESTCD == "IGE" & LBBLFL == "Y")

rslb.v2_short <- rslb.v2 %>%
  group_by(USUBJID) %>%
  summarise( Total_IgE = first(LBORRES)  )





adexac.v1 <- adexac %>%
  group_by(USUBJID) %>%
  summarise( Number_severe_asthma_attacks_during_followup = n()   )

adexac.v2 <- adexac %>%
  group_by(USUBJID) %>%
  dplyr::select(c(79, 36,38))   %>%
  mutate( Number_severe_asthma_attacks_during_followup = row_number()   )

adexac.v2.T1 <- adexac.v2 %>%
  filter(Number_severe_asthma_attacks_during_followup == 1)

adexac.v2.T2 <- adexac.v2 %>%
  filter(Number_severe_asthma_attacks_during_followup == 2)

adexac.v2.T3 <- adexac.v2 %>%
  filter(Number_severe_asthma_attacks_during_followup == 3)

adexac.v2.T4 <- adexac.v2 %>%
  filter(Number_severe_asthma_attacks_during_followup == 4)

adexac.v2.T5 <- adexac.v2 %>%
  filter(Number_severe_asthma_attacks_during_followup == 5)


adsl$EndFollowUp_Reason <- ifelse(adsl$COMPTRFL == "Y", "0", ifelse( adsl$COMPTRXL == "OTHER",adsl$COMPLFLD  , adsl$COMPTRXL   )  )


rszk.v6 <- rszk %>%
  filter( ZKTESTCD  == "FEV1" & AVISIT == "Week 52" &  ZKTPT == "Pre-dose"   ) %>%
  group_by(USUBJID) %>%
  summarise(FEV1PREBD_L_52W = max( ZKSTRESN , na.rm= T))

rszk.v7 <- rszk %>%
  filter( ZKTESTCD  == "FEV1PP" & AVISIT == "Week 52" &  ZKTPT == "Pre-dose"   ) %>%
  group_by(USUBJID) %>%
  summarise(FEV1PREBD_PCT_52W = max( ZKSTRESN , na.rm= T))

rszk.v8 <- rszk %>%
  filter( ZKTESTCD  == "FEV1" & AVISIT == "Week 52" &  (ZKTPT == "Post-dose" | ZKTPT == "Post-dose 15-20 min" | ZKTPT == "Post-dose 35 min" | ZKTPT == "Post-dose 55 min"  )  ) %>%
  group_by(USUBJID) %>%
  summarise(FEV1POSTBD_L_52W = max( ZKSTRESN , na.rm= T))

rszk.v9 <- rszk %>%
  filter( ZKTESTCD  == "FEV1PP" & AVISIT == "Week 52" &  (ZKTPT == "Post-dose" | ZKTPT == "Post-dose 15-20 min" | ZKTPT == "Post-dose 35 min" | ZKTPT == "Post-dose 55 min"  )  ) %>%
  group_by(USUBJID) %>%
  summarise(FEV1POSTBD_PCT_52W = max( ZKSTRESN , na.rm= T))

rscm_v2 <- rscm %>%
  filter(GINACOM != "" & ANL12FL == "Y" ) %>%
  dplyr::select(82,25,74,73)

rscm_v2$CMDOSTOT_mult <- ifelse(   rscm_v2$GINACOM == "BECLOMETASONE" & rscm_v2$CMDOSTOT != 1000, rscm_v2$CMDOSTOT*2.5, 
                                   ifelse( rscm_v2$GINACOM == "BECLOMETASONE" & rscm_v2$CMDOSTOT == 1000, rscm_v2$CMDOSTOT,
                                           ifelse( rscm_v2$GINACOM == "BUDESONIDE", rscm_v2$CMDOSTOT*2,
                                                   ifelse(rscm_v2$GINACOM == "CICLESONIDE", rscm_v2$CMDOSTOT*0.8,
                                                          ifelse(rscm_v2$GINACOM == "MOMETASONE", rscm_v2$CMDOSTOT*1.1,rscm_v2$CMDOSTOT
                                                           ) )) ))


rscm_v2_final <- rscm_v2 %>%
  group_by(USUBJID) %>%
  summarise(  ICS_Dose_PER_DAY = sum( CMDOSTOT_mult ,na.rm = T)   )

rsqs_short <- rsqs %>%
  dplyr::select(c(99,39,46,45))

rsqs_short_v1 <- rsqs_short %>%
  filter(QSTESTCD == "ACQ01" & QSBLFL == "Y")

rsqs_short_v2 <- rsqs_short %>%
  filter(QSTESTCD == "ACQ02" & QSBLFL == "Y")

rsqs_short_v3 <- rsqs_short %>%
  filter(QSTESTCD == "ACQ03" & QSBLFL == "Y")

rsqs_short_v4 <- rsqs_short %>%
  filter(QSTESTCD == "ACQ04" & QSBLFL == "Y")

rsqs_short_v5 <- rsqs_short %>%
  filter(QSTESTCD == "ACQ05" & QSBLFL == "Y")

rsqs_short_v6 <- rsqs_short %>%
  filter(QSTESTCD == "ACQ06" & QSBLFL == "Y")



rszk.supp <- rszk %>%
  filter( ZKTESTCD == "FEV1REV" & ZKBLFL == "Y"  ) 

rszk.supp$FEV1_PCT_reversibility_postBD <- rszk.supp$ZKSTRESN/1000

adsl <- adsl %>%
  group_by(USUBJID) %>%
  mutate( fup_max = max((COVAR03*365.25),COVAR04,na.rm=T)  )


############################################################################################################
#' [Extracting data]
############################################################################################################

DataSet <- adsl[,87]

DataSet$Sequential_number <- as.numeric(NA)

DataSet$Enrolled_Trial_name <- "STRATOS_1"

DataSet$Treatment_arm <- "PLACEBO"

DataSet <- merge(DataSet,adsl[,c(87, 86,10,85)], by = "USUBJID", all.x = T)

DataSet$Ethnicity <- as.numeric(NA)

DataSet$Country	 <- as.numeric(NA)

DataSet <- merge(DataSet,adsl[,c(87, 88)], by = "USUBJID", all.x = T)

DataSet$Any_severe_attack_previous_12m <- 1

DataSet <- merge(DataSet,adsl[,c(87, 64,89)], by = "USUBJID", all.x = T)

DataSet$Previous_ICU <- as.numeric(NA)

DataSet$Previous_Intubation	 <- as.numeric(NA)

DataSet <- merge(DataSet,rssu[,c(46,47,48)], by = "USUBJID", all.x = T)

DataSet <- DataSet[!duplicated(DataSet$USUBJID), ]

DataSet <- merge(DataSet,rsmh_v2[,c(1:10)], by = "USUBJID", all.x = T)

DataSet <- merge(DataSet,adexsum.v1[,c(71,40,72)], by = "USUBJID", all.x = T)

DataSet <- merge(DataSet,adexsum.v2[,c(1,2,3)], by = "USUBJID", all.x = T)

DataSet <- merge(DataSet,adexsum.v3[,c(1,2)], by = "USUBJID", all.x = T)

DataSet <- merge(DataSet,rscm_short[,c(1,2)], by = "USUBJID", all.x = T)

DataSet <- merge(DataSet,adexsum.v4[,c(1,2)], by = "USUBJID", all.x = T)

DataSet$Any_ICS_prescribed <- 1

DataSet <- merge(DataSet,adsl[,c(87, 90)], by = "USUBJID", all.x = T)

DataSet <- merge(DataSet,rscm_v2_final[,c(1,2)], by = "USUBJID", all.x = T)

DataSet <- merge(DataSet,rscm_short[,c(1,3,4)], by = "USUBJID", all.x = T)

DataSet$maintenance_OCS_prescribed <- 0

DataSet$Mainteance_OCS_dose <- 0

DataSet <- merge(DataSet,rscm_short[,c(1,5,6,7)], by = "USUBJID", all.x = T)

DataSet$FEV1_predicted_L <- as.numeric(NA)

DataSet$FVC_predicted_L <- as.numeric(NA)

DataSet <- merge(DataSet,rszk.v1[,c(95,46)], by = "USUBJID", all.x = T)

DataSet <- DataSet %>%
  rename(  FEV1_preBD_L_Baseline = ZKSTRESN )

DataSet <- merge(DataSet,rszk.v2[,c(95,46)], by = "USUBJID", all.x = T)

DataSet <- DataSet %>%
  rename(  FEV1_preBD_PCT_Baseline = ZKSTRESN )

DataSet <- merge(DataSet,rszk.v3[,c(95,46)], by = "USUBJID", all.x = T)

DataSet <- DataSet %>%
  rename(  FVC_preBD_L_Baseline = ZKSTRESN )

DataSet <- merge(DataSet,rszk.v4[,c(95,46)], by = "USUBJID", all.x = T)

DataSet <- DataSet %>%
  rename(  FVC_preBD_PCT_Baseline = ZKSTRESN )

DataSet <- merge(DataSet,rszk.v1_post, by = "USUBJID", all.x = T)

DataSet <- merge(DataSet,rszk.v2_post, by = "USUBJID", all.x = T)

DataSet <- merge(DataSet,rszk.v3_post, by = "USUBJID", all.x = T)

DataSet <- merge(DataSet,rszk.v4_post, by = "USUBJID", all.x = T)



DataSet <- merge(DataSet,rszk.supp[,c(95,96)], by = "USUBJID", all.x = T)

DataSet$FEV1_PCT_reversibility_postBD <- DataSet$FEV1_PCT_reversibility_postBD/DataSet$FEV1_preBD_L_Baseline



DataSet$ACQ_baseline_score_mean <- as.numeric(NA)

DataSet <- merge(DataSet,rsqs_short_v1[,c(1,4)], by = "USUBJID", all.x = T)

DataSet <- DataSet %>%
  rename(  ACQ_baseline_score_item1_sleepawakenings = QSSTRESN )

DataSet <- merge(DataSet,rsqs_short_v2[,c(1,4)], by = "USUBJID", all.x = T)

DataSet <- DataSet %>%
  rename( ACQ_baseline_score_item2_morningsymptoms  = QSSTRESN )

DataSet <- merge(DataSet,rsqs_short_v3[,c(1,4)], by = "USUBJID", all.x = T)

DataSet <- DataSet %>%
  rename(  ACQ_baseline_score_item3_activitylimitation = QSSTRESN )

DataSet <- merge(DataSet,rsqs_short_v4[,c(1,4)], by = "USUBJID", all.x = T)

DataSet <- DataSet %>%
  rename( ACQ_baseline_score_item4_dyspnea  = QSSTRESN )

DataSet <- merge(DataSet,rsqs_short_v5[,c(1,4)], by = "USUBJID", all.x = T)

DataSet <- DataSet %>%
  rename(  ACQ_baseline_score_item5_wheezing = QSSTRESN )

DataSet <- merge(DataSet,rsqs_short_v6[,c(1,4)], by = "USUBJID", all.x = T)

DataSet <- DataSet %>%
  rename(  ACQ_baseline_score_item6_RelieverUse = QSSTRESN )

DataSet$ACQ_baseline_score_item7_FEV1 <- as.numeric(NA)

DataSet$ACT_baseline_score <- as.numeric(NA)

DataSet <- merge(DataSet,rslb.v1[,c(105,31)], by = "USUBJID", all.x = T)

DataSet <- merge(DataSet,rszk.v5[,c(95,46)], by = "USUBJID", all.x = T)

DataSet <- merge(DataSet,rslb.v2_short[,c(1,2)], by = "USUBJID", all.x = T)

DataSet <- merge(DataSet,adsl[,c(87,92)], by = "USUBJID", all.x = T)

DataSet <- merge(DataSet,adexac.v1[,c(1,2)], by = "USUBJID", all.x = T)

DataSet$Number_severe_asthma_attacks_during_followup <- ifelse( is.na(DataSet$Number_severe_asthma_attacks_during_followup) == T, 0 , DataSet$Number_severe_asthma_attacks_during_followup    )

DataSet <- merge(DataSet,adexac.v2.T1[,c(1,3)], by = "USUBJID", all.x = T)

DataSet <- DataSet %>%
  rename(  Time_to_First_attack = ASTDY )

DataSet <- merge(DataSet,adexac.v2.T2[,c(1,3)], by = "USUBJID", all.x = T)

DataSet <- DataSet %>%
  rename(  Time_to_2n_attack = ASTDY )

DataSet <- merge(DataSet,adexac.v2.T3[,c(1,3)], by = "USUBJID", all.x = T)

DataSet <- DataSet %>%
  rename(  Time_to_3n_attack = ASTDY )

DataSet <- merge(DataSet,adexac.v2.T4[,c(1,3)], by = "USUBJID", all.x = T)

DataSet <- DataSet %>%
  rename(  Time_to_4n_attack = ASTDY )

DataSet <- merge(DataSet,adexac.v2.T5[,c(1,3)], by = "USUBJID", all.x = T)

DataSet <- DataSet %>%
  rename(  Time_to_5n_attack = ASTDY )

DataSet <- merge(DataSet,adsl[,c(87,91)], by = "USUBJID", all.x = T)

DataSet <- merge(DataSet,rszk.v6, by = "USUBJID", all.x = T)

DataSet <- merge(DataSet,rszk.v7, by = "USUBJID", all.x = T)

DataSet <- merge(DataSet,rszk.v8, by = "USUBJID", all.x = T)

DataSet <- merge(DataSet,rszk.v9, by = "USUBJID", all.x = T)

DataSet <- DataSet %>% 
  group_by(USUBJID) %>%
  mutate( ACQ_baseline_score_mean = ifelse( is.na(ACQ_baseline_score_item1_sleepawakenings) == T,NA,      sum(ACQ_baseline_score_item1_sleepawakenings,	
                                                 ACQ_baseline_score_item2_morningsymptoms,	
                                                 ACQ_baseline_score_item3_activitylimitation,	
                                                 ACQ_baseline_score_item4_dyspnea,	
                                                 ACQ_baseline_score_item5_wheezing,na.rm=T)/5 )  )

DataSet <- DataSet %>%
  rename(  Subject_ID = USUBJID ,
           Age = AGE,
           Gender_M = SEX,
           BMI = BLBMI,
           Number_severe_attack_previous_12m = COVAR06,
           Adherence_PreTrial_quantity = AVAL,
           Blood_Eos_baseline_x10_9_cells_per_L = LBSTRESN,
           FeNO_baseline_ppb = ZKSTRESN,
           Follow_up_duration_days = fup_max
           )


DataSet$Gender_M <- ifelse( DataSet$Gender_M == "M", 1, 0      )

DataSet <- DataSet[,c(2,1,3:78)]

DataSet$BMI <- ifelse( DataSet$BMI == "." , "", DataSet$BMI    )


write.xlsx(DataSet, "STRATOS_1_clean.xlsx")





#'*STRATOS 2 *

############################################################################################################
#' [Data import]
############################################################################################################

adsl <- read_sas("Y:/Simon_Couillard/ORACLE/STRATOS 1-2/STRATOS1-2/STRATOS1-2/STRATOS2/data/deid_adsl.sas7bdat")
rssu <- read_sas("Y:/Simon_Couillard/ORACLE/STRATOS 1-2/STRATOS1-2/STRATOS1-2/STRATOS2/data/deid_rssu.sas7bdat")
rsmh <- read_sas("Y:/Simon_Couillard/ORACLE/STRATOS 1-2/STRATOS1-2/STRATOS1-2/STRATOS2/data/deid_rsmh.sas7bdat")
adexsum <- read_sas("Y:/Simon_Couillard/ORACLE/STRATOS 1-2/STRATOS1-2/STRATOS1-2/STRATOS2/data/deid_adexsum.sas7bdat")
rscm <- read_sas("Y:/Simon_Couillard/ORACLE/STRATOS 1-2/STRATOS1-2/STRATOS1-2/STRATOS2/data/deid_rscm.sas7bdat")
rszk <- read_sas("Y:/Simon_Couillard/ORACLE/STRATOS 1-2/STRATOS1-2/STRATOS1-2/STRATOS2/data/deid_rszk.sas7bdat")
rslb <- read_sas("Y:/Simon_Couillard/ORACLE/STRATOS 1-2/STRATOS1-2/STRATOS1-2/STRATOS2/data/deid_rslb.sas7bdat")
adexac <- read_sas("Y:/Simon_Couillard/ORACLE/STRATOS 1-2/STRATOS1-2/STRATOS1-2/STRATOS2/data/deid_adexac.sas7bdat")
rsqs <- read_sas("Y:/Simon_Couillard/ORACLE/STRATOS 1-2/STRATOS1-2/STRATOS1-2/STRATOS2/deid_rsqs/deid_rsqs.sas7bdat")


############################################################################################################
#' [New variables]
############################################################################################################

adsl$Treatment_step <- ifelse( adsl$ICSCAT == "High", 5, ifelse( adsl$ICSCAT == "Medium",4, ifelse( adsl$ICSCAT == "Low", 3, NA    )   )   )

adsl$Number_hospitalisations_for_asthma_previous_12_months <- ifelse( adsl$COVAR11 == 0,"0",">=1"     )

rssu$Smoking <- ifelse(rssu$SUCAT == "TOBACCO" & rssu$SUOCCUR == "Y", 1,0)

rssu$Pack_years <- ifelse(rssu$SUCAT == "TOBACCO" & rssu$SUOCCUR == "Y", rssu$SUDOSE,0    )

rsmh$Psychiatric_disease <- ifelse( (rsmh$MHHLT == "Anxiety symptoms"
                                     | rsmh$MHHLT == "Attention deficit and disruptive behaviour disorders"
                                     | rsmh$MHHLT == "Depressive disorders" ),1,0       )



rsmh$Psy_disease_type <- ifelse(   (rsmh$MHHLT == "Anxiety symptoms"
                                    | rsmh$MHHLT == "Depressive disorders" ) ,1, ifelse(
                                      (rsmh$MHHLT == "Attention deficit and disruptive behaviour disorders") & rsmh$MHOCCUR == "Y",4,0 
                                    )            )



rsmh$Atopy_history <- ifelse(   (  (rsmh$MHTERM == "DIAGNOSIS OF ALLERGIC RHINITIS" | rsmh$MHTERM == "ECZEMA" ) & rsmh$MHOCCUR == "Y" ) | 
                                  (   (rsmh$MHDECOD == "Allergy to animal" | rsmh$MHDECOD == "Conjunctivitis allergic" |
                                         rsmh$MHDECOD == "Eczema" | rsmh$MHDECOD == "Food allergy" |
                                         rsmh$MHDECOD == "Mite allergy" | rsmh$MHDECOD == "Seasonal allergy") & rsmh$MHOCCUR == "Y" ),1,0     )


rsmh$Eczema <- ifelse(   (  (rsmh$MHTERM == "ECZEMA" ) & rsmh$MHOCCUR == "Y" ) | 
                           (   (rsmh$MHDECOD == "Eczema") & rsmh$MHOCCUR == "Y" ),1,0     )



rsmh$AllergicRhinitis <- ifelse(   (  (rsmh$MHTERM == "DIAGNOSIS OF ALLERGIC RHINITIS") & rsmh$MHOCCUR == "Y" ) | 
                                     (   (rsmh$MHDECOD == "Allergy to animal" | rsmh$MHDECOD == "Conjunctivitis allergic" |
                                            rsmh$MHDECOD == "Mite allergy" | rsmh$MHDECOD == "Seasonal allergy") & rsmh$MHOCCUR == "Y" ),1,0     )



rsmh$Airborne_allergen_sensitisation_on_testing <- ifelse( rsmh$MHTERM == "HISTORY OF POSITIVE ALLERGY TESTS" & rsmh$MHOCCUR == "Y", 1,0     )



rsmh$Chronic_Rhinosinusitis <- ifelse(   (  (rsmh$MHTERM == "CHRONIC SINUSITIS" ) & rsmh$MHOCCUR == "Y" ) | 
                                           (   (rsmh$MHDECOD == "Chronic sinusitis") & rsmh$MHOCCUR == "Y" ),1,0     )



rsmh$Nasal_polyposis <- ifelse(   (  (rsmh$MHTERM == "NASAL POLYPS" | rsmh$MHTERM == "PAST POLYPECTOMY" ) & rsmh$MHOCCUR == "Y" ) | 
                                    (   (rsmh$MHDECOD == "Nasal polypectomy" | rsmh$MHDECOD == "Nasal polyps"  ) & rsmh$MHOCCUR == "Y" ),1,0     )


rsmh$Previous_nasal_polypectomy <- ifelse(   (  (rsmh$MHTERM == "PAST POLYPECTOMY" ) & rsmh$MHOCCUR == "Y" ) | 
                                               (   (rsmh$MHDECOD == "Nasal polypectomy" ) & rsmh$MHOCCUR == "Y" ),1,0     )



rsmh_v2 <- rsmh %>%
  group_by(USUBJID) %>%
  summarise( Psychiatric_disease = ifelse( sum(Psychiatric_disease,na.rm=T) >=1,1,0),
             Psy_disease_type = ifelse( sum(Psy_disease_type,na.rm=T) >=1, max(Psy_disease_type,na.rm=T)   ,0),
             Atopy_history = ifelse( sum(Atopy_history,na.rm=T) >=1,1,0),
             Eczema = ifelse( sum(Eczema,na.rm=T) >=1,1,0),
             AllergicRhinitis = ifelse( sum(AllergicRhinitis,na.rm=T) >=1,1,0),
             Airborne_allergen_sensitisation_on_testing = ifelse( sum(Airborne_allergen_sensitisation_on_testing,na.rm=T) >=1,1,0),
             Chronic_Rhinosinusitis = ifelse( sum(Chronic_Rhinosinusitis,na.rm=T) >=1,1,0),
             Nasal_polyposis = ifelse( sum(Nasal_polyposis,na.rm=T) >=1,1,0),
             Previous_nasal_polypectomy = ifelse( sum(Previous_nasal_polypectomy,na.rm=T) >=1,1,0)
  )



adexsum.v1 <-  adexsum %>%
  filter(PARAMCD == "COMPINH" & APHASE == "Pre-treatment") 

adexsum.v1$Adherence_PreTrial_quality <- ifelse(adexsum.v1$AVAL >= 70, 1, ifelse(adexsum.v1$AVAL < 70,0, NA)  )

adexsum.v2 <-  adexsum %>%
  filter(PARAMCD == "COMPINH" & APHASE == "Treatment") %>%
  group_by(USUBJID) %>%
  summarise( Adherence_InTrial_quantity = mean(AVAL,na.rm=T)    )

adexsum.v2$Adherence_InTrial_quality <- ifelse(adexsum.v2$Adherence_InTrial_quantity >= 70, 1, ifelse(adexsum.v2$Adherence_InTrial_quantity < 70,0, NA)  )

adexsum.v3 <-  adexsum %>%
  filter(PARAMCD == "REAMOUNT" & APHASE == "Pre-treatment") %>%
  group_by(USUBJID) %>%
  summarise( SABA_actuations_per_day_average_PreTrial = mean(AVAL,na.rm=T)/14    )

adexsum.v4 <-  adexsum %>%
  filter(PARAMCD == "REAMOUNT" & APHASE == "Treatment") %>%
  group_by(USUBJID) %>%
  summarise( SABA_actuations_per_day_average_InTrial = mean(AVAL,na.rm=T)/14    )



rscm$SABA_prescribed <- ifelse( rscm$ANL05FL == "Y" & rscm$ANL12FL == "Y", 1, 0  )

adsl$ICS_TYPE <- ifelse( adsl$ICSCAT == "High", "FP>500", ifelse( adsl$ICSCAT == "Medium","FP>250-500", ifelse( adsl$ICSCAT == "Low", "FP=<250", NA    )   )   )

rscm$LABA_prescribed <- ifelse( rscm$ANL06FL == "Y" & rscm$ANL12FL == "Y",1,0  )   

rscm$LAMA_prescribed <- ifelse( rscm$ANL08FL == "Y" & rscm$ANL12FL == "Y",1,0  )   

rscm$Montelukast_prescribed <- ifelse( rscm$ANL09FL == "Y" & rscm$ANL12FL == "Y",1,0  )   

rscm$Theophylline_prescribed <- ifelse( rscm$ANL10FL == "Y" & rscm$ANL12FL == "Y",1,0  )   

rscm$Intranasal_seroid_prescribed <- ifelse( rscm$CMROUTE == "NASAL"  & ( rscm$ATCDTXT == "STEROIDS" |  rscm$ATCDTXT == "GLUCOCORTICOIDS") &  rscm$ANL12FL == "Y",1,0   )


rscm_short <- rscm %>%
  group_by(USUBJID) %>%
  summarise( SABA_prescribed = ifelse( sum(SABA_prescribed,na.rm=T) >=1,1,0),
             LABA_prescribed = ifelse( sum(LABA_prescribed,na.rm=T) >=1, 1,0),
             LAMA_prescribed = ifelse( sum(LAMA_prescribed,na.rm=T) >=1,1,0),
             Montelukast_prescribed = ifelse( sum(Montelukast_prescribed,na.rm=T) >=1,1,0),
             Theophylline_prescribed = ifelse( sum(Theophylline_prescribed,na.rm=T) >=1,1,0),
             Intranasal_seroid_prescribed = ifelse( sum(Intranasal_seroid_prescribed,na.rm=T) >=1,1,0)
  )





rszk.v1 <- rszk %>%
  filter( ZKTESTCD  == "FEV1" & (ZKBLFL == "Y" | VISIT == "Randomization" ) & ZKTPT == "Pre-dose"    )

rszk.v2 <- rszk %>%
  filter( ZKTESTCD  == "FEV1PP" & (ZKBLFL == "Y" | VISIT == "Randomization" ) & ZKTPT == "Pre-dose"    )

rszk.v3 <- rszk %>%
  filter( ZKTESTCD  == "FVC" & (ZKBLFL == "Y" | VISIT == "Randomization" ) & ZKTPT == "Pre-dose"    )

rszk.v4 <- rszk %>%
  filter( ZKTESTCD  == "FVCPP" & (ZKBLFL == "Y" | VISIT == "Randomization" ) & ZKTPT == "Pre-dose"    )



rszk.v1_post <- rszk %>%
  filter( ZKTESTCD  == "FEV1" & ZKBLFL == "Y" & (ZKTPT == "Post-dose" | ZKTPT == "Post-dose 15-20 min" | ZKTPT == "Post-dose 35 min" | ZKTPT == "Post-dose 55 min"  )    ) %>%
  group_by(USUBJID) %>%
  summarise(FEV1_postBD_L_Baseline = max( ZKSTRESN , na.rm= T))

rszk.v2_post <- rszk %>%
  filter( ZKTESTCD  == "FEV1PP" & ZKBLFL == "Y" & (ZKTPT == "Post-dose" | ZKTPT == "Post-dose 15-20 min" | ZKTPT == "Post-dose 35 min" | ZKTPT == "Post-dose 55 min"  )    ) %>%
  group_by(USUBJID) %>%
  summarise(FEV1_postBD_PCT_Baseline = max( ZKSTRESN , na.rm= T))

rszk.v3_post <- rszk %>%
  filter( ZKTESTCD  == "FVC" & ZKBLFL == "Y" & (ZKTPT == "Post-dose" | ZKTPT == "Post-dose 15-20 min" | ZKTPT == "Post-dose 35 min" | ZKTPT == "Post-dose 55 min"  )    ) %>%
  group_by(USUBJID) %>%
  summarise(FVC_postBD_L_Baseline = max( ZKSTRESN , na.rm= T))

rszk.v4_post <- rszk %>%
  filter( ZKTESTCD  == "FVCPP" & ZKBLFL == "Y" & (ZKTPT == "Post-dose" | ZKTPT == "Post-dose 15-20 min" | ZKTPT == "Post-dose 35 min" | ZKTPT == "Post-dose 55 min"  )    ) %>%
  group_by(USUBJID) %>%
  summarise(FVC_postBD_PCT_Baseline = max( ZKSTRESN , na.rm= T))




rslb.v1 <- rslb %>%
  filter(LBTESTCD == "EOS" & LBBLFL == "Y")


rszk.v5 <- rszk %>%
  filter( ZKTESTCD  == "FENO" & ZKBLFL == "Y"   )


rslb.v2 <- rslb %>%
  filter(LBTESTCD == "IGE" & LBBLFL == "Y")

rslb.v2_short <- rslb.v2 %>%
  group_by(USUBJID) %>%
  summarise( Total_IgE = first(LBORRES)     )





adexac.v1 <- adexac %>%
  group_by(USUBJID) %>%
  summarise( Number_severe_asthma_attacks_during_followup = n()   )

adexac.v2 <- adexac %>%
  group_by(USUBJID) %>%
  dplyr::select(c(69, 22,24))   %>%
  mutate( Number_severe_asthma_attacks_during_followup = row_number()   )

adexac.v2.T1 <- adexac.v2 %>%
  filter(Number_severe_asthma_attacks_during_followup == 1)

adexac.v2.T2 <- adexac.v2 %>%
  filter(Number_severe_asthma_attacks_during_followup == 2)

adexac.v2.T3 <- adexac.v2 %>%
  filter(Number_severe_asthma_attacks_during_followup == 3)

adexac.v2.T4 <- adexac.v2 %>%
  filter(Number_severe_asthma_attacks_during_followup == 4)

adexac.v2.T5 <- adexac.v2 %>%
  filter(Number_severe_asthma_attacks_during_followup == 5)


adsl$EndFollowUp_Reason <- ifelse(adsl$COMPTRFL == "Y", "0", ifelse( adsl$COMPTRXL == "OTHER",adsl$COMPLFLD  , adsl$COMPTRXL   )  )


rszk.v6 <- rszk %>%
  filter( ZKTESTCD  == "FEV1" & AVISIT == "Week 52" &  ZKTPT == "Pre-dose"   ) %>%
  group_by(USUBJID) %>%
  summarise(FEV1PREBD_L_52W = max( ZKSTRESN , na.rm= T))

rszk.v7 <- rszk %>%
  filter( ZKTESTCD  == "FEV1PP" & AVISIT == "Week 52" &  ZKTPT == "Pre-dose"   ) %>%
  group_by(USUBJID) %>%
  summarise(FEV1PREBD_PCT_52W = max( ZKSTRESN , na.rm= T))

rszk.v8 <- rszk %>%
  filter( ZKTESTCD  == "FEV1" & AVISIT == "Week 52" &  (ZKTPT == "Post-dose" | ZKTPT == "Post-dose 15-20 min" | ZKTPT == "Post-dose 35 min" | ZKTPT == "Post-dose 55 min"  )  ) %>%
  group_by(USUBJID) %>%
  summarise(FEV1POSTBD_L_52W = max( ZKSTRESN , na.rm= T))

rszk.v9 <- rszk %>%
  filter( ZKTESTCD  == "FEV1PP" & AVISIT == "Week 52" &  (ZKTPT == "Post-dose" | ZKTPT == "Post-dose 15-20 min" | ZKTPT == "Post-dose 35 min" | ZKTPT == "Post-dose 55 min"  )  ) %>%
  group_by(USUBJID) %>%
  summarise(FEV1POSTBD_PCT_52W = max( ZKSTRESN , na.rm= T))

rscm_v2 <- rscm %>%
  filter(GINACOM != "" & ANL12FL == "Y" ) %>%
  dplyr::select(88,30,79,80)

rscm_v2$CMDOSTOT_mult <- ifelse(   rscm_v2$GINACOM == "BECLOMETASONE" & rscm_v2$CMDOSTOT != 1000, rscm_v2$CMDOSTOT*2.5, 
                                   ifelse( rscm_v2$GINACOM == "BECLOMETASONE" & rscm_v2$CMDOSTOT == 1000, rscm_v2$CMDOSTOT,
                                           ifelse( rscm_v2$GINACOM == "BUDESONIDE", rscm_v2$CMDOSTOT*2,
                                                   ifelse(rscm_v2$GINACOM == "CICLESONIDE", rscm_v2$CMDOSTOT*0.8,
                                                          ifelse(rscm_v2$GINACOM == "MOMETASONE", rscm_v2$CMDOSTOT*1.1,rscm_v2$CMDOSTOT
                                                          ) )) ))


rscm_v2_final <- rscm_v2 %>%
  group_by(USUBJID) %>%
  summarise(  ICS_Dose_PER_DAY = sum( CMDOSTOT_mult ,na.rm = T)   )

rsqs_short <- rsqs %>%
  dplyr::select(c(86,26,33,32))

rsqs_short_v1 <- rsqs_short %>%
  filter(QSTESTCD == "ACQ01" & QSBLFL == "Y")

rsqs_short_v2 <- rsqs_short %>%
  filter(QSTESTCD == "ACQ02" & QSBLFL == "Y")

rsqs_short_v3 <- rsqs_short %>%
  filter(QSTESTCD == "ACQ03" & QSBLFL == "Y")

rsqs_short_v4 <- rsqs_short %>%
  filter(QSTESTCD == "ACQ04" & QSBLFL == "Y")

rsqs_short_v5 <- rsqs_short %>%
  filter(QSTESTCD == "ACQ05" & QSBLFL == "Y")

rsqs_short_v6 <- rsqs_short %>%
  filter(QSTESTCD == "ACQ06" & QSBLFL == "Y")




rszk.supp <- rszk %>%
  filter( ZKTESTCD == "FEV1REV" & ZKBLFL == "Y"  ) 

rszk.supp$FEV1_PCT_reversibility_postBD <- rszk.supp$ZKSTRESN/1000



############################################################################################################
#' [Extracting data]
############################################################################################################


DataSet <- adsl[,95]

DataSet$Sequential_number <- as.numeric(NA)

DataSet$Enrolled_Trial_name <- "STRATOS_2"

DataSet$Treatment_arm <- "PLACEBO"

DataSet <- merge(DataSet,adsl[,c(95, 94,10,93)], by = "USUBJID", all.x = T)

DataSet$Ethnicity <- as.numeric(NA)

DataSet$Country	 <- as.numeric(NA)

DataSet <- merge(DataSet,adsl[,c(95, 96)], by = "USUBJID", all.x = T)

DataSet$Any_severe_attack_previous_12m <- 1

DataSet <- merge(DataSet,adsl[,c(95, 69,97)], by = "USUBJID", all.x = T)

DataSet$Previous_ICU <- as.numeric(NA)

DataSet$Previous_Intubation	 <- as.numeric(NA)

DataSet <- merge(DataSet,rssu[,c(51,52,53)], by = "USUBJID", all.x = T)

DataSet <- merge(DataSet,rsmh_v2[,c(1:10)], by = "USUBJID", all.x = T)

DataSet <- merge(DataSet,adexsum.v1[,c(57,26,58)], by = "USUBJID", all.x = T)

DataSet <- merge(DataSet,adexsum.v2[,c(1,2,3)], by = "USUBJID", all.x = T)

DataSet <- merge(DataSet,adexsum.v3[,c(1,2)], by = "USUBJID", all.x = T)

DataSet <- merge(DataSet,rscm_short[,c(1,2)], by = "USUBJID", all.x = T)

DataSet <- merge(DataSet,adexsum.v4[,c(1,2)], by = "USUBJID", all.x = T)

DataSet$Any_ICS_prescribed <- 1

DataSet <- merge(DataSet,adsl[,c(95, 98)], by = "USUBJID", all.x = T)

DataSet <- merge(DataSet,rscm_v2_final[,c(1,2)], by = "USUBJID", all.x = T)

DataSet <- merge(DataSet,rscm_short[,c(1,3,4)], by = "USUBJID", all.x = T)

DataSet$maintenance_OCS_prescribed <- 0

DataSet$Mainteance_OCS_dose <- 0

DataSet <- merge(DataSet,rscm_short[,c(1,5,6,7)], by = "USUBJID", all.x = T)

DataSet$FEV1_predicted_L <- as.numeric(NA)

DataSet$FVC_predicted_L <- as.numeric(NA)

DataSet <- merge(DataSet,rszk.v1[,c(82,33)], by = "USUBJID", all.x = T)

DataSet <- DataSet %>%
  rename(  FEV1_preBD_L_Baseline = ZKSTRESN )

DataSet <- merge(DataSet,rszk.v2[,c(82,33)], by = "USUBJID", all.x = T)

DataSet <- DataSet %>%
  rename(  FEV1_preBD_PCT_Baseline = ZKSTRESN )

DataSet <- merge(DataSet,rszk.v3[,c(82,33)], by = "USUBJID", all.x = T)

DataSet <- DataSet %>%
  rename(  FVC_preBD_L_Baseline = ZKSTRESN )

DataSet <- merge(DataSet,rszk.v4[,c(82,33)], by = "USUBJID", all.x = T)

DataSet <- DataSet %>%
  rename(  FVC_preBD_PCT_Baseline = ZKSTRESN )

DataSet <- merge(DataSet,rszk.v1_post, by = "USUBJID", all.x = T)

DataSet <- merge(DataSet,rszk.v2_post, by = "USUBJID", all.x = T)

DataSet <- merge(DataSet,rszk.v3_post, by = "USUBJID", all.x = T)

DataSet <- merge(DataSet,rszk.v4_post, by = "USUBJID", all.x = T)

DataSet <- merge(DataSet,rszk.supp[,c(82,83)], by = "USUBJID", all.x = T)

DataSet$FEV1_PCT_reversibility_postBD <- DataSet$FEV1_PCT_reversibility_postBD/DataSet$FEV1_preBD_L_Baseline

DataSet$ACQ_baseline_score_mean <- as.numeric(NA)

DataSet <- merge(DataSet,rsqs_short_v1[,c(1,4)], by = "USUBJID", all.x = T)

DataSet <- DataSet %>%
  rename(  ACQ_baseline_score_item1_sleepawakenings = QSSTRESN )

DataSet <- merge(DataSet,rsqs_short_v2[,c(1,4)], by = "USUBJID", all.x = T)

DataSet <- DataSet %>%
  rename( ACQ_baseline_score_item2_morningsymptoms  = QSSTRESN )

DataSet <- merge(DataSet,rsqs_short_v3[,c(1,4)], by = "USUBJID", all.x = T)

DataSet <- DataSet %>%
  rename(  ACQ_baseline_score_item3_activitylimitation = QSSTRESN )

DataSet <- merge(DataSet,rsqs_short_v4[,c(1,4)], by = "USUBJID", all.x = T)

DataSet <- DataSet %>%
  rename( ACQ_baseline_score_item4_dyspnea  = QSSTRESN )

DataSet <- merge(DataSet,rsqs_short_v5[,c(1,4)], by = "USUBJID", all.x = T)

DataSet <- DataSet %>%
  rename(  ACQ_baseline_score_item5_wheezing = QSSTRESN )

DataSet <- merge(DataSet,rsqs_short_v6[,c(1,4)], by = "USUBJID", all.x = T)

DataSet <- DataSet %>%
  rename(  ACQ_baseline_score_item6_RelieverUse = QSSTRESN )

DataSet$ACQ_baseline_score_item7_FEV1 <- as.numeric(NA)

DataSet$ACT_baseline_score <- as.numeric(NA)

DataSet <- merge(DataSet,rslb.v1[,c(110,36)], by = "USUBJID", all.x = T)

DataSet <- merge(DataSet,rszk.v5[,c(82,33)], by = "USUBJID", all.x = T)

DataSet <- merge(DataSet,rslb.v2_short[,c(1,2)], by = "USUBJID", all.x = T)


DataSet <- merge(DataSet,adsl[,c(95, 65)], by = "USUBJID", all.x = T)

DataSet <- merge(DataSet,adexac.v1[,c(1,2)], by = "USUBJID", all.x = T)

DataSet$Number_severe_asthma_attacks_during_followup <- ifelse( is.na(DataSet$Number_severe_asthma_attacks_during_followup) == T, 0 , DataSet$Number_severe_asthma_attacks_during_followup    )

DataSet <- merge(DataSet,adexac.v2.T1[,c(1,3)], by = "USUBJID", all.x = T)

DataSet <- DataSet %>%
  rename(  Time_to_First_attack = ASTDY )

DataSet <- merge(DataSet,adexac.v2.T2[,c(1,3)], by = "USUBJID", all.x = T)

DataSet <- DataSet %>%
  rename(  Time_to_2n_attack = ASTDY )

DataSet <- merge(DataSet,adexac.v2.T3[,c(1,3)], by = "USUBJID", all.x = T)

DataSet <- DataSet %>%
  rename(  Time_to_3n_attack = ASTDY )

DataSet <- merge(DataSet,adexac.v2.T4[,c(1,3)], by = "USUBJID", all.x = T)

DataSet <- DataSet %>%
  rename(  Time_to_4n_attack = ASTDY )

DataSet <- merge(DataSet,adexac.v2.T5[,c(1,3)], by = "USUBJID", all.x = T)

DataSet <- DataSet %>%
  rename(  Time_to_5n_attack = ASTDY )

DataSet <- merge(DataSet,adsl[,c(95,99)], by = "USUBJID", all.x = T)

DataSet <- merge(DataSet,rszk.v6, by = "USUBJID", all.x = T)

DataSet <- merge(DataSet,rszk.v7, by = "USUBJID", all.x = T)

DataSet <- merge(DataSet,rszk.v8, by = "USUBJID", all.x = T)

DataSet <- merge(DataSet,rszk.v9, by = "USUBJID", all.x = T)

DataSet <- DataSet[!duplicated(DataSet$USUBJID), ]

DataSet <- DataSet %>% 
  group_by(USUBJID) %>%
  mutate( ACQ_baseline_score_mean =  sum(ACQ_baseline_score_item1_sleepawakenings,	 ACQ_baseline_score_item2_morningsymptoms,	
                                         ACQ_baseline_score_item3_activitylimitation,	
                                         ACQ_baseline_score_item4_dyspnea,	
                                         ACQ_baseline_score_item5_wheezing,na.rm=T)/5 )  

DataSet <- DataSet %>%
  rename(  Subject_ID = USUBJID ,
           Age = AGE,
           Gender_M = SEX,
           BMI = BLBMI,
           Number_severe_attack_previous_12m = COVAR06,
           Adherence_PreTrial_quantity = AVAL,
           Blood_Eos_baseline_x10_9_cells_per_L = LBSTRESN,
           FeNO_baseline_ppb = ZKSTRESN,
           Follow_up_duration_days = COVAR04
  )


DataSet$Gender_M <- ifelse( DataSet$Gender_M == "M", 1, 0      )

DataSet <- DataSet[,c(2,1,3:78)]

DataSet$BMI <- ifelse( DataSet$BMI == "." , "", DataSet$BMI    )


DataSet$Time_to_First_attack <- ifelse( DataSet$Time_to_First_attack > DataSet$Follow_up_duration_days, NA,DataSet$Time_to_First_attack      )
DataSet$Time_to_2n_attack <- ifelse( DataSet$Time_to_2n_attack > DataSet$Follow_up_duration_days, NA,DataSet$Time_to_2n_attack      )
DataSet$Time_to_3n_attack <- ifelse( DataSet$Time_to_3n_attack > DataSet$Follow_up_duration_days, NA,DataSet$Time_to_3n_attack      )
DataSet$Time_to_4n_attack <- ifelse( DataSet$Time_to_4n_attack > DataSet$Follow_up_duration_days, NA,DataSet$Time_to_4n_attack      )
DataSet$Time_to_5n_attack <- ifelse( DataSet$Time_to_5n_attack > DataSet$Follow_up_duration_days, NA,DataSet$Time_to_5n_attack      )
DataSet$Number_severe_asthma_attacks_during_followup <- ifelse( is.na(DataSet$Time_to_First_attack)== T, 0,DataSet$Number_severe_asthma_attacks_during_followup      )


write.xlsx(DataSet, "STRATOS_2_clean.xlsx")




