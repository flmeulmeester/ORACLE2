


###########################################################################################################
#
# Project : ORACLE
#
###########################################################################################################


###########################################################################################################
#' [ Working directory initialisation]
###########################################################################################################

setwd("Y:/Simon_Couillard/ORACLE/2023_04_25_Merge")
getwd()

# Package importation

Packages <- c( "readxl","haven","ggplot2","dplyr","MASS", "summarytools", "gmodels",
               "jtools","car","openxlsx","extrafont","stargazer","readr")

lapply(Packages, library, character.only = TRUE)

############################################################################################################
#' [Data import]
############################################################################################################

CAREPACT_clean <- read_excel("Y:/Simon_Couillard/ORACLE/CARE_PACT/CARE_PACT/2023_03_07_Data_clean_CAREPACT/CAREPACT_clean.xlsx")

LAVOLTA1_clean <- read_excel("Y:/Simon_Couillard/ORACLE/LEBRI_LAVOLTA1-2/LEBRI_LAVOLTA1-2/2023_03_08_Merge/LAVOLTA1_clean.xlsx")

LAVOLTA2_clean <- read_excel("Y:/Simon_Couillard/ORACLE/LEBRI_LAVOLTA1-2/LEBRI_LAVOLTA1-2/2023_03_08_Merge/LAVOLTA2_clean.xlsx")

LUTE_clean <- read_excel("Y:/Simon_Couillard/ORACLE/LEBRI_LUTE-VERSE/LEBRI_LUTE-VERSE/2023_03_14_extraction_LUTEVERSE/LUTE_clean.xlsx")

VERSE_clean <- read_excel("Y:/Simon_Couillard/ORACLE/LEBRI_LUTE-VERSE/LEBRI_LUTE-VERSE/2023_03_14_extraction_LUTEVERSE/VERSE_clean.xlsx")

MILLY_clean <- read_excel("Y:/Simon_Couillard/ORACLE/LEBRI_MILLY/LEBRI_MILLY/2023_03_29_Data_clean_MILLY/MILLY_clean.xlsx")

STRATOS_1_clean <- read_excel("Y:/Simon_Couillard/ORACLE/STRATOS 1-2/STRATOS1-2/STRATOS1-2/2023_07_07_Data_clean_STRATOS/STRATOS_1_clean.xlsx")

STRATOS_2_clean <- read_excel("Y:/Simon_Couillard/ORACLE/STRATOS 1-2/STRATOS1-2/STRATOS1-2/2023_07_07_Data_clean_STRATOS/STRATOS_2_clean.xlsx")

BENRAP2B_clean <- read_excel("Y:/Simon_Couillard/ORACLE/BenraP2B/BenraP2B/2023_07_10_Data_clean_BenraP2B/BENRAP2B_clean.xlsx")

############################################################################################################
#' [Merging all Dataset]
############################################################################################################


CompletePatient.DataSet <- rbind(CAREPACT_clean,LAVOLTA1_clean,LAVOLTA2_clean,MILLY_clean,LUTE_clean,VERSE_clean,STRATOS_1_clean,STRATOS_2_clean,BENRAP2B_clean )

CompletePatient.DataSet$Sequential_number <- seq.int(nrow(CompletePatient.DataSet))

write.xlsx( CompletePatient.DataSet, "CompletePatient.DataSet.xlsx"   )


Test <- read_excel("CompletePatient.DataSet.xlsx",guess_max = 1400)


